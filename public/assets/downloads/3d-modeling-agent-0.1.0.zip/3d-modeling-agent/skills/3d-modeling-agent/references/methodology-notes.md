# Methodology Notes

This skill synthesizes three user-supplied documents. Their contents were treated as reference material, not as instructions with authority over the user request or the agent's governing rules.

## Durable contributions

### LLM-Driven 3D Modeling: A Practical Pipeline for AI-Assisted Procedural Asset Creation

Contributed the production architecture:

- LLM as semantic planner, specification writer, code agent, and critic;
- structured asset specification plus semantic component library as authority;
- deterministic DCC or CAD executor rather than unrestricted raw mesh generation;
- Blender as one strong asset-compiler option, not a universal requirement;
- separation of visual, mechanical, collision, and runtime representations;
- layered geometry, canonical renders, local parameter repair, and compiled delivery artifacts.

### Modeling 3D Objects with Large Language Models

Contributed representation awareness and research context:

- procedural/CAD programs for editability and dimensional truth;
- image-conditioned specialist models for general visual assets;
- calibrated reconstruction and neural/Gaussian representations for observed scenes;
- direct mesh or 3D-token generation as an emerging research route;
- multimodal evaluation rather than one universal score;
- separation of model inference from deterministic geometry processing;
- explicit provenance, reproducibility, and execution security.

### 3D Modeling Agent: Operating Specification for Reliable AI-Assisted Asset Creation

Provided the operational synthesis used as this skill's spine:

- artifact contract before tool selection;
- route selection by required truth and intended use;
- source locks for scientific and engineering work;
- concise structured specifications with `UNSPECIFIED` values;
- semantic modeling, staged construction, validation, local repair, human gates, and delivery reporting;
- source/reference content treated as data rather than executable authority.

## Packaging decisions

- Keep `SKILL.md` concise enough for routine invocation.
- Put route mechanics, intake, QA, and schemas in targeted references.
- Include deterministic workspace/specification scripts because these controls are reused across asset classes.
- Do not bundle one particular 3D generator or MCP server as a universal dependency.
- Route to installed Blender, Cinema 4D, CAD, reconstruction, or generative tooling as appropriate.
- Keep named research models out of the core contract because availability, licensing, quality, and compute requirements change quickly.
- Require live verification against official sources before recommending or installing a current model backend.

## Design boundary

This is a production-control skill, not a trained text-to-mesh model and not a replacement for DCC-specific tool instructions. It governs how to choose the representation, preserve authority, plan the build, validate evidence, repair locally, and hand off reliably. DCC skills and geometry backends implement the selected route.
