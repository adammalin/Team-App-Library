# Route Playbooks

Read only the route relevant to the current artifact. Named products and research systems are examples, not permanent defaults; verify current availability, licensing, hardware requirements, and official documentation before recommending or installing them.

## Router

Use this order:

1. Does dimensional, scientific, mechanical, or fabrication truth dominate? Use deterministic procedural or parametric CAD.
2. Is the target a repeatable family or expected to receive precise local edits? Use deterministic procedural or parametric CAD.
3. Is the target a real observed object or scene with sufficient measured imagery or scan data? Use measured reconstruction.
4. Is the target primarily visual, organic, decorative, or a rapid concept? Use controlled generative visual creation.
5. Is direct mesh/token generation itself the experiment? Use the experimental route and make no production claim without independent QA.
6. If portions differ, use a hybrid route and declare source authority per portion.

Do not choose a route merely because its tool is available.

## Route A — Deterministic procedural DCC

Best for editable native scenes, modular systems, stylized hard-surface assets, architectural assemblies, repeatable families, and many scientific illustrations.

```text
brief + references
→ artifact contract
→ asset.spec.json
→ semantic component plan
→ deterministic generator
→ native DCC scene
→ geometry and render QA
→ local parameter repair
→ native and interchange delivery
```

### Blender

Prefer Blender when headless Python, Geometry Nodes, modifiers, UV/baking, rigging, LODs, GLB export, or automated canonical renders are central.

- Keep a named root collection or Empty and semantic collections.
- Use reusable geometry/material helpers.
- Apply or preserve transforms deliberately; do not let unapplied scale invalidate bevels, normals, physics, or export.
- Set renderer, color management, camera, frame, resolution, and output path explicitly.
- Validate the saved `.blend`, not only in-memory state.
- Re-import critical GLB/USD/FBX derivatives when compatibility matters.

### Cinema 4D

Prefer Cinema 4D when the production scene already lives there, artist handoff requires `.c4d`, MoGraph/Fields/native generators are important, or Standard/Physical/Redshift conventions are required.

- Preserve named Null hierarchy, generators, material assignments, object scale, camera, active take, and RenderData.
- Prefer native parametric generators or Scene Nodes when they improve handoff editability.
- When custom geometry is appropriate, create native polygon objects with inspectable points and polygons rather than opaque imported blobs.
- Treat Standard, Physical, and Redshift as distinct contracts; do not silently substitute one.
- Save to a dedicated variant before a major experiment when the original must remain untouched.
- Validate the exact saved `.c4d`, active camera, render data, materials, and a representative mesh.

### Semantic modeling library

Build a narrow vocabulary for the asset family instead of a universal mesh API. Possible categories:

- frames, beams, plates, shells, panels, housings;
- pivots, bearings, sliders, telescoping joints;
- actuators, cables, hoses, mounts, hardpoints;
- windows, doors, walls, supports, modular connectors;
- domain-backed scientific structures;
- collision hulls, keep-out volumes, LODs, materials, rigs, exporters.

The specification should call domain operations and validated parameters. Low-level vertices and faces are implementation details.

## Route A2 — Parametric CAD

Best for dimensioned parts, tolerance-sensitive assemblies, manufacturing review, construction history, and STEP/B-rep delivery.

```text
measurements + constraints
→ source lock
→ feature/constraint plan
→ constrained CAD program
→ deterministic kernel execution
→ dimension and topology inspection
→ explicit approved repair
→ STEP/B-rep plus optional mesh derivative
```

- Keep numbers and tolerances in structured fields, not adjectives.
- Prefer sketches, constraints, extrusions, revolves, patterns, fillets, and booleans that preserve intent.
- Fail or hold when required dimensions are unknown.
- Independently measure the kernel result.
- Do not promote a visually plausible diffusion mesh to authoritative CAD.
- Do not silently heal geometry if healing can change functional dimensions.

CadQuery, OpenSCAD, or another CAD kernel can be an executor, but choose by required output and construction-history needs.

## Route B — Controlled generative visual asset

Best for organic, sculptural, decorative, irregular, background, or rapid concept assets where exact hidden structure is not authoritative.

```text
structured art brief
→ approved single image or consistent multiview package
→ image-conditioned or multiview 3D backend
→ explicit geometry extraction
→ neutral geometry inspection
→ topology/remesh/retopo
→ UV and PBR appearance
→ DCC finishing
→ runtime/render validation
```

### Reference package

Include intended use and viewing distance, front/side/rear/three-quarter views where possible, scale cue, material references, exclusions, articulation/attachment overlay, and approval status.

Reject or repair the reference package before reconstruction when views disagree about silhouette, part count, symmetry, attachments, colors, labels, handles, holes, or movable features. Independent unrelated 2D generations do not constitute measured multiview evidence.

### Backend policy

Specialist systems may produce meshes, SDFs, neural fields, Gaussians, or learned latents. Isolate the backend behind a stable adapter so geometry validation and DCC finishing do not depend on one research repository.

Examples have included feed-forward image-to-mesh systems, multiview reconstruction systems, structured 3D latent models, and separate shape/PBR generators. Verify current official sources before using any named backend.

Generated output is a candidate. Check disconnected components, degeneracy, normals, non-manifold edges, watertightness where required, self-intersection, bounds, scale, triangle count, UVs, and material completeness.

## Route C — Measured reconstruction

Best for reproducing a real object or scene when photographs, video, depth, LiDAR, or scan data are available.

```text
capture-quality review
→ calibration and registration
→ sparse/dense reconstruction
→ point cloud, mesh, neural field, or Gaussians
→ scale registration
→ validation against observations
→ surface extraction only when needed
→ DCC finishing or dedicated renderer
```

- Prefer measured observations over generated missing views when accuracy matters.
- Reject blurred, moving, reflective, textureless, or exposure-inconsistent inputs when they invalidate reconstruction.
- Preserve camera calibration, scale references, masks, and reconstruction settings.
- NeRF or Gaussian representations may be the final artifact for novel-view photorealism.
- Convert to a mesh only when editing, collision, physics, animation, simulation, fabrication, or conventional delivery requires it.
- When extracting a mesh, record method and parameters; validate weakly observed regions separately.

Typical deterministic tools include camera/SfM reconstruction, point-cloud registration, normal estimation, surface reconstruction, mesh inspection, remeshing, and decimation. Keep those stages replaceable.

## Route D — Direct 3D generation experiment

Use only when the task explicitly studies text-serialized meshes, discrete 3D tokens, native 3D language models, or very small constrained geometry.

- State that the route is experimental.
- Enforce hard token, vertex, polygon, memory, and execution limits.
- Parse into a neutral representation before opening in a trusted DCC.
- Run the full geometry and visual QA stack.
- Do not claim production topology, dimensional accuracy, or editability merely because the sample renders.

## Hybrid route

For each component, record:

- route;
- source authority;
- coordinate and scale mapping;
- attachment interface;
- permitted repair operations;
- validation owner.

Examples:

- CAD core plus generative cosmetic shell;
- measured scan plus procedurally rebuilt replacement parts;
- source-locked scientific structure plus illustrative environment;
- generated organic mesh attached to deterministic mechanical hardware.

Do not allow a lower-authority visual stage to modify a higher-authority scientific, dimensional, or mechanical stage.

## Format selection

| Need | Prefer |
|---|---|
| Native artist editing | `.blend` or `.c4d` |
| Web/game/XR runtime | GLB/glTF, with validated PBR and budgets |
| Broad scene interchange | USD, when hierarchy/material conventions are agreed |
| Baked animation/cache | Alembic |
| General mesh interchange | FBX or OBJ with explicit limitations |
| Fabrication mesh | STL only after units, watertightness, and tolerances pass |
| CAD authority | STEP/B-rep; mesh is derivative |
| Novel-view photorealism | Native neural-field or Gaussian representation when supported |

Formats lose different kinds of information. Preserve the native authoritative source and document known losses in materials, constraints, generators, animation, units, axes, or hierarchy.
