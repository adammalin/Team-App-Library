# Validation Matrix

Use validation proportional to the artifact contract. No single metric proves that a 3D asset is good.

## Status vocabulary

- **PASS** — every required check has current evidence and no unresolved blocking defect.
- **PASS WITH WARNINGS** — required checks pass; documented non-blocking limitations remain within the contract.
- **HOLD** — required evidence, authority, target application, or reviewer is unavailable; do not claim completion.
- **FAIL** — a required check produced contrary evidence.

Do not convert HOLD to PASS by lowering the requirement after the fact. Do not infer PASS from file existence, a successful API response, or one attractive render.

## Evidence record

For each required check record:

```json
{
  "id": "GEO-001",
  "category": "topology",
  "requirement": "Watertight fabrication mesh",
  "method": "independent mesh inspection",
  "artifact": "review/mesh-validation.json",
  "result": "PASS",
  "measurement": {"boundary_edges": 0},
  "warnings": []
}
```

Record the exact artifact tested. If the scene or export changes, rerun affected checks.

## Universal checks

### Source and lineage

- User request and approved references are identifiable.
- Document/reference instructions were not treated as execution authority.
- Source-of-truth files are named.
- Assumptions and `UNSPECIFIED` values are visible.
- Generator/model/DCC versions and random seeds are recorded when relevant.
- Original files required to remain unchanged have verified hash, size, or modification-time evidence.

### Structure

- Units, scale, origin, handedness, up axis, and front axis match the specification.
- Required components exist exactly once and use stable names.
- Parentage, symmetry, attachments, materials, and transforms are valid.
- No unintended fragments, duplicate objects, empty deliverables, or unresolved external dependencies.

### Geometry

- Bounds and scale are plausible and measured.
- Normals and winding are consistent.
- Degenerate faces, duplicate faces, zero-area geometry, and non-manifold edges meet the contract.
- Watertightness, self-intersection, wall thickness, clearances, and topology are tested when required.
- Object, polygon, vertex, material, texture-memory, and draw-call budgets are measured when relevant.

### Visual

- Canonical views use recorded cameras, framing, resolution, renderer, frame, and color settings.
- Neutral geometry renders are inspected before texture is credited with fixing shape.
- Silhouette, proportions, component placement, negative spaces, symmetry, materials, distinctive features, and final-size readability are compared against approved references.
- Critical back, underside, occluded, and close-up views are inspected when they affect use.

### Delivery

- The exact final native scene opens in the target application.
- Textures, caches, linked assets, materials, hierarchy, cameras, rigs, animation, and units resolve as required.
- Interchange/runtime outputs pass an appropriate validator.
- Critical derivatives are re-imported into the destination application or a representative clean environment.
- Known format losses are reported.

## Route-specific checks

### Deterministic procedural DCC

- Rebuild from specification succeeds without manual hidden steps.
- Repeated build with the same version and seed is equivalent within documented tolerances.
- Generator parameters produce localized changes without unrelated drift.
- Native scene retains the promised editability: generators, modifiers, Scene Nodes, named polygon objects, materials, or hierarchy.
- A representative mesh is inspected, not merely listed.
- Active camera, renderer, take/frame, and RenderData are confirmed before the final render.

### Parametric CAD

- Feature program/kernel execution succeeds.
- Required dimensions and tolerances are independently measured.
- Constraint system has no unacceptable under/over-constraint.
- B-rep/solid validity, minimum wall thickness, interference, and manufacturing constraints pass as required.
- STEP/B-rep opens in a clean target environment.
- Any healing or repair is explicit and remeasured.

### Generative visual asset

- Input views are mutually consistent or contradictions are documented.
- Geometry is inspected without materials.
- Unobserved geometry is identified as inferred.
- Mesh extraction, remeshing, retopology, UV, and texture steps have recorded versions/settings.
- Perceptual similarity is paired with topology and runtime checks.
- Model/checkpoint, prompts, seeds, input images, and licenses are recorded.

### Measured reconstruction

- Capture set quality, calibration, and scale reference pass.
- Registration/reprojection error is measured when the method supports it.
- Weakly observed, reflective, moving, or occluded regions are identified.
- Surface extraction does not silently convert uncertain space into authoritative geometry.
- Validation compares against held-out observations when practical.

### Mechanical or articulated asset

- Joint centers, axes, limits, and hierarchy match the specification.
- Full required range-of-motion sweep passes.
- Actuators remain attached and within travel limits.
- Collision proxies align with intended solids.
- Clearances, penetrations, reachability, mass, center of mass, stability, and contact geometry are tested when specified.
- Visual geometry is not used as mechanical truth without an explicit contract.

### Scientific or source-locked asset

- Geometry, orientation, labels, composition, scale, and semantic colors are checked against authoritative data.
- Illustrative metaphors cannot reasonably be mistaken for unsupported claims.
- Simplifications and uncertainties are documented.
- Required domain-expert review is complete, or status remains HOLD.

### Runtime/game/XR asset

- Target polygon count, draw calls, material count, texture bytes, compression, and LOD behavior pass.
- Collision, skeleton, animations, morph targets, and material channels import correctly.
- Frame time and memory are measured in the target or a representative environment.
- Visual LOD changes do not silently alter authoritative collision or interaction behavior.

### Fabrication asset

- Units and manufacturing scale are explicit.
- Watertight solid, wall thickness, tolerances, clearances, overhang/support constraints, and machine/material limits pass as required.
- Fabrication authorization and safety review are distinct from visual approval.

## Canonical view minimums

Choose views based on the asset, but a substantial isolated-object review commonly includes front, rear, left, right, top, bottom, and a three-quarter hero view. Add close-ups for critical features and poses for articulated assets.

Use consistent neutral lighting for comparison. A beauty render can be included but cannot replace diagnostic views.

## Local repair finding

```json
{
  "id": "VIS-014",
  "status": "revision_required",
  "category": "proportion",
  "component": "knee_housing",
  "evidence": "Front-view width is 12 percent below the approved sheet.",
  "severity": "medium",
  "patch": {
    "source": "asset.spec.json",
    "path": "components.knee_housing.dimensions.width",
    "operation": "multiply",
    "value": 1.12
  },
  "protected_constraints": [
    "knee_joint.center",
    "knee_joint.axis",
    "actuator.endpoints"
  ],
  "rerun": ["DIM-003", "VIS-FRONT", "MECH-SWEEP"]
}
```

Apply only the authorized patch, then rerun every dependent check. If the same blocker repeats without new evidence or an available repair, report HOLD with the exact requirement and missing capability.

## Handoff checklist

- Source of truth and native scene are linked.
- Deliverables and formats are listed.
- Validation status is stated without exaggeration.
- Exact renders/reports used as evidence are linked.
- Assumptions, warnings, and approval state are explicit.
- Compatibility and renderer limitations are stated.
- Original preservation is confirmed when required.
