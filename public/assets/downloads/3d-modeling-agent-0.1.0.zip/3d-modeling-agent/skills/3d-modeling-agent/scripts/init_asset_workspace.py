#!/usr/bin/env python3
"""Create a conservative, inspectable 3D asset workspace and specification."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


ROUTES = (
    "deterministic_procedural",
    "parametric_cad",
    "generative_visual",
    "measured_reconstruction",
    "direct_3d_experimental",
    "hybrid",
)

ACCURACY_CLASSES = (
    "visual_approximation",
    "proportionally_faithful",
    "dimensionally_constrained",
    "scientifically_authoritative",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", help="New or empty workspace directory")
    parser.add_argument("--asset-id", required=True, help="Lowercase stable asset identifier")
    parser.add_argument("--name", required=True, help="Human-readable asset name")
    parser.add_argument("--purpose", default="UNSPECIFIED")
    parser.add_argument("--scope", choices=("object", "assembly", "environment", "captured_scene", "UNSPECIFIED"), default="UNSPECIFIED")
    parser.add_argument("--route", choices=ROUTES, default="deterministic_procedural")
    parser.add_argument("--accuracy-class", choices=ACCURACY_CLASSES, default="visual_approximation")
    parser.add_argument("--units", default="UNSPECIFIED")
    parser.add_argument("--dcc", default="UNSPECIFIED")
    return parser.parse_args()


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> None:
    args = parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]*", args.asset_id):
        fail("--asset-id must match [a-z0-9][a-z0-9_-]*")

    output = Path(args.output).expanduser().resolve()
    home = Path.home().resolve()
    if output == home or output == Path(output.anchor):
        fail("refusing to use a home directory or filesystem root as the workspace")
    if output.exists() and any(output.iterdir()):
        fail(f"workspace already exists and is not empty: {output}")

    skill_root = Path(__file__).resolve().parent.parent
    example_path = skill_root / "references" / "asset-spec.example.json"
    schema_path = skill_root / "references" / "asset-spec.schema.json"
    spec = json.loads(example_path.read_text(encoding="utf-8"))
    spec["$schema"] = "source/asset-spec.schema.json"
    spec["asset"].update(
        {
            "id": args.asset_id,
            "name": args.name,
            "purpose": args.purpose,
            "scope": args.scope,
            "route": args.route,
            "accuracy_class": args.accuracy_class,
        }
    )
    spec["coordinates"].update(
        {
            "units": args.units,
            "origin": "UNSPECIFIED",
            "up_axis": "UNSPECIFIED",
            "front_axis": "UNSPECIFIED",
            "handedness": "UNSPECIFIED",
        }
    )
    spec["inputs"] = {"brief": "design.md", "references": [], "authoritative_data": []}
    spec["assumptions"] = []
    spec["components"] = []
    spec["appearance"] = {"design_language": "UNSPECIFIED", "materials": {}, "prohibited_features": []}
    spec["geometry"] = {
        "silhouette_priority": "UNSPECIFIED",
        "symmetry": "UNSPECIFIED",
        "manifold_required": "UNSPECIFIED",
        "watertight_required": "UNSPECIFIED",
        "max_triangle_count": "UNSPECIFIED",
    }
    spec["motion"] = {"mode": "UNSPECIFIED", "joints": []}
    spec["deliverables"] = {
        "native_scene": "UNSPECIFIED",
        "formats": [],
        "output_directory": "deliverables",
        "files": [],
    }
    spec["validation"] = {"required_checks": [], "canonical_views": [], "thresholds": {}}
    spec["provenance"] = {
        "generator": "UNSPECIFIED",
        "dcc": args.dcc,
        "source_files": ["design.md", "source/asset-spec.schema.json"],
        "random_seed": "UNSPECIFIED",
    }
    spec["review"] = {
        "artifact_contract": "draft",
        "scientific_interpretation": "pending" if args.accuracy_class == "scientifically_authoritative" else "not_applicable",
        "final_approval": "pending",
    }

    output.mkdir(parents=True, exist_ok=True)
    for directory in ("references", "source", "review", "deliverables"):
        (output / directory).mkdir(exist_ok=True)

    (output / "source" / "asset-spec.schema.json").write_text(
        schema_path.read_text(encoding="utf-8"), encoding="utf-8"
    )
    (output / "asset.spec.json").write_text(json.dumps(spec, indent=2) + "\n", encoding="utf-8")
    (output / "design.md").write_text(
        f"# {args.name}\n\n"
        "## User request\n\nRecord the governing request here.\n\n"
        "## Artifact contract\n\nRecord intended use, accuracy, editability, target, and deliverables.\n\n"
        "## Source authority\n\nIdentify authoritative data and visual references.\n",
        encoding="utf-8",
    )
    (output / "assumptions.md").write_text(
        "# Assumptions and unresolved requirements\n\n"
        "Record consequential assumptions, reversible defaults, and UNSPECIFIED values.\n",
        encoding="utf-8",
    )
    manifest = {
        "asset_id": args.asset_id,
        "asset_version": "0.1.0",
        "specification": "asset.spec.json",
        "route": args.route,
        "accuracy_class": args.accuracy_class,
        "status": "draft",
        "deliverables": [],
        "validation_reports": [],
        "warnings": ["Artifact contract and final approval are pending."],
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    print(json.dumps({"status": "created", "workspace": str(output), "specification": str(output / "asset.spec.json")}, indent=2))


if __name__ == "__main__":
    main()
