#!/usr/bin/env python3
"""Exercise the packaged workspace initializer and specification validator."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path


def run(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, text=True, capture_output=True, check=False)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> None:
    scripts = Path(__file__).resolve().parent
    initializer = scripts / "init_asset_workspace.py"
    validator = scripts / "validate_asset_spec.py"
    results: list[dict[str, object]] = []

    with tempfile.TemporaryDirectory(prefix="3d-modeling-agent-test-") as temp:
        workspace = Path(temp) / "sample-asset"
        created = run(
            sys.executable,
            str(initializer),
            str(workspace),
            "--asset-id",
            "sample-asset",
            "--name",
            "Sample Asset",
            "--route",
            "deterministic_procedural",
            "--units",
            "m",
            "--dcc",
            "Blender",
        )
        require(created.returncode == 0, created.stderr or created.stdout)
        require((workspace / "asset.spec.json").is_file(), "initializer did not create asset.spec.json")
        require((workspace / "source" / "asset-spec.schema.json").is_file(), "initializer did not copy the schema")
        results.append({"case": "initialize_workspace", "status": "PASS"})

        spec_path = workspace / "asset.spec.json"
        baseline = run(sys.executable, str(validator), str(spec_path))
        require(baseline.returncode == 0, baseline.stderr or baseline.stdout)
        require(json.loads(baseline.stdout)["status"] == "PASS_WITH_WARNINGS", "draft spec should pass structurally with warnings")
        results.append({"case": "validate_draft", "status": "PASS"})

        existing = run(
            sys.executable,
            str(initializer),
            str(workspace),
            "--asset-id",
            "sample-asset",
            "--name",
            "Sample Asset",
        )
        require(existing.returncode != 0, "initializer should refuse a non-empty workspace")
        results.append({"case": "protect_existing_workspace", "status": "PASS"})

        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        spec["asset"].update({"purpose": "renderer-independent self-test", "scope": "object"})
        spec["coordinates"].update({"origin": "object base center", "up_axis": "+Y", "front_axis": "-Z", "handedness": "right"})
        spec["appearance"]["design_language"] = "neutral test material"
        spec["geometry"].update(
            {
                "silhouette_priority": "high",
                "symmetry": "bilateral",
                "manifold_required": True,
                "watertight_required": False,
                "max_triangle_count": 100000,
            }
        )
        spec["motion"]["mode"] = "static"
        spec["deliverables"].update({"native_scene": "sample-asset.blend", "formats": ["blend"]})
        spec["validation"].update({"required_checks": ["silhouette", "topology"], "canonical_views": ["front", "side", "three-quarter"]})
        spec["provenance"].update({"generator": "self_test.py", "random_seed": "not_applicable"})
        spec["review"].update({"artifact_contract": "approved", "final_approval": "approved"})
        spec_path.write_text(json.dumps(spec, indent=2) + "\n", encoding="utf-8")
        complete = run(sys.executable, str(validator), str(spec_path), "--strict")
        require(complete.returncode == 0, complete.stderr or complete.stdout)
        require(json.loads(complete.stdout)["status"] == "PASS", "complete spec should pass without warnings")
        results.append({"case": "validate_complete_spec", "status": "PASS"})

        component = {
            "id": "duplicate",
            "type": "part",
            "parent": "root",
            "source_authority": "brief",
            "parameters": {},
            "material_role": "default",
        }
        spec["components"] = [component, dict(component)]
        spec_path.write_text(json.dumps(spec, indent=2) + "\n", encoding="utf-8")
        duplicate = run(sys.executable, str(validator), str(spec_path))
        require(duplicate.returncode == 1, "duplicate component IDs should fail")
        require(any("duplicate component id" in item["message"] for item in json.loads(duplicate.stdout)["errors"]), "duplicate error missing")
        results.append({"case": "reject_duplicate_component", "status": "PASS"})

        spec["components"] = []
        spec["asset"]["accuracy_class"] = "scientifically_authoritative"
        spec["coordinates"]["units"] = "UNSPECIFIED"
        spec["inputs"]["authoritative_data"] = []
        spec_path.write_text(json.dumps(spec, indent=2) + "\n", encoding="utf-8")
        source_lock = run(sys.executable, str(validator), str(spec_path))
        require(source_lock.returncode == 1, "scientifically authoritative assets should require units and authoritative data")
        messages = [item["message"] for item in json.loads(source_lock.stdout)["errors"]]
        require(any("authoritative source" in message for message in messages), "source-lock error missing")
        results.append({"case": "enforce_source_lock", "status": "PASS"})

        spec["asset"] = []
        spec["coordinates"] = []
        spec_path.write_text(json.dumps(spec, indent=2) + "\n", encoding="utf-8")
        malformed = run(sys.executable, str(validator), str(spec_path))
        require(malformed.returncode == 1, "malformed object sections should fail without crashing")
        malformed_report = json.loads(malformed.stdout)
        require(malformed_report["status"] == "FAIL", "malformed spec should report FAIL")
        results.append({"case": "reject_malformed_sections", "status": "PASS"})

    print(json.dumps({"status": "PASS", "cases": results}, indent=2))


if __name__ == "__main__":
    main()
