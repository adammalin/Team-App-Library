#!/usr/bin/env python3
"""Validate core invariants in a 3D Modeling Agent asset.spec.json file."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


ROUTES = {
    "deterministic_procedural",
    "parametric_cad",
    "generative_visual",
    "measured_reconstruction",
    "direct_3d_experimental",
    "hybrid",
}

ACCURACY_CLASSES = {
    "visual_approximation",
    "proportionally_faithful",
    "dimensionally_constrained",
    "scientifically_authoritative",
}

REQUIRED_SECTIONS = (
    "schema_version",
    "asset",
    "coordinates",
    "inputs",
    "assumptions",
    "components",
    "appearance",
    "geometry",
    "motion",
    "deliverables",
    "validation",
    "provenance",
    "review",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", help="Path to asset.spec.json")
    parser.add_argument("--strict", action="store_true", help="Return nonzero when warnings remain")
    return parser.parse_args()


def collect_unspecified(value: Any, path: str = "$") -> list[str]:
    found: list[str] = []
    if value == "UNSPECIFIED":
        found.append(path)
    elif isinstance(value, dict):
        for key, child in value.items():
            found.extend(collect_unspecified(child, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.extend(collect_unspecified(child, f"{path}[{index}]"))
    return found


def is_dict(value: Any) -> bool:
    return isinstance(value, dict)


def main() -> None:
    args = parse_args()
    spec_path = Path(args.spec).expanduser().resolve()
    errors: list[dict[str, str]] = []
    warnings: list[dict[str, str]] = []

    def error(path: str, message: str) -> None:
        errors.append({"path": path, "message": message})

    def warn(path: str, message: str) -> None:
        warnings.append({"path": path, "message": message})

    try:
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        error("$", f"file does not exist: {spec_path}")
        spec = {}
    except json.JSONDecodeError as exc:
        error("$", f"invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}")
        spec = {}

    if not is_dict(spec):
        error("$", "top level must be an object")
        spec = {}

    for section in REQUIRED_SECTIONS:
        if section not in spec:
            error(f"$.{section}", "required section is missing")

    asset = spec.get("asset", {})
    coordinates = spec.get("coordinates", {})
    inputs = spec.get("inputs", {})
    components = spec.get("components", [])
    deliverables = spec.get("deliverables", {})
    validation = spec.get("validation", {})
    review = spec.get("review", {})

    for path, value in (("$.asset", asset), ("$.coordinates", coordinates), ("$.inputs", inputs), ("$.deliverables", deliverables), ("$.validation", validation), ("$.review", review)):
        if not is_dict(value):
            error(path, "must be an object")

    asset_route = asset.get("route") if is_dict(asset) else None
    asset_accuracy = asset.get("accuracy_class") if is_dict(asset) else None
    coordinate_units = coordinates.get("units") if is_dict(coordinates) else None

    if is_dict(asset):
        asset_id = asset.get("id")
        if not isinstance(asset_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9_-]*", asset_id):
            error("$.asset.id", "must match [a-z0-9][a-z0-9_-]*")
        for key in ("name", "version", "purpose", "scope"):
            if not isinstance(asset.get(key), str) or not asset.get(key):
                error(f"$.asset.{key}", "must be a non-empty string")
        if asset.get("route") not in ROUTES:
            error("$.asset.route", f"must be one of {sorted(ROUTES)}")
        if asset.get("accuracy_class") not in ACCURACY_CLASSES:
            error("$.asset.accuracy_class", f"must be one of {sorted(ACCURACY_CLASSES)}")

    if is_dict(coordinates):
        for key in ("units", "origin", "up_axis", "front_axis", "handedness"):
            if key not in coordinates:
                error(f"$.coordinates.{key}", "is required")
        up_axis = coordinates.get("up_axis")
        front_axis = coordinates.get("front_axis")
        if isinstance(up_axis, str) and isinstance(front_axis, str):
            if up_axis != "UNSPECIFIED" and front_axis != "UNSPECIFIED" and up_axis.lstrip("+-") == front_axis.lstrip("+-"):
                error("$.coordinates", "up_axis and front_axis cannot use the same axis")

    if not isinstance(components, list):
        error("$.components", "must be an array")
        components = []
    component_ids: set[str] = set()
    for index, component in enumerate(components):
        path = f"$.components[{index}]"
        if not is_dict(component):
            error(path, "must be an object")
            continue
        component_id = component.get("id")
        if not isinstance(component_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9_-]*", component_id):
            error(f"{path}.id", "must match [a-z0-9][a-z0-9_-]*")
        elif component_id in component_ids:
            error(f"{path}.id", f"duplicate component id: {component_id}")
        else:
            component_ids.add(component_id)
        for key in ("type", "parent", "source_authority", "parameters", "material_role"):
            if key not in component:
                error(f"{path}.{key}", "is required")

    for index, component in enumerate(components):
        if not is_dict(component):
            continue
        parent = component.get("parent")
        if isinstance(parent, str) and parent not in {"root", "UNSPECIFIED"} and parent not in component_ids:
            error(f"$.components[{index}].parent", f"unknown parent component: {parent}")

    if is_dict(inputs):
        references = inputs.get("references")
        authoritative = inputs.get("authoritative_data")
        if not isinstance(references, list):
            error("$.inputs.references", "must be an array")
            references = []
        if not isinstance(authoritative, list):
            error("$.inputs.authoritative_data", "must be an array")
            authoritative = []
        source_ids: set[str] = set()
        for category, sources in (("references", references), ("authoritative_data", authoritative)):
            for index, source in enumerate(sources):
                path = f"$.inputs.{category}[{index}]"
                if not is_dict(source):
                    error(path, "must be an object")
                    continue
                source_id = source.get("id")
                if not isinstance(source_id, str) or not source_id:
                    error(f"{path}.id", "must be a non-empty string")
                elif source_id in source_ids:
                    error(f"{path}.id", f"duplicate source id: {source_id}")
                else:
                    source_ids.add(source_id)
                for key in ("role", "path", "approval_status", "authoritative"):
                    if key not in source:
                        error(f"{path}.{key}", "is required")

        if asset_accuracy in {"dimensionally_constrained", "scientifically_authoritative"}:
            if coordinate_units == "UNSPECIFIED":
                error("$.coordinates.units", f"cannot be UNSPECIFIED for {asset_accuracy}")
            if not authoritative:
                error("$.inputs.authoritative_data", f"at least one authoritative source is required for {asset_accuracy}")

    if is_dict(deliverables):
        formats = deliverables.get("formats")
        if not isinstance(formats, list):
            error("$.deliverables.formats", "must be an array")
        elif not formats:
            warn("$.deliverables.formats", "no delivery format is selected")
        if not deliverables.get("output_directory"):
            error("$.deliverables.output_directory", "must be a non-empty string")

    if is_dict(validation):
        checks = validation.get("required_checks")
        if not isinstance(checks, list):
            error("$.validation.required_checks", "must be an array")
        elif not checks:
            warn("$.validation.required_checks", "no required validation checks are selected")

    if asset_route == "direct_3d_experimental":
        warn("$.asset.route", "direct 3D generation is experimental and requires independent validation")
    if asset_route == "parametric_cad" and is_dict(deliverables):
        formats = {str(value).lower() for value in deliverables.get("formats", []) if isinstance(value, str)}
        if not formats.intersection({"step", "stp", "iges", "igs", "brep"}):
            warn("$.deliverables.formats", "parametric CAD route has no STEP, IGES, or B-rep deliverable")

    if is_dict(review):
        if review.get("final_approval") in {None, "pending", "draft", "UNSPECIFIED"}:
            warn("$.review.final_approval", "final human approval is not recorded")
        if asset_accuracy == "scientifically_authoritative" and review.get("scientific_interpretation") != "approved":
            warn("$.review.scientific_interpretation", "scientific interpretation approval is not recorded")

    unspecified = collect_unspecified(spec)
    if unspecified:
        warn("$", f"{len(unspecified)} UNSPECIFIED value(s) remain; first paths: {unspecified[:12]}")

    status = "FAIL" if errors else ("PASS_WITH_WARNINGS" if warnings else "PASS")
    report = {
        "status": status,
        "specification": str(spec_path),
        "errors": errors,
        "warnings": warnings,
        "component_count": len(components),
        "unspecified_count": len(unspecified),
    }
    print(json.dumps(report, indent=2))
    if errors:
        raise SystemExit(1)
    if args.strict and warnings:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
