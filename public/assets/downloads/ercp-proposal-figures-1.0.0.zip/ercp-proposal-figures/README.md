# ERCP Proposal Figures Agent Plugin

This Agent Plugins 1.0 package adds one Codex skill: `create-ercp-proposal-figures`.

It turns a substantive DOE Office of Science ERCP or ECRP proposal draft into one source-grounded Figure 1 collaboration draft. The visual deliverable is always a completely label-free, opaque 1536 × 1024 raster PNG produced with Codex image generation. It is never an SVG, vector file, slide, PDF, final scientific figure, or submission-ready artifact.

## What the workflow does

1. Opens and reads the attached proposal rather than relying on its filename or a user summary.
2. Locks the scientific system, gap, objectives, primary capability, decisive relationship, validation logic, endpoint, DOE payoff, and evidence.
3. Builds one proposal-native funding argument that answers “Why fund this?” without turning the figure into a Roadmap or methods inventory.
4. Assigns visible carriers for Vision, Gap, Objectives, Approach, and Impact. Those role names are explained only in chat.
5. Selects one of four bundled style references after the proposal-native topology is fixed. The examples control visual language only; they never supply science or claims.
6. Generates two internal, label-free raster candidates, inspects the actual images, permits at most one localized repair, and returns only the strongest usable PNG.
7. Archives the source hash, prompts, candidates, QA records, and selected result in a workspace-bound run folder.

The package also includes four style-reference PNGs, four fictional qualification fixtures, a deterministic self-test, and a frozen evaluation protocol.

## Start a Figure 1

Attach the substantive proposal draft to a Codex task and say:

> Use $create-ercp-proposal-figures on the proposal attached to this message. Create one completely label-free Figure 1 collaboration draft. If I attached an existing Figure 1, Roadmap, sketch, or style reference, use only its visual system.

An existing companion figure is optional. When none is supplied, the skill uses the bundled visual family. The source files remain read-only.

For a first-time recipient, attach the versioned plugin ZIP and proposal together and use the one-shot bootstrap prompt in `INSTALL-PROMPT.md`. It installs the plugin and tells Codex to follow the packaged skill directly for that same task.

## Product boundary

The result is an AI-generated collaboration draft for researcher interpretation, graphic-designer redraw, and scientist/content-owner verification. The package does not create Roadmaps and does not modify Custom GPTs or external systems.

## Package layout

```text
plugin.json
.codex-plugin/plugin.json
skills/
  create-ercp-proposal-figures/
    SKILL.md
    agents/openai.yaml
    assets/
    references/
    scripts/
```

The root `plugin.json` follows Agent Plugins 1.0. The `.codex-plugin` manifest provides Codex-specific presentation metadata without changing the portable core manifest.

## Validate the package

Run the packaged deterministic test:

```bash
python3 skills/create-ercp-proposal-figures/scripts/self_test.py
```

See `skills/create-ercp-proposal-figures/references/testing-and-evaluation.md` for the frozen live-image qualification checks and the boundary between script validation and stochastic visual quality.
