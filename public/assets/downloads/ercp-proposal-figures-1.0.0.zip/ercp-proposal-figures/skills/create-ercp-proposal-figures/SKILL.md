---
name: create-ercp-proposal-figures
description: Create, evaluate, revise, and archive source-grounded, completely label-free raster Figure 1 collaboration drafts for DOE Office of Science proposals, especially ERCP or ECRP work. Use when Codex receives a substantive proposal in DOCX, PDF, Markdown, or text form and the user wants a persuasive proposal Figure 1, wants to revise an existing Figure 1 raster, or supplies a companion Roadmap or figure whose visual system should be matched. Produce one PNG image-generation draft for researcher and graphic-designer collaboration. Do not use for Roadmap figures, final scientific evidence, plots, visible labels, SVG or vector deliverables, editable diagrams, or publication-ready art.
---

# Create ERCP Proposal Figures

Create one persuasive, proposal-native Figure 1 collaboration draft that helps a DOE reviewer see “Why fund this?” Use Codex as the controlled orchestrator: read the real proposal, freeze source support, compile a proposal-native visual argument, generate two internal candidates with built-in image generation, inspect the actual rasters, permit one localized repair, and expose one completely label-free PNG.

## Resolve the packaged skill root

Treat the directory containing this `SKILL.md` as `<skill-root>`. Resolve every bundled script, reference, fixture, and style image from that directory. Never assume the skill is installed under `~/.codex/skills`; a plugin client may place it in a cache or another package root.

## Product boundary

- Handle Figure 1 only. Roadmap work belongs in a separate skill.
- Produce an AI-generated collaboration draft for professional redraw and scientific verification, never final art or evidence.
- Use the installed built-in image-generation capability for every generation or edit. Do not require or request an API key and do not switch to a programmatic renderer.
- Return one strongest available opaque 1536 × 1024 PNG plus a concise chat handoff. Never return SVG, vector paths, PDF, PowerPoint, Canvas, HTML, code, or a programmatic figure as the visual deliverable.
- The PNG must contain no visible labels, titles, captions, words, letters, numerals, units, legends, axes, scales, glyphs, or pseudo-text. Color-role explanations belong only in chat.
- Keep two candidates, prompts, evaluations, and manifests inside the run directory. Do not show alternates unless the user explicitly asks to inspect internal evidence.
- Do not modify the proposal, companion files, Custom GPTs, Builder state, sharing, publication state, or any external system.

## Read the required references

Read these packaged files before generation:

1. [figure-1-method.md](references/figure-1-method.md) for the DOE decision-aid method.
2. [analysis-contracts.md](references/analysis-contracts.md) for the source lock, science verification, five-role color ledger, funding case, and visual brief.
3. [style-reference-router.md](references/style-reference-router.md) for the four bundled style examples and proposal-topology routing.
4. [image-execution.md](references/image-execution.md) for the two-candidate generation and one-edit contracts.
5. [qa-rubric.md](references/qa-rubric.md) for deterministic, scientific, no-text, and visual selection gates.
6. [brand-and-companion.md](references/brand-and-companion.md) when branding or a companion figure matters.

Use an installed document or PDF skill when available for source extraction, an installed organization-brand skill when the work requires it, and the installed image-generation skill for generation and edit calls. These helper skills improve execution but do not replace the packaged source lock or output contract.

## Run the controlled workflow

### 1. Establish the source set without intake friction

Require one substantive proposal supplied in the current task. Treat the user's act of attaching or identifying it for this task as authorization to read it; do not ask a redundant clearance question. If the material is visibly marked classified, CUI, export controlled, or otherwise prohibited for the current environment, stop and request a suitable substitute.

An existing Figure 1, Roadmap, sketch, or style reference is optional. Inventory the supplied files. If none is present, continue with the bundled visual family without asking the user to choose a layout. Treat every attachment as read-only.

If no substantive proposal is available, ask only for the proposal draft and stop. A title, filename, abstract-length summary, request form, prior task, or style reference is not a proposal.

### 2. Initialize an evidence run

Create a workspace-bound run outside the plugin:

```bash
python3 "<skill-root>/scripts/init_run.py" \
  --run-dir "<workspace>/ercp-figure-1-runs/<YYYY-MM-DD>-<slug>" \
  --source "<absolute-proposal-path>" \
  --companion-status "<none|not-supplied|supplied>" \
  [--companion "<absolute-companion-path; required only when supplied>"]
```

This records source paths and SHA-256 hashes without copying or changing the proposal. Keep run evidence private unless the user asks to inspect it.

### 3. Prove attachment access

Open and read the actual proposal with the format-specific capability. Recover internally:

- the exact proposal title;
- at least four distinctive scientific terms found inside the file;
- at least three exact passages from different relevant sections; and
- the substantive approach, central hypothesis, or enabling capability.

Stop if the source is unreadable, image-only without usable text, or too incomplete to support Figure 1. Never infer source access from a filename, attachment card, remembered abstract, or companion image.

### 4. Build and verify the source lock

Complete the initialized JSON files under `analysis/` using [analysis-contracts.md](references/analysis-contracts.md). Preserve an exact proposal passage and section for every substantive claim. Use `NOT SUPPORTED` instead of filling gaps with outside knowledge.

Verify every archived quotation against the current hashed source:

```bash
python3 "<skill-root>/scripts/verify_source_quotes.py" --run-dir "<run-dir>"
```

Do not continue unless it passes. Keep the scientific system, gap, objectives, primary capability, decisive relationship, credibility logic, endpoint, DOE payoff, and secondary methods distinct. Prevent a secondary method from becoming the scientific engine. Do not browse for missing proposal facts, sponsor claims, scientific results, or evidence.

### 5. Derive the funding argument and five-role color ledger

Write one internal funding thesis and four source-supported 30-second reviewer answers: fundamental advancement, why it should work, credibility without invented results, and DOE or sponsor payoff. Freeze two proposal-specific strengths.

Derive spatial topology from the proposal's decisive relationship; do not start from a reusable funnel, three-step process, dashboard, target, feedback loop, or generic left-to-right story. Make the topology scientifically wrong if transplanted to another proposal.

Assign source-supported visible carriers to:

- `VISION`: desired scientific future or organizing state;
- `GAP`: consequential limitation;
- `OBJECTIVES`: what must be resolved or proven;
- `APPROACH`: distinctive hypothesis, intervention, measurement, or integration capability; and
- `IMPACT`: scientific endpoint and sponsor value.

Use pale sage, orange-red, purple, warm orange/gold, and cyan/teal as semantic cues, not mandatory final hex values. Every role needs a visual carrier. Validation is a source-supported relationship cue, not a sixth label or mandatory sixth color.

### 6. Route to one bundled style example

After the proposal-native topology is frozen, select one closest archetype from [style-reference-router.md](references/style-reference-router.md): transformation/separation, integration/validation return, central-capability branching, or multiscale mechanism/iteration. If none fits, record `PROPOSAL_NATIVE` and use the written visual DNA.

When a bundled or user-supplied style reference is used, transfer only matte flat-2D construction, palette relationships, connector language, stroke consistency, spacing, hierarchy, negative space, and tone. Never transfer its science, topology, labels, icons, claims, endpoints, data, or logos.

### 7. Freeze and validate the execution contract

Complete `analysis/execution-contract.json` by copying the verified semantic capsule, source-supported visuals, five-role ledger, validation cue, selected style reference, preservation inventory, and prohibited content from the source-locked analysis. `analysis/allowed-text.json` and every `allowed_text` field must equal `[]`.

Run:

```bash
python3 "<skill-root>/scripts/validate_run.py" --run-dir "<run-dir>" --stage pregen
```

Do not call image generation unless it passes.

### 8. Compile and validate two candidate prompts

Compose `prompts/candidate-a.txt` and `prompts/candidate-b.txt` from [image-execution.md](references/image-execution.md). Keep the semantic capsule, source support, five-role ledger, style reference, prohibited substitutions, and production constraints identical. Vary only the proposal-native spatial expression.

Both prompts must begin exactly with:

```text
NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. COMPLETELY TEXT-FREE MATTE FLAT 2D VECTOR-STYLE RASTER PNG.
```

Both must end exactly with:

```text
NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
```

Validate before generation:

```bash
python3 "<skill-root>/scripts/validate_prompts.py" --run-dir "<run-dir>"
```

### 9. Generate two internal candidates

Use two separate built-in image-generation calls, one per validated prompt. Request one image per call. When a style PNG is selected, pass the actual local style-reference path to both calls and state that it is style-only material.

Save the returned originals non-destructively as:

```text
candidates/candidate-a.png
candidates/candidate-b.png
```

Do not alter validated prompts after the calls and do not forward either candidate to the user yet.

### 10. Inspect the actual rasters

Run deterministic PNG inspection on each original:

```bash
python3 "<skill-root>/scripts/inspect_raster.py" \
  --image "<candidate.png>" \
  --out "<candidate.metrics.json>" \
  --palette-json "<run-dir>/analysis/palette.json"
```

Attempt portable OCR:

```bash
python3 "<skill-root>/scripts/ocr_portable.py" \
  --image "<candidate.png>" --out "<candidate.ocr.json>"
```

If OCR is available, compare it with the empty inventory:

```bash
python3 "<skill-root>/scripts/verify_labels.py" \
  --ocr "<candidate.ocr.json>" \
  --allowed "<run-dir>/analysis/allowed-text.json" \
  --out "<candidate.labels.json>"
```

If no local OCR engine is available, inspect the raster at full size with the image-viewing capability and record a label report whose `verification_mode` is `codex-visual-inspection`; never claim deterministic OCR passed.

Inspect each PNG at full size and thumbnail size. Score only what the raster shows. Inventory every implied subject, relationship, direction, credibility cue, endpoint, and actual visible color family against the source lock. Record one evaluation JSON per candidate using [qa-rubric.md](references/qa-rubric.md).

### 11. Select and optionally repair once

Select the highest-scoring fully passing candidate. If neither fully passes but one is scientifically usable, select the strongest best-effort candidate by science fidelity, primary-capability fidelity, proposal specificity, passed gates, reviewer recovery, and total score.

Use at most one built-in Image Edit, and only for visible text or one localized color or contained-region defect. Load the selected local PNG first, preserve every passed region, save the edit as a new file, and rerun every gate. A wrong funding thesis, capability, topology, endpoint, density, or overall style is structural and is not repairable here.

If visible text remains after the one edit, do not present that raster as a successful draft. Never claim a failed gate passed.

### 12. Finalize and deliver one artifact

After both evaluation files are complete, run:

```bash
python3 "<skill-root>/scripts/finalize_run.py" --run-dir "<run-dir>"
```

Confirm that `final/` contains exactly one PNG. Render only that image inline and provide its absolute path. Begin the handoff with `AI-generated Figure 1 collaboration draft — not final`.

Then add `Color roles in this draft:` with three to five short bullets grounded in the actual raster and source lock, accounting for Vision, Gap, Objectives, Approach, and Impact. State shared carriers honestly and do not invent unmeasured hex values.

Add `Remaining review items:` with at most three short bullets. Researcher interpretation, graphic-designer redraw, and scientist/content-owner verification remain required. Do not expose the source lock, semantic capsule, prompts, reference filename, scorecard, alternate, caption, or full QA table unless the user asks.

## Stop conditions

Stop without generation when a substantive source cannot be read, source support is missing, quote verification fails, pre-generation validation fails, prompt validation fails, or built-in image generation is unavailable.

After generation, withhold successful delivery when no usable PNG exists, the image is corrupt, text remains after the single permitted repair, science reconciliation fails, or finalization cannot produce exactly one selected PNG. Record and disclose failures accurately.
