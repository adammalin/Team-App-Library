# Bundled style references

These four PNGs are approved style-example material for this collaboration-draft workflow:

- `ref-a-transformation-separation.png`
- `ref-b-integration-validation-return.png`
- `ref-c-central-capability-branching.png`
- `ref-d-multiscale-mechanism-iteration.png`

They demonstrate a label-free, matte flat-2D scientific-editorial family: white field, large color-coordinated forms, clear connectors, generous negative space, and strong thumbnail hierarchy.

They are never scientific authorities or content templates. Do not copy their science, topology, icons, claims, endpoints, evidence, labels, device details, schedules, or logos. Select one only after the attached proposal has established its own source-supported topology.
