# Source-locked analysis contracts

Complete the initialized JSON files before generation. Use exact proposal wording where required. Use `NOT SUPPORTED` rather than inventing missing content.

## `source-lock.json`

Required fields:

```json
{
  "status": "pass",
  "proposal_title": "",
  "distinctive_terms": ["", "", "", ""],
  "scientific_vision": "",
  "scientific_system": "",
  "consequential_gap": "",
  "objectives": [""],
  "primary_capability": "",
  "decisive_relationship": "",
  "validation_logic": "",
  "scientific_endpoint": "",
  "doe_payoff": "",
  "strengths": ["", ""],
  "secondary_methods": [
    {"name": "", "limited_role": ""}
  ],
  "allowed_subjects": [""],
  "allowed_relationships": [""],
  "forbidden_inferences": [""],
  "evidence": [
    {
      "claim_id": "C01",
      "claim": "",
      "exact_quote": "",
      "section": ""
    }
  ]
}
```

Map every substantive field to at least one evidence entry. Preserve promised research versus achieved results. Do not broaden DOE relevance beyond supplied funding language.

After completing this file, run `verify_source_quotes.py`. It must verify every normalized exact quotation against the current source hash without archiving a full text copy of the proposal.

## `science-verification.json`

Required fields:

```json
{
  "status": "pass",
  "proposal_identity_checksum": {
    "scientific_system": "",
    "primary_capability": "",
    "decisive_relationship": "",
    "validation_logic": "",
    "scientific_endpoint": "",
    "doe_payoff": ""
  },
  "renderer_capsule": {
    "SYSTEM": "",
    "PRIMARY CAPABILITY": "",
    "DECISIVE RELATIONSHIP": "",
    "ENDPOINT": "",
    "DO NOT SUBSTITUTE": ""
  },
  "claim_evidence_matrix": [
    {"planned_item": "", "claim_id": "C01"}
  ],
  "prohibited_substitutions": [""],
  "secondary_method_suppression_pass": true,
  "interchangeability_test_pass": true
}
```

Copy the first four renderer-capsule values from the verified identity without creative rewriting. Make `DO NOT SUBSTITUTE` proposal-specific, including attractive but incorrect secondary methods and endpoints.

## `funding-case.json`

Required fields:

```json
{
  "status": "pass",
  "funding_thesis": "",
  "reviewer_answers": {
    "fundamental_advancement": "",
    "why_it_should_work": "",
    "credibility": "",
    "doe_or_sponsor_payoff": ""
  },
  "strengths": ["", ""]
}
```

Use this as internal decision logic, not visible image copy.

## `visual-brief.json`

Required fields:

```json
{
  "status": "pass",
  "proposal_native_topology": "",
  "spatial_blueprint": [
    {
      "id": "REGION_1",
      "semantic_anchor": "PRIMARY CAPABILITY",
      "claim_id": "C01",
      "geometry": ""
    }
  ],
  "color_role_ledger": {
    "VISION": {"scientific_meaning": "", "claim_id": "C01", "visual_carrier": "", "color_family": "pale sage"},
    "GAP": {"scientific_meaning": "", "claim_id": "C02", "visual_carrier": "", "color_family": "orange-red"},
    "OBJECTIVES": {"scientific_meaning": "", "claim_id": "C03", "visual_carrier": "", "color_family": "purple"},
    "APPROACH": {"scientific_meaning": "", "claim_id": "C04", "visual_carrier": "", "color_family": "warm orange"},
    "IMPACT": {"scientific_meaning": "", "claim_id": "C05", "visual_carrier": "", "color_family": "cyan or teal"}
  },
  "validation_relationship_cue": {"scientific_meaning": "", "claim_id": "C06", "geometry": ""},
  "style_reference": {
    "archetype": "A|B|C|D|PROPOSAL_NATIVE|USER_SUPPLIED",
    "asset": "relative packaged path, supplied path, or NONE",
    "style_only": true,
    "transfer": [""],
    "prohibited_transfer": [""]
  },
  "allowed_text": [],
  "allowed_visuals": [""],
  "must_preserve": [""],
  "forbidden": [""],
  "companion_transfer": [],
  "companion_prohibited_transfer": [],
  "logo_state": "OMIT",
  "canvas": {"width": 1536, "height": 1024},
  "candidate_count": 2,
  "final_artifact_count": 1,
  "repair_ceiling": 1
}
```

Keep every geometry item linked to a semantic anchor and evidence claim. Use a white or very light field and a restrained palette unless an approved companion establishes another role system.

`allowed_text` must equal the empty list. Every five-role ledger entry needs a source-supported meaning, claim id, visible carrier, and color family. Validation must be encoded as a relationship cue rather than a sixth label. Select the style reference only after the proposal-native topology is frozen.

## `execution-contract.json`

Required fields:

```json
{
  "status": "pass",
  "semantic_capsule": {
    "SYSTEM": "",
    "PRIMARY CAPABILITY": "",
    "DECISIVE RELATIONSHIP": "",
    "ENDPOINT": "",
    "DO NOT SUBSTITUTE": ""
  },
  "only_allowed_text": [],
  "color_role_ledger": {},
  "validation_relationship_cue": {},
  "style_reference": {},
  "allowed_visuals": [""],
  "logo_state": "OMIT",
  "must_preserve": [""],
  "forbidden": [""],
  "output": {
    "candidate_count": 2,
    "final_artifact_count": 1,
    "format": "PNG",
    "artifact_type": "raster",
    "width": 1536,
    "height": 1024,
    "opacity": "opaque"
  },
  "repair_ceiling": 1
}
```

Copy fields without creative rewriting from `science-verification.json` and `visual-brief.json`. The pre-generation validator checks exact equality and rejects a stale or improvised contract. `only_allowed_text` must equal `[]`.

## Palette and allowed-text files

Write `palette.json` as a JSON list of approved hex colors. When no companion establishes a different system, use this flexible collaboration-draft palette as a diagnostic reference:

```json
["#FFFFFF", "#C8DCCB", "#F15A24", "#8B5FBF", "#F5A623", "#56C7D9", "#178F86", "#164A6A", "#373A36"]
```

These hex values are not mandatory rendering targets; they help the raster inspector identify extreme palette drift. For ORNL work, an approved companion or the installed ORNL brand skill may establish another cohesive palette while preserving the five semantic roles. Write `allowed-text.json` as exactly `[]`.
