# ORNL brand and companion-figure controls

Use the installed ORNL brand skill as the authority. Treat every generated Figure 1 as a draft pending scientific, content-owner, and appropriate brand review.

## Default expression

Use a balanced scientific-editorial expression unless the user or approved companion establishes another direction:

- ORNL Green `#00662C` as the recognition anchor without flooding the image;
- Hale Navy `#00454D`, Polar `#FFFFFF`, Graphite `#DBDCDB`, and Dark Matter `#373A36` for structure;
- Aqua `#00BDB5` or one other purposeful secondary role when useful; and
- at most one restrained accent such as Forge `#FF9E1B`, with combined accents below 25%.

Use square 90-degree corners for every brand-created container. Prefer one strong visual hierarchy, selective color, clean alignment, and generous space. Do not force hexagons, gradients, or a logo.

## Companion transfer

Extract and record only:

- palette roles;
- type character or hierarchy roles;
- line weights;
- arrow or connector language;
- icon treatment;
- spacing and grid; and
- overall tone.

Prohibit transfer of science, labels, claims, schedule, data, dates, tasks, milestones, results, partner marks, logos, and incidental copy.

The proposal remains the sole content authority. A Roadmap may establish visual style but never Figure 1 science or sequencing.

## Typography and marks

Visible text is always `NONE`, so no production typeface is requested or imitated. Keep every role name and color explanation in the chat handoff.

Default the logo state to `OMIT`. Use only supplied approved production artwork, composited after generation, when the user explicitly requires a logo. Never ask the image model to recreate the ORNL logo or oak leaf.

## Content fidelity

Do not invent ORNL slogans, claims, facilities, scientific methods, results, qualifiers, scores, URLs, identifiers, or official language. Brand alignment never substitutes for content authorization.
