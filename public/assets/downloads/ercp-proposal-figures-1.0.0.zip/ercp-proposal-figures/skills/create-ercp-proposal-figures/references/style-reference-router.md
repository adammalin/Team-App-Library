# Style-reference DNA and proposal-topology router

## Purpose

Use the four bundled PNGs as visual-style examples, never as scientific authorities or reusable content templates. The proposal remains the sole authority for science, claims, topology, endpoints, and sponsor value.

## Bundled references

- `assets/style-references/ref-a-transformation-separation.png`: transformation, filtering, sorting, or separation through one continuous field.
- `assets/style-references/ref-b-integration-validation-return.png`: integration through a central capability with a source-supported return path or comparison.
- `assets/style-references/ref-c-central-capability-branching.png`: one dominant capability resolving or distributing into distinct scientific outcomes.
- `assets/style-references/ref-d-multiscale-mechanism-iteration.png`: coupled scales, boundaries, interfaces, or mechanisms linked through source-supported iteration.

Choose after writing the proposal-native topology. Use exactly one closest reference as the primary visual example. A second may inform only one narrow treatment such as connector language or spacing. If none fits, record `PROPOSAL_NATIVE` and use the written visual DNA.

When the image tool accepts local references, pass the selected PNG as style-example material. Transfer only its matte flat-2D construction, white field, large color regions, connector language, stroke consistency, negative space, hierarchy, and polish. Never transfer its science, topology, icons, labels, claims, endpoint, evidence, device details, schedule, or logo.

## Shared visual DNA

- one opaque 1536 × 1024 landscape PNG;
- pure white or near-white background;
- zero visible text or pseudo-text;
- one continuous scientific narrative;
- three to five major color regions with one dominant relationship;
- large proposal-specific forms rather than many small icons;
- solid matte fills using one or two flat tones per color family;
- crisp boundaries, consistent strokes, and clear connectors;
- generous negative space and strong thumbnail readability; and
- a scientific state, capability, or understanding as the endpoint, never a generic success badge.

Reject perspective, receding planes, glow, directional lighting, transparency haze, particle spray, texture, hairline contour fields, glossy or depth-creating gradients, depth, 3D, photorealism, and scientific-rendering aesthetics. Subtle non-directional tonal variation within one color family may follow the approved examples when it still reads as a matte flat-2D shape and does not create volume, glass, illumination, or spatial depth.

## Five-role semantic color system

| Proposal role | Wireframe cue | Source-supported meaning |
|---|---|---|
| Vision | pale sage | desired organizing state or future scientific capability |
| Gap | orange-red | consequential limitation, missing access, unresolved mixture, or disorder |
| Objectives | purple | what must be discovered, resolved, compared, or proven |
| Approach | warm orange or gold | distinctive hypothesis, intervention, measurement, or integration capability |
| Impact | cyan, blue, or teal | scientific endpoint and source-supported DOE or sponsor value |

These are semantic cues, not mandatory final hex values. Translate them into one cohesive palette. Every role needs a visible carrier; share a family only when two roles are scientifically inseparable, and disclose that in chat.

Validation is not a sixth label or required sixth color. Encode credibility as a proposal-supported return path, recurrence, comparison, matched endpoint, selective convergence, or repeated agreement.

## Routing checks

Use A when the decisive relationship transforms an unresolved field into differentiated mechanisms, states, classes, or predictions.

Use B when multiple sources or scales are integrated and credibility depends on a real comparison or return path.

Use C when one central detector, measurement capability, hypothesis, or framework reveals several distinct outcomes while secondary analysis remains subordinate.

Use D when a boundary, interface, coupled scale, or mechanism connects observation and understanding through a real iterative relationship.

Fail the routing gate when an archetype is chosen before the topology, when reference science appears in the planned figure, or when the resulting composition remains plausible after swapping in unrelated proposal nouns.
