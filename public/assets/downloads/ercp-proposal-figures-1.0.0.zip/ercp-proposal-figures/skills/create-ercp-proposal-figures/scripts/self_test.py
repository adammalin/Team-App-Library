#!/usr/bin/env python3
"""Exercise the Figure 1 run contract with fictional text and a synthetic PNG."""

from __future__ import annotations

import hashlib
import json
import shutil
import struct
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
SOURCE = ROOT / "assets" / "fictional-fluxweave-proposal.md"

HARD_GATES = (
    "attachment_grounding",
    "science_fidelity",
    "primary_capability_fidelity",
    "secondary_method_suppression",
    "decisive_relationship_visible",
    "scientific_endpoint_visible",
    "claim_evidence_reconciliation",
    "closed_text_inventory",
    "five_role_color_fidelity",
    "style_reference_boundary",
    "no_fabricated_evidence",
    "no_roadmap_logic",
    "no_unauthorized_marks",
    "no_generic_template_or_stock_metaphor",
    "flat_scientific_editorial_style",
    "one_dominant_hierarchy",
    "thumbnail_reviewer_test",
    "graphic_designer_handoff_value",
)

SCORES = (
    "science_fidelity",
    "primary_capability_fidelity",
    "proposal_specificity",
    "funding_story",
    "sponsor_value",
    "credibility_without_fake_evidence",
    "visual_hierarchy",
    "label_free_compliance",
    "graphic_designer_handoff_value",
)


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def run(command: list[str], expect: int = 0) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    if result.returncode != expect:
        raise RuntimeError(
            f"unexpected exit {result.returncode}, expected {expect}: {' '.join(command)}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def png_chunk(kind: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)


def write_synthetic_png(path: Path) -> None:
    width, height = 1536, 1024
    white = bytes((255, 255, 255)) * width
    green = bytes((0, 102, 44)) * width
    scanlines = b"".join(b"\x00" + (green if 384 <= y < 640 else white) for y in range(height))
    data = (
        b"\x89PNG\r\n\x1a\n"
        + png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
        + png_chunk(b"IDAT", zlib.compress(scanlines, level=9))
        + png_chunk(b"IEND", b"")
    )
    path.write_bytes(data)


def inspect_and_label(run_dir: Path, stem: str) -> None:
    candidate = run_dir / "candidates" / f"{stem}.png"
    metrics = run_dir / "candidates" / f"{stem}.metrics.json"
    ocr = run_dir / "candidates" / f"{stem}.ocr.json"
    labels = run_dir / "candidates" / f"{stem}.labels.json"
    write_synthetic_png(candidate)
    run(
        [
            sys.executable,
            str(SCRIPTS / "inspect_raster.py"),
            "--image",
            str(candidate),
            "--out",
            str(metrics),
            "--palette-json",
            str(run_dir / "analysis" / "palette.json"),
        ]
    )
    run([sys.executable, str(SCRIPTS / "ocr_portable.py"), "--image", str(candidate), "--out", str(ocr)])
    ocr_result = json.loads(ocr.read_text(encoding="utf-8"))
    if ocr_result.get("available") is True:
        run(
            [
                sys.executable,
                str(SCRIPTS / "verify_labels.py"),
                "--ocr",
                str(ocr),
                "--allowed",
                str(run_dir / "analysis" / "allowed-text.json"),
                "--out",
                str(labels),
            ]
        )
    else:
        write_json(
            labels,
            {
                "status": "pass",
                "image": str(candidate.resolve()),
                "verification_mode": "codex-visual-inspection-fixture",
                "allowed_text": [],
                "recognized_text": [],
            },
        )


def populate_analysis(run_dir: Path) -> None:
    scientific_system = "Transient interfacial disorder and coupled heat and charge transport across layered quantum interfaces"
    primary_capability = "Synchronized ultrafast structural and transport mapping across the same interface"
    decisive_relationship = "Recurring structural motifs create identifiable transport corridors, and a timed strain pulse selectively strengthens or suppresses those corridors"
    validation_logic = "Recurrence of the same motif–transport relationship across repeated interface preparations"
    endpoint = "A source-supported map connecting transient interfacial motifs to directional transport response"
    payoff = "A mechanistic basis for designing energy-relevant quantum interfaces whose transport behavior can be deliberately tuned rather than observed only after averaging"
    strengths = [
        "The same interface is observed structurally and electronically on synchronized time scales.",
        "The proposed recurrence test links a transient visual feature to an independently measured transport response without claiming a result in advance.",
    ]
    claims = [
        ("C1", "scientific system", "FLUXWEAVE will establish how transient interfacial disorder redirects coupled heat and charge transport across layered quantum interfaces.", "Scientific vision"),
        ("C2", "consequential gap", "Existing measurements average over the brief interval in which interfacial disorder forms, propagates, and reorganizes.", "Consequential gap"),
        ("C3", "primary capability", "The central capability is synchronized ultrafast structural and transport mapping across the same interface.", "Primary capability and hypothesis"),
        ("C4", "decisive relationship", "The hypothesis is that recurring structural motifs create identifiable transport corridors, and that a timed strain pulse selectively strengthens or suppresses those corridors.", "Primary capability and hypothesis"),
        ("C5", "comparison approach", "The project will compare synchronized measurements before, during, and after the strain pulse across repeated interface preparations.", "Approach and credibility"),
        ("C6", "validation logic", "Recurrence of the same motif–transport relationship across preparations provides the proposed credibility check.", "Approach and credibility"),
        ("C7", "secondary method limit", "Pattern classification is limited to locating recurring motifs; it is not the scientific engine.", "Approach and credibility"),
        ("C8", "scientific endpoint", "The endpoint is a source-supported map connecting transient interfacial motifs to directional transport response.", "Scientific endpoint and DOE relevance"),
        ("C9", "DOE payoff", "This relationship would provide a mechanistic basis for designing energy-relevant quantum interfaces whose transport behavior can be deliberately tuned rather than observed only after averaging.", "Scientific endpoint and DOE relevance"),
        ("C10", "strength one", strengths[0], "Expected strengths"),
        ("C11", "strength two", strengths[1], "Expected strengths"),
    ]
    source = {
        "status": "pass",
        "proposal_title": "FLUXWEAVE: Reversible Thermal Transport in Porous Interfaces",
        "distinctive_terms": ["FLUXWEAVE", "reciprocal", "porous interface", "localization"],
        "scientific_vision": "Establish how transient interfacial disorder redirects coupled heat and charge transport across layered quantum interfaces.",
        "scientific_system": scientific_system,
        "consequential_gap": "Existing measurements obscure the transient interval and leave structural rearrangement versus directional transport unresolved.",
        "objectives": [
            "Resolve how recurring structural motifs connect to directional transport response.",
            "Test how a timed strain pulse selectively strengthens or suppresses transport corridors.",
        ],
        "primary_capability": primary_capability,
        "decisive_relationship": decisive_relationship,
        "validation_logic": validation_logic,
        "scientific_endpoint": endpoint,
        "doe_payoff": payoff,
        "strengths": strengths,
        "secondary_methods": [{"name": "Pattern classification", "limited_role": "Locating recurring motifs only"}],
        "allowed_subjects": ["layered quantum interface", "recurring structural motifs", "transport corridors", "timed strain pulse"],
        "allowed_relationships": [decisive_relationship, validation_logic],
        "forbidden_inferences": ["no achieved result", "no fabricated transport value", "no generic AI pipeline"],
        "evidence": [
            {"claim_id": claim_id, "claim": claim, "exact_quote": quote, "section": section}
            for claim_id, claim, quote, section in claims
        ],
    }
    write_json(run_dir / "analysis" / "source-lock.json", source)
    write_json(
        run_dir / "analysis" / "science-verification.json",
        {
            "status": "pass",
            "proposal_identity_checksum": {
                "scientific_system": scientific_system,
                "primary_capability": primary_capability,
                "decisive_relationship": decisive_relationship,
                "validation_logic": validation_logic,
                "scientific_endpoint": endpoint,
                "doe_payoff": payoff,
            },
            "renderer_capsule": {
                "SYSTEM": scientific_system,
                "PRIMARY CAPABILITY": primary_capability,
                "DECISIVE RELATIONSHIP": decisive_relationship,
                "ENDPOINT": endpoint,
                "DO NOT SUBSTITUTE": "Do not replace synchronized motif–transport logic with pattern classification, steady-state averaging, a generic pipeline, or a dashboard",
            },
            "claim_evidence_matrix": [
                {"claim_id": f"C{index}", "planned_item": item}
                for index, item in enumerate(
                    ["layered interface", "transient disorder gap", "synchronized mapping", "motif–corridor relationship"], 1
                )
            ],
            "prohibited_substitutions": ["pattern classification as engine", "generic funnel", "dashboard"],
            "secondary_method_suppression_pass": True,
            "interchangeability_test_pass": True,
        },
    )
    write_json(
        run_dir / "analysis" / "funding-case.json",
        {
            "status": "pass",
            "funding_thesis": "Fund the capability that exposes how geometry governs reversible local transport.",
            "reviewer_answers": {
                "fundamental_advancement": primary_capability,
                "why_it_should_work": decisive_relationship,
                "credibility": validation_logic,
                "doe_or_sponsor_payoff": payoff,
            },
            "strengths": strengths,
        },
    )
    write_json(
        run_dir / "analysis" / "visual-brief.json",
        {
            "status": "pass",
            "proposal_native_topology": "one layered interface whose recurring motifs align with directional transport corridors while a timed pulse selectively changes corridor emphasis",
            "spatial_blueprint": [
                {"id": "R1", "semantic_anchor": "SYSTEM", "claim_id": "C1", "geometry": "wide layered interface field"},
                {"id": "R2", "semantic_anchor": "PRIMARY CAPABILITY", "claim_id": "C3", "geometry": "paired structural and transport readings anchored to the same interface"},
                {"id": "R3", "semantic_anchor": "DECISIVE RELATIONSHIP", "claim_id": "C4", "geometry": "recurring motifs aligned with selectively emphasized corridors"},
                {"id": "R4", "semantic_anchor": "ENDPOINT", "claim_id": "C8", "geometry": "integrated motif-to-directional-response map"},
            ],
            "color_role_ledger": {
                "VISION": {"scientific_meaning": source["scientific_vision"], "claim_id": "C1", "visual_carrier": "pale outer organizing field", "color_family": "pale sage"},
                "GAP": {"scientific_meaning": source["consequential_gap"], "claim_id": "C2", "visual_carrier": "compressed unresolved interface region", "color_family": "orange-red"},
                "OBJECTIVES": {"scientific_meaning": source["objectives"][0], "claim_id": "C4", "visual_carrier": "paired motif and corridor forms", "color_family": "purple"},
                "APPROACH": {"scientific_meaning": primary_capability, "claim_id": "C3", "visual_carrier": "central synchronized mapping region", "color_family": "warm orange"},
                "IMPACT": {"scientific_meaning": payoff, "claim_id": "C9", "visual_carrier": "integrated endpoint field", "color_family": "cyan or teal"},
            },
            "validation_relationship_cue": {"scientific_meaning": validation_logic, "claim_id": "C6", "geometry": "matched return connectors across repeated preparations"},
            "style_reference": {
                "archetype": "B",
                "asset": "assets/style-references/ref-b-integration-validation-return.png",
                "style_only": True,
                "transfer": ["matte flat 2D construction", "white field", "uniform connector weight"],
                "prohibited_transfer": ["reference science", "reference topology", "reference icons", "reference claims"],
            },
            "allowed_text": [],
            "allowed_visuals": ["layered interface", "recurring motifs", "transport corridors", "timed pulse", "integrated endpoint map"],
            "must_preserve": ["same-interface coupling", "motif–corridor relationship", "white field"],
            "forbidden": ["extra text", "logo", "timeline", "dashboard", "3D effects"],
            "companion_transfer": [],
            "companion_prohibited_transfer": [],
            "logo_state": "OMIT",
            "canvas": {"width": 1536, "height": 1024},
            "candidate_count": 2,
            "final_artifact_count": 1,
            "repair_ceiling": 1,
        },
    )
    write_json(run_dir / "analysis" / "allowed-text.json", [])
    write_json(
        run_dir / "analysis" / "execution-contract.json",
        {
            "status": "pass",
            "semantic_capsule": {
                "SYSTEM": scientific_system,
                "PRIMARY CAPABILITY": primary_capability,
                "DECISIVE RELATIONSHIP": decisive_relationship,
                "ENDPOINT": endpoint,
                "DO NOT SUBSTITUTE": "Do not replace synchronized motif–transport logic with pattern classification, steady-state averaging, a generic pipeline, or a dashboard",
            },
            "only_allowed_text": [],
            "color_role_ledger": {
                "VISION": {"scientific_meaning": source["scientific_vision"], "claim_id": "C1", "visual_carrier": "pale outer organizing field", "color_family": "pale sage"},
                "GAP": {"scientific_meaning": source["consequential_gap"], "claim_id": "C2", "visual_carrier": "compressed unresolved interface region", "color_family": "orange-red"},
                "OBJECTIVES": {"scientific_meaning": source["objectives"][0], "claim_id": "C4", "visual_carrier": "paired motif and corridor forms", "color_family": "purple"},
                "APPROACH": {"scientific_meaning": primary_capability, "claim_id": "C3", "visual_carrier": "central synchronized mapping region", "color_family": "warm orange"},
                "IMPACT": {"scientific_meaning": payoff, "claim_id": "C9", "visual_carrier": "integrated endpoint field", "color_family": "cyan or teal"},
            },
            "validation_relationship_cue": {"scientific_meaning": validation_logic, "claim_id": "C6", "geometry": "matched return connectors across repeated preparations"},
            "style_reference": {
                "archetype": "B",
                "asset": "assets/style-references/ref-b-integration-validation-return.png",
                "style_only": True,
                "transfer": ["matte flat 2D construction", "white field", "uniform connector weight"],
                "prohibited_transfer": ["reference science", "reference topology", "reference icons", "reference claims"],
            },
            "allowed_visuals": ["layered interface", "recurring motifs", "transport corridors", "timed pulse", "integrated endpoint map"],
            "logo_state": "OMIT",
            "must_preserve": ["same-interface coupling", "motif–corridor relationship", "white field"],
            "forbidden": ["extra text", "logo", "timeline", "dashboard", "3D effects"],
            "output": {
                "candidate_count": 2,
                "final_artifact_count": 1,
                "format": "PNG",
                "artifact_type": "raster",
                "width": 1536,
                "height": 1024,
                "opacity": "opaque",
            },
            "repair_ceiling": 1,
        },
    )


def write_candidate_prompts(run_dir: Path) -> None:
    contract = json.loads((run_dir / "analysis" / "execution-contract.json").read_text(encoding="utf-8"))
    capsule = "\n".join(f"{key}: {value}" for key, value in contract["semantic_capsule"].items())
    allowed_visuals = "\n".join(f"- {value}" for value in contract["allowed_visuals"])
    must_preserve = "\n".join(f"- {value}" for value in contract["must_preserve"])
    forbidden = "\n".join(f"- {value}" for value in contract["forbidden"])
    ledger = "\n".join(
        f"{role}: {entry['color_family']} | {entry['visual_carrier']} | {entry['scientific_meaning']}"
        for role, entry in contract["color_role_ledger"].items()
    )
    validation = contract["validation_relationship_cue"]
    style_reference = contract["style_reference"]
    transfer = "\n".join(f"- {value}" for value in style_reference["transfer"])
    prohibited_transfer = "\n".join(f"- {value}" for value in style_reference["prohibited_transfer"])
    shared = f"""NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. COMPLETELY TEXT-FREE MATTE FLAT 2D VECTOR-STYLE RASTER PNG.

Use case: scientific-educational
Asset type: fictional DOE proposal Figure 1 raster concept draft

SEMANTIC CONTEXT — DO NOT RENDER AS TEXT
{capsule}

REFERENCE ROLE — STYLE ONLY — DO NOT RENDER AS TEXT
ARCHETYPE: {style_reference['archetype']}
TRANSFER:
{transfer}
PROHIBITED TRANSFER:
{prohibited_transfer}

FIVE-ROLE COLOR LEDGER — DO NOT RENDER AS TEXT
{ledger}
VALIDATION RELATIONSHIP CUE: {validation['scientific_meaning']} | {validation['geometry']}

ABSOLUTELY NO LETTERS, WORDS, NUMERALS, UNITS, SYMBOL LABELS, PSEUDO-TEXT, TITLES, LEGENDS, OR CAPTIONS ANYWHERE.

ALLOWED VISUALS
{allowed_visuals}

MUST PRESERVE
{must_preserve}

ONLY ALLOWED VISIBLE TEXT
NONE

ABSOLUTELY NO LETTERS, WORDS, NUMERALS, UNITS, SYMBOL LABELS, PSEUDO-TEXT, TITLES, LEGENDS, OR CAPTIONS ANYWHERE.

STYLE
Flat scientific-editorial raster; no logo.

FORBIDDEN
{forbidden}

OUTPUT
One opaque landscape raster PNG, 1536 × 1024.
One image only.
"""
    (run_dir / "prompts" / "candidate-a.txt").write_text(
        shared + "\nSPATIAL ENCODING\nContinuous same-interface motif and corridor alignment.\n\nNEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.\n",
        encoding="utf-8",
    )
    (run_dir / "prompts" / "candidate-b.txt").write_text(
        shared + "\nSPATIAL ENCODING\nNested motif recurrence around a selective corridor field.\n\nNEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.\n",
        encoding="utf-8",
    )


def main() -> int:
    if not SOURCE.is_file():
        raise SystemExit(f"fixture source is missing: {SOURCE}")
    with tempfile.TemporaryDirectory(prefix="ercp-figure-1-self-test-") as temporary:
        run_dir = Path(temporary) / "run"
        run(
            [
                sys.executable,
                str(SCRIPTS / "init_run.py"),
                "--run-dir",
                str(run_dir),
                "--source",
                str(SOURCE),
                "--companion-status",
                "none",
            ]
        )
        run([sys.executable, str(SCRIPTS / "validate_run.py"), "--run-dir", str(run_dir)], expect=1)
        populate_analysis(run_dir)
        run([sys.executable, str(SCRIPTS / "verify_source_quotes.py"), "--run-dir", str(run_dir)])
        run([sys.executable, str(SCRIPTS / "validate_run.py"), "--run-dir", str(run_dir)])
        write_candidate_prompts(run_dir)
        run([sys.executable, str(SCRIPTS / "validate_prompts.py"), "--run-dir", str(run_dir)])

        inspect_and_label(run_dir, "candidate-a")
        inspect_and_label(run_dir, "candidate-b")
        candidate = run_dir / "candidates" / "candidate-a.png"

        mismatch_ocr = run_dir / "validation" / "mismatch-ocr.json"
        mismatch_report = run_dir / "validation" / "mismatch-labels.json"
        write_json(
            mismatch_ocr,
            {
                "available": True,
                "verification_mode": "deterministic-local-ocr",
                "image": str(candidate.resolve()),
                "observations": [{"text": "UNAUTHORIZED", "confidence": 1.0}],
            },
        )
        run(
            [
                sys.executable,
                str(SCRIPTS / "verify_labels.py"),
                "--ocr",
                str(mismatch_ocr),
                "--allowed",
                str(run_dir / "analysis" / "allowed-text.json"),
                "--out",
                str(mismatch_report),
            ],
            expect=1,
        )

        evaluation = {
            "candidate_id": "A",
            "artifact": "candidates/candidate-a.png",
            "metrics": "candidates/candidate-a.metrics.json",
            "labels_report": "candidates/candidate-a.labels.json",
            "status": "fail",
            "hard_gates": {name: name != "flat_scientific_editorial_style" for name in HARD_GATES},
            "reviewer_test": {
                "fundamental_advancement": True,
                "why_it_should_work": True,
                "credibility": True,
                "doe_or_sponsor_payoff": True,
                "proposal_specific_strengths": ["reciprocal field logic", "geometry-linked endpoint"],
            },
            "actual_color_role_ledger": {
                role: {"visible_family": "green or white", "carrier": "synthetic test field", "source_support": "fictional fixture"}
                for role in ("VISION", "GAP", "OBJECTIVES", "APPROACH", "IMPACT")
            },
            "scores": {name: 3.8 for name in SCORES},
            "repairable_issue": None,
            "selection_reason": "fictional self-test candidate",
        }
        write_json(run_dir / "evaluations" / "candidate-a.json", evaluation)
        rejected = {
            "candidate_id": "B",
            "artifact": "candidates/candidate-b.png",
            "metrics": "candidates/candidate-b.metrics.json",
            "labels_report": "candidates/candidate-b.labels.json",
            "status": "fail",
            "hard_gates": {name: name != "no_generic_template_or_stock_metaphor" for name in HARD_GATES},
            "reviewer_test": {
                "fundamental_advancement": True,
                "why_it_should_work": True,
                "credibility": True,
                "doe_or_sponsor_payoff": False,
                "proposal_specific_strengths": ["reciprocal field logic", "geometry-linked endpoint"],
            },
            "actual_color_role_ledger": {
                role: {"visible_family": "green or white", "carrier": "synthetic test field", "source_support": "fictional fixture"}
                for role in ("VISION", "GAP", "OBJECTIVES", "APPROACH", "IMPACT")
            },
            "scores": {name: 3.0 for name in SCORES},
            "repairable_issue": None,
            "selection_reason": "generic fictional layout rejected",
        }
        write_json(run_dir / "evaluations" / "candidate-b.json", rejected)
        run([sys.executable, str(SCRIPTS / "finalize_run.py"), "--run-dir", str(run_dir)])

        final_files = list((run_dir / "final").iterdir())
        if [path.name for path in final_files] != ["ercp-figure-1-draft.png"]:
            raise RuntimeError(f"unexpected final files: {final_files}")
        if hashlib.sha256(final_files[0].read_bytes()).hexdigest() != hashlib.sha256(candidate.read_bytes()).hexdigest():
            raise RuntimeError("final artifact is not byte-identical to the selected source raster")
        finalization = json.loads((run_dir / "validation" / "finalization.json").read_text(encoding="utf-8"))
        if finalization.get("status") != "best_effort" or finalization.get("qualification_pass") is not False:
            raise RuntimeError(f"failed candidates did not produce a best-effort handoff: {finalization}")
        if not finalization.get("remaining_issues"):
            raise RuntimeError("best-effort handoff did not record remaining issues")

    print("RESULT | PASS | ERCP Figure 1 skill self-test completed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
