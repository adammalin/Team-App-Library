# Bundled style references

These seven PNGs are approved style-example material for this collaboration-draft workflow:

- `ref-a-transformation-separation.png`
- `ref-a2-heterogeneous-resolution.png`
- `ref-b-integration-validation-return.png`
- `ref-b2-mapping-feedback-return.png`
- `ref-b3-iterative-control-return.png`
- `ref-c-central-capability-branching.png`
- `ref-d-multiscale-mechanism-iteration.png`

They demonstrate a label-free, matte flat-2D scientific-editorial family: white field, large color-coordinated forms, clear connectors, generous negative space, and strong thumbnail hierarchy. The image model may learn those surface qualities, but the current proposal supplies the science and the canonical five-role system supplies the colors.

They are never scientific authorities or content templates. Do not copy their science, topology, icons, claims, endpoints, evidence, labels, device details, schedules, logos, brand treatment, or original palette assignments. Select one only after the attached proposal has established its own source-supported topology.
