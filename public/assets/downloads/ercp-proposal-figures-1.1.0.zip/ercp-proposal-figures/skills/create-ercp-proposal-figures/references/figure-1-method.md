# DOE Figure 1 decision-aid method

## Purpose

Treat Figure 1 as the proposal’s front door and visual funding case. Make the reviewer understand the fundamental advancement, why it should work, what makes it credible, and why the scientific outcome matters to DOE or the sponsor.

Produce a decision aid, not a manuscript figure, objective list, methods inventory, Roadmap, dashboard, poster, or decorated abstract.

## Source-first build order

1. Read the substantive proposal.
2. Extract the scientific vision, consequential gap, central capability or hypothesis, decisive relationship, credibility or validation logic, endpoint, DOE payoff, and two strengths.
3. Preserve an exact source passage and section for every substantive claim.
4. Separate primary capability from secondary methods and their limited roles.
5. Name plausible but wrong substitute stories for this proposal.
6. Write the source-bounded funding thesis and four reviewer answers.
7. Derive one proposal-native topology.
8. Freeze the empty text inventory, allowed visuals, five-role color carriers, invariants, and forbidden content.
9. Generate, inspect, select, repair once if localized, and deliver one PNG.

## Proposal-native topology

Derive spatial organization from the proposal’s distinctive relationship, not from a template menu. Possible relationships include coupling, comparison, coverage across scales, nested structure, recurrence, selective intervention, emergence, constraint, integration, or another source-supported logic.

Do not default to:

- challenge → capability → impact;
- current → proposed;
- left → center → right;
- funnel or convergence;
- feedback or learning loop;
- equal objective cards;
- a terminal target;
- a methods strip; or
- a detached impact band.

Use such a structure only when it is literally central to the proposal. The resulting topology must become scientifically wrong when transplanted to another proposal.

## Thirty-second reviewer test

At thumbnail size, require recovery of:

1. the fundamental advancement;
2. why the approach or hypothesis should work;
3. what makes success credible without invented evidence;
4. the source-supported scientific or sponsor payoff; and
5. at least two proposal-specific strengths.

Reject a figure whose nouns could be swapped for another proposal while preserving the same story.

## No-text strategy

The raster is completely label-free. Never add labels, sentences, paragraphs, title blocks, subtitles, captions, bullets, rubric headings, acronyms, numerals, axes, legends, units, glyphs, pseudo-text, or visible QA language.

Carry scientific specificity through proposal-native form, topology, color roles, boundary behavior, continuity, separation, recurrence, or connectors. Explain the actual Vision, Gap, Objectives, Approach, and Impact color carriers only in chat after inspecting the raster.

## Visual language

Use one dominant hierarchy, a few large forms, generous negative space, and a clean scientific-editorial raster style that a graphic designer can recreate in Illustrator.

Prefer solid or subtly varied same-family fills, crisp boundaries, consistent strokes, orthographic views, and restrained connectors. The result must remain matte and depthless. Avoid generic stock icons, networks, dashboards, fake charts, literal targets, giant arrows, decorative atoms, brain imagery, glass panels, photorealistic apparatus, glow, bevel, shadow, cinematic light, and invented precision.

Do not fabricate plots, spectra, microscopy, microstructure, molecular structures, measurements, scale bars, facilities, results, or exact-looking evidence. AI may explore concept and composition; humans must verify and professionally redraw before submission.

## Benchmark lessons

- A universal visual grammar failed across heterogeneous proposals.
- Proposal-specific structure improved when the scientific substrate, instrument, interface, or physical relationship drove composition.
- Two internal candidates improved selection by exposing weaker spatial grammars before delivery.
- Zero text improves collaboration-draft economy only when the proposal-native topology and five-role color carriers remain scientifically specific. A generic text-free infographic still fails.
- Abstract data-intensive proposals are especially vulnerable to generic cards, tables, chart axes, and software-dashboard motifs. Build those figures from physical relationships and scientific consequences instead.
- Human figures remain more complete and polished. Treat generated outputs as concept drafts, not replacements for professional design.
