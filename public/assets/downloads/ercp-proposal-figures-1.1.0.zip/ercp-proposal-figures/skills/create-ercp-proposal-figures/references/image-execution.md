# Built-in image execution contracts

## Candidate strategy

Generate exactly two internal candidates with separate built-in image-generation calls. Keep the source support, semantic capsule, five-role color ledger, selected style-only reference, allowed visuals, output contract, and prohibited substitutions identical. Change only the proposal-native spatial expression.

Candidate B must be a genuine alternative expression of the same decisive relationship, not a generic layout or cosmetic rearrangement. Request one image per call.

## Generation prompt structure

Use this order. The first and last lines are exact hard-contract strings.

```text
NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. COMPLETELY TEXT-FREE MATTE FLAT 2D VECTOR-STYLE RASTER PNG.

Use case: scientific-educational
Asset type: DOE Office of Science proposal Figure 1 collaboration draft for graphic-designer redraw
Primary request: Create one proposal-native decision-aid image that visibly depends on the scientific relationship below.

SEMANTIC CONTEXT — DO NOT RENDER AS TEXT
SYSTEM: ...
PRIMARY CAPABILITY: ...
DECISIVE RELATIONSHIP: ...
ENDPOINT: ...
DO NOT SUBSTITUTE: ...

VISUAL BRAND POLICY — DO NOT RENDER AS TEXT
BRAND_NEUTRAL_PROPOSAL_DRAFT
Do not apply or imitate ORNL or any other organization brand. No logo, mark, branded typography, branded geometry, organization-recognition palette, or companion palette.

REFERENCE ROLE — STYLE ONLY — DO NOT RENDER AS TEXT
ARCHETYPE: ...
TRANSFER: ...
PROHIBITED TRANSFER: science, topology, icons, labels, claims, endpoints, data, schedules, and logos

FIVE-ROLE COLOR LEDGER — DO NOT RENDER AS TEXT
VISION: pale sage #C6DCCC | [visible carrier] | [source-supported meaning]
GAP: orange-red #FE5000 | [visible carrier] | [source-supported meaning]
OBJECTIVES: purple #B36CFF | [visible carrier] | [source-supported meaning]
APPROACH: warm orange/gold #FF9E1B | [visible carrier] | [source-supported meaning]
IMPACT: pale cyan/teal #BFD1D3 | [visible carrier] | [source-supported meaning]
VALIDATION RELATIONSHIP CUE: [source-supported relationship and geometry; not a label or sixth color]

ABSOLUTELY NO LETTERS, WORDS, NUMERALS, UNITS, SYMBOL LABELS, PSEUDO-TEXT, TITLES, LEGENDS, OR CAPTIONS ANYWHERE.

PROPOSAL-NATIVE SPATIAL BLUEPRINT
[Counted literal geometry with position, continuity, overlap, separation, branching, recurrence, boundary change, or return path. Three to five major regions.]

ABSOLUTELY NO LETTERS, WORDS, NUMERALS, UNITS, SYMBOL LABELS, PSEUDO-TEXT, TITLES, LEGENDS, OR CAPTIONS ANYWHERE.

ALLOWED VISUALS
[Proposal-supported subjects and relationships only.]

MUST PRESERVE
[Proposal-native topology, hierarchy, exact five-role color assignments, brand-neutral output, negative space, and reference style boundary.]

STYLE
Brand-neutral pure white or near-white field. Straight-on or orthographic matte flat 2D scientific-editorial raster. Three to five large simple silhouette regions. Solid fills using one or two flat tones per canonical family. Crisp simple boundaries. One uniform connector weight. Strong negative space. No logo. Never substitute an organization palette for the five proposal-role colors.

FORBIDDEN
Any science outside the capsule; reference science or icons; generic AI or method imagery; fabricated data or evidence; Roadmap logic; every visible text-like mark; title, caption, panel, card, dashboard, icon row, process strip, detached impact band, badge, giant arrow; ORNL or other organization-brand styling; organization-recognition palette treatment; companion palette; logo; wordmark; brand mark; perspective, receding planes, depth, 3D, glossy or depth-creating gradients, glow, directional lighting, shadow, transparency, mist, blur, particle spray, texture, mesh, grain, hairline contour field, photorealism, scientific-rendering effects, bevel, glass, or watermark.

OUTPUT
One opaque landscape raster PNG, 1536 × 1024.
One image only.
No alternate, comparison, series, SVG, vector data, document, prompt text, or QA text in the artwork.

NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
```

Do not send source quotations, the abstract, intake notes, funding thesis, reviewer questions, filenames, or QA tables to the image tool. Send only the concise semantic capsule, style-only reference role, color ledger, spatial blueprint, allowed visuals, and production constraints.

When a bundled or user-supplied reference PNG is selected, pass its actual local path to the image tool for both calls. State in the prompt that it controls visual language only. Do not claim a reference was used if the tool could not receive or inspect it.

## Suppress renderer shortcuts

- Encode credibility as a source-supported relationship or return path, not a plot, chart, monitor, clipboard, checkmark, shield, award, laboratory row, facility silhouette, or “validated” badge.
- Encode transformation through proposal-native continuity, separation, overlap, recurrence, selective emphasis, or boundary change, not a gear, funnel, database cylinder, dashboard, document stack, icon row, or oversized success arrow.
- Forbid DNA, helix, brain, robot, atom, molecule, microstructure grains, cracks, spectra, microscopy, contour fields, axes, tick marks, thermometers, and scale bars unless the source lock expressly identifies that subject and the visual brief expressly allows that encoding.
- Prefer a few large proposal-specific forms. Avoid many repeated disks or particles unless the source requires them.
- Repeat the most likely wrong substitution beside the spatial instruction where it could occur.

## Localized edit contract

Use one edit only after loading the selected local PNG with the image-viewing capability:

```text
NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
Use case: precise-object-edit
Asset type: DOE proposal Figure 1 raster correction
Primary request: Correct only the localized defect below.

CHANGE: [remove all text, or one localized color or contained-region defect]
PRESERVE EXACTLY: canvas, crop, topology, science, hierarchy, canonical five-role color assignments, brand-neutral output, line work, connectors, negative space, passed regions, and style

SEMANTIC CONTEXT — DO NOT RENDER AS TEXT
[Unchanged five-line semantic capsule]

FORBIDDEN: every other change, addition, substitution, style shift, word, numeral, glyph, mark, or artifact
NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
```

Save the result beside the selected candidate with `-edit-01` in its filename and archive the exact edit prompt. Never overwrite the source candidate. Do not edit a wrong funding thesis, primary capability, decisive relationship, topology, endpoint, density, or overall style.

## Save-path rule

Built-in generation writes under client-managed storage first. Copy each returned original into the run directory before inspection. Preserve original bytes; do not normalize or recompress before hashing and QA.
