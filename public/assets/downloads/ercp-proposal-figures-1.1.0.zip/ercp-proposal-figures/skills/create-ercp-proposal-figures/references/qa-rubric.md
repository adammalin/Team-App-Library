# Figure 1 raster QA and selection rubric

Evaluate the downloaded original raster, not a file card, screenshot, filename, prompt, or model self-report.

## Deterministic hard gates

Require:

- one PNG candidate per generation call;
- valid PNG signature and decodable critical chunks;
- exactly 1536 × 1024 pixels;
- 8-bit RGB or fully opaque RGBA;
- one final file in `final/`;
- SHA-256 and exact original filename archived;
- exact candidate prompts archived and contract-validated before generation;
- empty allowed-text inventory plus OCR or full-size visual inspection finding no visible string or pseudo-text;
- zero forbidden vector, document, or secondary client-facing artifacts; and
- recorded generation mode, prompt, source hash, companion hash when supplied, and repair count.

Treat palette, white-space, and coverage metrics as conservative diagnostics. Fail extreme misses; use visual inspection for tonal variation because image generation may introduce small off-palette variations.

## Visual and scientific hard gates

Every item must be true:

```json
{
  "attachment_grounding": true,
  "science_fidelity": true,
  "primary_capability_fidelity": true,
  "secondary_method_suppression": true,
  "decisive_relationship_visible": true,
  "scientific_endpoint_visible": true,
  "claim_evidence_reconciliation": true,
  "closed_text_inventory": true,
  "five_role_color_fidelity": true,
  "brand_neutral_output": true,
  "style_reference_boundary": true,
  "no_fabricated_evidence": true,
  "no_roadmap_logic": true,
  "no_unauthorized_marks": true,
  "no_generic_template_or_stock_metaphor": true,
  "flat_scientific_editorial_style": true,
  "one_dominant_hierarchy": true,
  "thumbnail_reviewer_test": true,
  "graphic_designer_handoff_value": true
}
```

Inventory every visible string, color family, five-role carrier, and implied subject, relationship, direction, credibility cue, and endpoint. Map them to the source lock and renderer capsule. A plausible but different scientific story is a hard failure. Any visible letter, word, numeral, unit, legend, axis label, glyph, or pseudo-text fails `closed_text_inventory`.

`five_role_color_fidelity` passes only when Vision, Gap, Objectives, Approach, and Impact each have a source-supported visible carrier and remain visibly associated with pale sage `#C6DCCC`, orange-red `#FE5000`, purple `#B36CFF`, warm orange/gold `#FF9E1B`, and pale cyan/teal `#BFD1D3`, respectively. Same-family tonal variation is allowed, but colors may not swap. When roles are scientifically inseparable, retain both colors through overlap, adjacency, or a shared boundary and disclose the shared carrier in chat. Validation remains a relationship cue.

`brand_neutral_output` passes only when the raster avoids ORNL or other organization-brand styling, logos, marks, wordmarks, brand typography, branded geometry, organization-recognition palette treatment, and sponsor-template devices. A color that also appears in a brand palette is allowed only when its carrier clearly serves the fixed five-role proposal system. `style_reference_boundary` passes only when the reference contributes visual language but none of its science, icons, claims, topology, endpoints, data, labels, schedules, marks, palette assignments, or branding.

`flat_scientific_editorial_style` may pass with restrained same-family tonal variation like the bundled examples, provided the composition remains straight-on, matte, and depthless. Fail glossy or directional lighting gradients, volume, transparency haze, glow, shadows, bevel, glass, perspective, or scientific-rendering effects.

## Renderer-shortcut scan

Fail the applicable hard gate by default when the raster uses any of these without express source-lock and visual-brief support:

- chart, axes, trend line, contour, tick marks, thermometer, scale bar, microscopy, spectra, microstructure grains, or cracks;
- shield, checkmark, award, ribbon, giant success arrow, or other stock outcome badge;
- gear, database cylinder, dashboard, monitor, clipboard, document stack, generic laboratory icon, facility silhouette, or icon row standing in for the primary capability or credibility logic; or
- DNA or helix, brain, neural network, atom, molecule, robot, or other domain-confusing metaphor.

Inspect repeated line fragments inside document or table symbols as possible pseudo-text. OCR passing does not excuse visually apparent pseudo-text, fabricated evidence, or a wrong scientific metaphor. A local edit is eligible only when one shortcut is confined to one region and the rest of the candidate already passes.

## Thirty-second reviewer record

Record whether the raster visibly communicates:

- fundamental advancement;
- why the approach or hypothesis should work;
- credibility without invented results;
- DOE or sponsor payoff; and
- two proposal-specific strengths.

## Scores

Score each from 0 to 5:

- science fidelity;
- primary-capability fidelity;
- proposal specificity;
- funding story;
- sponsor value;
- credibility without fake evidence;
- visual hierarchy;
- label-free compliance; and
- graphic-designer handoff value.

Qualify only when every hard gate passes, the average is at least 4.0, and no score is below 3. Qualification and delivery are separate: a usable raster that does not qualify remains eligible for a clearly labeled best-effort handoff.

## Candidate evaluation file

Create `evaluations/candidate-a.json` and `evaluations/candidate-b.json`:

```json
{
  "candidate_id": "A",
  "artifact": "candidates/candidate-a.png",
  "metrics": "candidates/candidate-a.metrics.json",
  "labels_report": "candidates/candidate-a.labels.json",
  "status": "pass",
  "hard_gates": {},
  "reviewer_test": {
    "fundamental_advancement": true,
    "why_it_should_work": true,
    "credibility": true,
    "doe_or_sponsor_payoff": true,
    "proposal_specific_strengths": ["", ""]
  },
  "actual_color_role_ledger": {
    "VISION": {"visible_family": "", "carrier": "", "source_support": ""},
    "GAP": {"visible_family": "", "carrier": "", "source_support": ""},
    "OBJECTIVES": {"visible_family": "", "carrier": "", "source_support": ""},
    "APPROACH": {"visible_family": "", "carrier": "", "source_support": ""},
    "IMPACT": {"visible_family": "", "carrier": "", "source_support": ""}
  },
  "scores": {},
  "repairable_issue": null,
  "selection_reason": ""
}
```

Use `status: fail` whenever a hard gate fails, regardless of total score.

## Repair and best-effort handoff

Permit one localized edit only for one contained defect. Rerun every hard gate and record an evaluation for the edited raster. Broad drift, a second defect, or a second edit fails qualification and ends tool use; compare the edit with the original and retain the stronger usable raster.

If no candidate passes, rank the usable candidates by science fidelity, primary-capability fidelity, proposal specificity, passed gates, reviewer recovery, and total score. Return exactly one strongest raster as an `AI-generated Figure 1 concept draft — not final`, followed by no more than three concise remaining review items. Never claim that failed gates passed. Withhold only when no usable image exists, the image is corrupt or unsafe to display, or the finalizer cannot produce exactly one PNG.
