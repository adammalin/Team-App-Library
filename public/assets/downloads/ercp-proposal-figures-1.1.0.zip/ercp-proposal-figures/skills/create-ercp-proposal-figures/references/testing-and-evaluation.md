# Testing and evaluation

## Deterministic package test

Run from any installation location:

```bash
python3 "<skill-root>/scripts/self_test.py"
```

The self-test uses only the packaged fictional source and a synthetic PNG. It checks run initialization, source-quote verification, pre-generation contract rejection and acceptance, prompt validation, portable OCR routing, empty text-inventory enforcement, PNG inspection, candidate evaluation, best-effort selection, and byte-identical finalization. It does not call image generation and does not claim visual quality.

## Frozen behavior checks

Use the packaged fictional fixtures to qualify a candidate release. Keep prompts and evaluation criteria frozen before testing.

1. Attachment canary: reject a filename, style image, or abstract-length summary when no substantive proposal is attached.
2. Source substitution canary: the semantic capsule and visible science must use the fixture's distinctive terms and must not import a generic science story.
3. Archetype A: transformation/separation fixture routes to A only after a proposal-native topology is written.
4. Archetype B: integration/return fixture encodes a real comparison or validation relationship, not a decorative loop.
5. Archetype C: central-branching fixture keeps the primary capability dominant and secondary analysis subordinate.
6. No-text gate: any visible word, numeral, unit, legend, axis, glyph, or pseudo-text consumes the one repair and fails delivery if it remains.
7. Color-role gate: actual raster QA accounts for Vision, Gap, Objectives, Approach, and Impact using the five source-supported carriers and canonical role assignments; role names remain outside the PNG and colors never swap.
8. Brand-neutral gate: reject any raster that imitates ORNL or another organization brand, uses a logo or mark, or replaces the proposal-role palette with an organization or companion palette.
9. Reference boundary: the bundled PNG affects style only and contributes no science, icon, claim, endpoint, label, data, topology, palette assignment, or branding.
10. Raster-only gate: exactly one final opaque 1536 × 1024 PNG; no SVG, vector document, slide, PDF, code, prompt, or alternate is user-facing.
11. Reviewer gate: the unlabeled thumbnail still communicates the advancement, why it should work, credibility without fabricated results, sponsor payoff, and two proposal-specific strengths.

## Evaluation record

Archive for each candidate:

- exact validated prompt and SHA-256;
- original PNG, metrics, OCR or visual text-verification report, and SHA-256;
- every hard-gate value;
- actual color-role ledger;
- 30-second reviewer record;
- 0–5 scores;
- repair eligibility and any exact edit prompt; and
- selection reason.

Qualification requires every hard gate, an average score of at least 4.0, and no score below 3. A scientifically usable image that misses qualification may be returned only as a clearly identified best-effort collaboration draft with the failed findings disclosed.

## Stochastic image-model boundary

The deterministic self-test proves package mechanics, not future image-model behavior. Run at least one fresh image-generation qualification on each release that changes prompts, visual DNA, style references, color roles, or QA. Never equate a local script pass with live visual qualification.
