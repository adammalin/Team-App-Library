# Brand-neutral visual system and companion controls

## Non-branding rule

Every generated Figure 1 is a brand-neutral scientific collaboration draft. Do not use an ORNL or other organization-brand skill to style the image. Do not seek visual recognition through an organization palette, logo, mark, typeface, branded container geometry, campaign motif, or institutional design device.

The proposal-role colors are a semantic analysis system for collaboration drafts, not an attempt to reproduce ORNL branding. Some source-presentation colors may also occur in a brand palette; their role assignment here is fixed by proposal meaning, not brand recognition.

## Canonical proposal-role colors

Keep these assignments stable across proposals:

| Role | Canonical anchor | Meaning |
|---|---:|---|
| Vision | `#C6DCCC` pale sage | desired organizing state or future scientific capability |
| Gap | `#FE5000` orange-red | consequential limitation or unresolved condition |
| Objectives | `#B36CFF` purple | what must be discovered, resolved, compared, or proven |
| Approach | `#FF9E1B` warm orange/gold | distinctive hypothesis, intervention, measurement, or integration capability |
| Impact | `#BFD1D3` pale cyan/teal | scientific endpoint and source-supported DOE or sponsor value |

Use the canonical anchor in the image prompt for each role. Restrained lighter or darker tones from the same family may help hierarchy, but a role may not adopt another role's family. Do not replace this system with ORNL Green, Hale Navy, a sponsor palette, or a companion palette.

## Companion transfer

A supplied Figure 1, Roadmap, sketch, or style image may influence only:

- line weights;
- arrow or connector language;
- icon abstraction level without copying icons;
- spacing and grid;
- balance of large versus small forms;
- negative space; and
- overall flat scientific-editorial tone.

Do not transfer palette, typography, logos, marks, science, topology, labels, claims, schedule, data, dates, tasks, milestones, results, device details, partner marks, or incidental copy. The proposal remains the sole content authority. A Roadmap may influence non-color surface treatment but never Figure 1 science, sequencing, or the canonical role-color assignments.

## Typography and marks

Visible text is always `NONE`. Keep every role name and color explanation in the chat handoff. Logo state is always `OMIT`; do not composite a logo and never ask the image model to recreate one.

## QA consequence

Fail `brand_neutral_output` when the raster appears designed to reproduce an organization brand or contains any logo, mark, branded lockup, institutional wordmark, oak leaf, sponsor badge, organization-recognition palette treatment, or branded template device. Shared colors alone are not a failure when they visibly serve the fixed proposal-role system.
