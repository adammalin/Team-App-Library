#!/usr/bin/env python3
"""Select one strongest usable candidate and expose exactly one final PNG."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


HARD_GATES = {
    "attachment_grounding",
    "science_fidelity",
    "primary_capability_fidelity",
    "secondary_method_suppression",
    "decisive_relationship_visible",
    "scientific_endpoint_visible",
    "claim_evidence_reconciliation",
    "closed_text_inventory",
    "five_role_color_fidelity",
    "brand_neutral_output",
    "style_reference_boundary",
    "no_fabricated_evidence",
    "no_roadmap_logic",
    "no_unauthorized_marks",
    "no_generic_template_or_stock_metaphor",
    "flat_scientific_editorial_style",
    "one_dominant_hierarchy",
    "thumbnail_reviewer_test",
    "graphic_designer_handoff_value",
}

SCORE_FIELDS = {
    "science_fidelity",
    "primary_capability_fidelity",
    "proposal_specificity",
    "funding_story",
    "sponsor_value",
    "credibility_without_fake_evidence",
    "visual_hierarchy",
    "label_free_compliance",
    "graphic_designer_handoff_value",
}

REVIEWER_FLAGS = {
    "fundamental_advancement",
    "why_it_should_work",
    "credibility",
    "doe_or_sponsor_payoff",
}
COLOR_ROLES = {"VISION", "GAP", "OBJECTIVES", "APPROACH", "IMPACT"}


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_inside(run_dir: Path, relative: Any, label: str) -> Path:
    if not isinstance(relative, str) or not relative.strip():
        raise ValueError(f"{label} path is missing")
    path = (run_dir / relative).resolve()
    try:
        path.relative_to(run_dir)
    except ValueError as exc:
        raise ValueError(f"{label} path escapes the run directory: {path}") from exc
    if not path.is_file():
        raise ValueError(f"{label} file does not exist: {path}")
    return path


def assess(run_dir: Path, evaluation_path: Path) -> tuple[dict[str, Any] | None, list[str]]:
    fatal_errors: list[str] = []
    findings: list[str] = []
    evaluation = load_json(evaluation_path)
    candidate_id = str(evaluation.get("candidate_id", evaluation_path.stem))

    if evaluation.get("status") not in ("pass", "fail"):
        fatal_errors.append("evaluation status must be pass or fail")
    elif evaluation.get("status") != "pass":
        findings.append("evaluation status is fail")
    gates = evaluation.get("hard_gates", {})
    if not isinstance(gates, dict) or set(gates) != HARD_GATES:
        fatal_errors.append("hard-gate inventory is incomplete")
        passed_gate_count = 0
    else:
        passed_gate_count = sum(value is True for value in gates.values())
        findings.extend(f"failed hard gate: {name}" for name in sorted(gates) if gates[name] is not True)

    reviewer = evaluation.get("reviewer_test", {})
    if not isinstance(reviewer, dict):
        fatal_errors.append("30-second reviewer record is missing")
        reviewer_pass_count = 0
    else:
        reviewer_pass_count = sum(reviewer.get(flag) is True for flag in REVIEWER_FLAGS)
        findings.extend(
            f"30-second reviewer miss: {flag}"
            for flag in sorted(REVIEWER_FLAGS)
            if reviewer.get(flag) is not True
        )
    strengths = reviewer.get("proposal_specific_strengths", []) if isinstance(reviewer, dict) else []
    if not isinstance(strengths, list) or len([value for value in strengths if str(value).strip()]) < 2:
        findings.append("fewer than two proposal-specific strengths are recoverable")

    color_ledger = evaluation.get("actual_color_role_ledger", {})
    if not isinstance(color_ledger, dict) or set(color_ledger) != COLOR_ROLES:
        fatal_errors.append("actual five-role color ledger is incomplete")
    else:
        for role, entry in color_ledger.items():
            if not isinstance(entry, dict) or not all(
                isinstance(entry.get(key), str) and entry.get(key).strip()
                for key in ("visible_family", "carrier", "source_support")
            ):
                fatal_errors.append(f"actual color-role record is incomplete: {role}")

    scores = evaluation.get("scores", {})
    numeric_scores: list[float] = []
    if not isinstance(scores, dict) or set(scores) != SCORE_FIELDS:
        fatal_errors.append("score inventory is incomplete")
    else:
        for key, value in scores.items():
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= 5:
                fatal_errors.append(f"score is outside 0-5: {key}")
            else:
                numeric_scores.append(float(value))
        if numeric_scores and (min(numeric_scores) < 3 or sum(numeric_scores) / len(numeric_scores) < 4.0):
            findings.append("scores do not meet the minimum 3 and average 4.0 qualification floor")

    if evaluation.get("repairable_issue") is not None:
        findings.append(f"unresolved repairable issue: {evaluation.get('repairable_issue')}")

    try:
        artifact = resolve_inside(run_dir, evaluation.get("artifact"), "artifact")
        metrics_path = resolve_inside(run_dir, evaluation.get("metrics"), "metrics")
        labels_path = resolve_inside(run_dir, evaluation.get("labels_report"), "labels report")
        metrics = load_json(metrics_path)
        labels = load_json(labels_path)
        artifact_hash = sha256(artifact)
        if artifact.suffix.lower() != ".png":
            fatal_errors.append("artifact is not a PNG")
        if metrics.get("hard_gate_pass") is not True:
            fatal_errors.append("deterministic raster inspection did not pass")
        if metrics.get("sha256") != artifact_hash:
            fatal_errors.append("raster metrics are stale or refer to a different artifact")
        if Path(str(metrics.get("file", ""))).resolve() != artifact:
            fatal_errors.append("raster metrics file path does not match the artifact")
        if labels.get("status") != "pass":
            findings.append("closed label inventory did not pass")
        if Path(str(labels.get("image", ""))).resolve() != artifact:
            fatal_errors.append("label report image path does not match the artifact")
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        fatal_errors.append(str(exc))
        artifact = None
        artifact_hash = None

    if fatal_errors:
        return None, [f"{candidate_id}: {error}" for error in fatal_errors]
    average = sum(numeric_scores) / len(numeric_scores) if numeric_scores else 0.0
    science_priority = sum(
        float(scores[name])
        for name in ("science_fidelity", "primary_capability_fidelity", "proposal_specificity")
    )
    return {
        "candidate_id": candidate_id,
        "evaluation": str(evaluation_path.relative_to(run_dir)),
        "artifact": artifact,
        "sha256": artifact_hash,
        "average_score": average,
        "science_priority": science_priority,
        "passed_gate_count": passed_gate_count,
        "reviewer_pass_count": reviewer_pass_count,
        "qualification_pass": not findings,
        "findings": findings,
    }, []


def validate_base_candidates(run_dir: Path) -> list[str]:
    """Prove that both originally generated candidates were archived and evaluated."""
    errors: list[str] = []
    for stem, expected_id in (("candidate-a", "A"), ("candidate-b", "B")):
        evaluation_path = run_dir / "evaluations" / f"{stem}.json"
        try:
            prompt_path = resolve_inside(run_dir, f"prompts/{stem}.txt", f"{expected_id} prompt")
            if not prompt_path.read_text(encoding="utf-8").strip():
                errors.append(f"{expected_id}: exact generation prompt is empty")
            evaluation = load_json(evaluation_path)
            if str(evaluation.get("candidate_id")) != expected_id:
                errors.append(f"{expected_id}: evaluation candidate_id does not match")
            if evaluation.get("status") not in ("pass", "fail"):
                errors.append(f"{expected_id}: evaluation is still pending")
            for field, label in (("artifact", "artifact"), ("metrics", "metrics"), ("labels_report", "labels report")):
                resolve_inside(run_dir, evaluation.get(field), f"{expected_id} {label}")
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            errors.append(f"{expected_id}: {exc}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()

    try:
        run = load_json(run_dir / "run.json")
        pregen = load_json(run_dir / "validation" / "pregen.json")
        prompt_validation = load_json(run_dir / "validation" / "prompts.json")
        if pregen.get("status") != "pass":
            raise ValueError("pre-generation validation did not pass")
        source_record = run.get("source", {})
        source_path = Path(str(source_record.get("path", ""))).expanduser().resolve()
        if not source_path.is_file() or sha256(source_path) != source_record.get("sha256"):
            raise ValueError("source file is missing or changed after run initialization")
        current_analysis_hashes = {
            str(path.relative_to(run_dir)): sha256(path)
            for path in sorted((run_dir / "analysis").glob("*.json"))
        }
        if pregen.get("analysis_sha256") != current_analysis_hashes:
            raise ValueError("analysis changed after pre-generation validation")
        if prompt_validation.get("status") != "pass":
            raise ValueError("candidate prompt validation did not pass")
        current_prompt_hashes = {
            str(path.relative_to(run_dir)): sha256(path)
            for path in sorted((run_dir / "prompts").glob("candidate-[ab].txt"))
        }
        if prompt_validation.get("prompt_sha256") != current_prompt_hashes:
            raise ValueError("candidate prompts changed after prompt validation")
        repair_count = run.get("repair_count")
        if not isinstance(repair_count, int) or isinstance(repair_count, bool) or not 0 <= repair_count <= 1:
            raise ValueError("repair_count must be an integer from zero to one")

        base_errors = validate_base_candidates(run_dir)
        if base_errors:
            raise ValueError("base candidate archive is incomplete:\n- " + "\n- ".join(base_errors))

        evaluations = sorted((run_dir / "evaluations").glob("*.json"))
        if not evaluations:
            raise ValueError("no evaluation JSON files found")
        eligible: list[dict[str, Any]] = []
        fatal_reasons: list[str] = []
        for evaluation_path in evaluations:
            candidate, errors = assess(run_dir, evaluation_path)
            fatal_reasons.extend(errors)
            if candidate:
                eligible.append(candidate)
        if not eligible:
            raise ValueError("no usable evaluated candidate exists:\n- " + "\n- ".join(fatal_reasons))

        if repair_count == 1:
            edited = [item for item in eligible if "-edit-01" in item["artifact"].stem]
            if not edited:
                raise ValueError("repair_count is one but no evaluated -edit-01 artifact exists")
            for item in edited:
                edit_prompt = resolve_inside(
                    run_dir,
                    f"prompts/{item['artifact'].stem}.txt",
                    f"{item['candidate_id']} localized edit prompt",
                )
                if not edit_prompt.read_text(encoding="utf-8").strip():
                    raise ValueError(f"exact localized edit prompt is empty: {edit_prompt}")

        qualifying = [item for item in eligible if item["qualification_pass"]]
        if qualifying:
            qualifying.sort(key=lambda item: (-item["average_score"], str(item["candidate_id"])))
            selected = qualifying[0]
        else:
            eligible.sort(
                key=lambda item: (
                    -item["science_priority"],
                    -item["passed_gate_count"],
                    -item["reviewer_pass_count"],
                    -item["average_score"],
                    str(item["candidate_id"]),
                )
            )
            selected = eligible[0]
        final_dir = (run_dir / "final").resolve()
        try:
            final_dir.relative_to(run_dir)
        except ValueError as exc:
            raise ValueError(f"final directory escapes the run directory: {final_dir}") from exc
        final_dir.mkdir(parents=True, exist_ok=True)
        if any(final_dir.iterdir()):
            raise ValueError(f"refusing non-empty final directory: {final_dir}")
        destination = final_dir / "ercp-figure-1-draft.png"
        shutil.copy2(selected["artifact"], destination)
        if sha256(destination) != selected["sha256"]:
            destination.unlink(missing_ok=True)
            raise ValueError("final artifact hash differs after copy")
        if [item.name for item in final_dir.iterdir()] != [destination.name]:
            raise ValueError("final directory does not contain exactly one selected PNG")

        finalized_at = datetime.now(timezone.utc).isoformat()
        final_record = {
            "status": "pass" if selected["qualification_pass"] else "best_effort",
            "qualification_pass": selected["qualification_pass"],
            "finalized_at": finalized_at,
            "selected_candidate": selected["candidate_id"],
            "selected_evaluation": selected["evaluation"],
            "selected_average_score": round(selected["average_score"], 4),
            "source_artifact": str(selected["artifact"].relative_to(run_dir)),
            "final_artifact": str(destination.relative_to(run_dir)),
            "sha256": selected["sha256"],
            "qualifying_candidates": [item["candidate_id"] for item in qualifying],
            "remaining_issues": selected["findings"][:3],
            "candidate_findings": {
                item["candidate_id"]: item["findings"]
                for item in eligible
            },
            "fatal_evaluation_errors": fatal_reasons,
        }
        validation_path = run_dir / "validation" / "finalization.json"
        validation_path.write_text(json.dumps(final_record, indent=2) + "\n", encoding="utf-8")
        run["status"] = "finalized"
        run["finalized_at"] = finalized_at
        run["final_artifact"] = {
            "path": str(destination.relative_to(run_dir)),
            "sha256": selected["sha256"],
            "selected_candidate": selected["candidate_id"],
            "delivery_status": final_record["status"],
        }
        (run_dir / "run.json").write_text(json.dumps(run, indent=2) + "\n", encoding="utf-8")
        print(
            f"RESULT | PASS | delivery={final_record['status']} | "
            f"selected={selected['candidate_id']} | final={destination}"
        )
        return 0
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        print(f"RESULT | FAIL | {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
