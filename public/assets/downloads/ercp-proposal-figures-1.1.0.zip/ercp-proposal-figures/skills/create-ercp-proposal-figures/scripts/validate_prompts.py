#!/usr/bin/env python3
"""Validate two archived candidate prompts against the frozen execution contract."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()
    out = run_dir / "validation" / "prompts.json"

    try:
        run = load_json(run_dir / "run.json")
        pregen = load_json(run_dir / "validation" / "pregen.json")
        execution = load_json(run_dir / "analysis" / "execution-contract.json")
        current_analysis_hashes = {
            str(path.relative_to(run_dir)): sha256(path)
            for path in sorted((run_dir / "analysis").glob("*.json"))
        }
        errors: list[str] = []
        if run.get("status") != "pregen_passed" or pregen.get("status") != "pass":
            errors.append("pre-generation validation is not current and passed")
        if pregen.get("analysis_sha256") != current_analysis_hashes:
            errors.append("analysis changed after pre-generation validation")

        prompts: dict[str, str] = {}
        prompt_hashes: dict[str, str] = {}
        required_start = "NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. COMPLETELY TEXT-FREE MATTE FLAT 2D VECTOR-STYLE RASTER PNG."
        required_end = "NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE."
        no_text_inventory = "ABSOLUTELY NO LETTERS, WORDS, NUMERALS, UNITS, SYMBOL LABELS, PSEUDO-TEXT, TITLES, LEGENDS, OR CAPTIONS ANYWHERE."
        required_brand_policy = "BRAND_NEUTRAL_PROPOSAL_DRAFT"
        required_brand_exclusion = "Do not apply or imitate ORNL or any other organization brand."
        for stem in ("candidate-a", "candidate-b"):
            path = run_dir / "prompts" / f"{stem}.txt"
            if not path.is_file():
                errors.append(f"missing exact prompt: {path}")
                continue
            text = path.read_text(encoding="utf-8").strip()
            prompts[stem] = text
            prompt_hashes[str(path.relative_to(run_dir))] = sha256(path)
            if not text:
                errors.append(f"empty prompt: {stem}")
                continue
            if not text.startswith(required_start):
                errors.append(f"{stem} does not begin with the exact no-text hard gate")
            if not text.endswith(required_end):
                errors.append(f"{stem} does not end with the exact no-text hard gate")
            if text.count(no_text_inventory) < 2:
                errors.append(f"{stem} does not repeat the complete no-text inventory around the spatial blueprint")
            for key, value in execution.get("semantic_capsule", {}).items():
                line = f"{key}: {value}"
                if line not in text:
                    errors.append(f"{stem} lacks exact semantic-capsule line: {key}")
            for value in execution.get("allowed_visuals", []):
                if value not in text:
                    errors.append(f"{stem} lacks allowed visual: {value}")
            for value in execution.get("must_preserve", []):
                if value not in text:
                    errors.append(f"{stem} lacks preserve item: {value}")
            for value in execution.get("forbidden", []):
                if value not in text:
                    errors.append(f"{stem} lacks forbidden item: {value}")
            allowed_text = execution.get("only_allowed_text", [])
            if allowed_text != []:
                errors.append(f"{stem} execution contract is not label-free")
            if execution.get("visual_brand_policy") != required_brand_policy:
                errors.append(f"{stem} execution contract is not brand-neutral")
            if required_brand_policy not in text or required_brand_exclusion not in text:
                errors.append(f"{stem} lacks the explicit brand-neutral hard gate")
            ledger = execution.get("color_role_ledger", {})
            for role, entry in ledger.items():
                if role not in text:
                    errors.append(f"{stem} lacks color role: {role}")
                for key in ("scientific_meaning", "visual_carrier", "color_family", "anchor_hex"):
                    value = entry.get(key)
                    if isinstance(value, str) and value not in text:
                        errors.append(f"{stem} lacks {role} {key}")
            validation_cue = execution.get("validation_relationship_cue", {})
            for key in ("scientific_meaning", "geometry"):
                value = validation_cue.get(key)
                if isinstance(value, str) and value not in text:
                    errors.append(f"{stem} lacks validation relationship {key}")
            style_reference = execution.get("style_reference", {})
            archetype = style_reference.get("archetype")
            if f"ARCHETYPE: {archetype}" not in text:
                errors.append(f"{stem} lacks the selected style-reference archetype")
            for value in style_reference.get("transfer", []):
                if value not in text:
                    errors.append(f"{stem} lacks style-only transfer item: {value}")
            for value in style_reference.get("prohibited_transfer", []):
                if value not in text:
                    errors.append(f"{stem} lacks prohibited style transfer: {value}")
            if "SEMANTIC CONTEXT — DO NOT RENDER AS TEXT" not in text:
                errors.append(f"{stem} does not hide semantic context from rendering")
            if execution.get("logo_state") == "OMIT" and "no logo" not in text.casefold():
                errors.append(f"{stem} does not explicitly omit the logo")
            for required in ("One opaque landscape raster PNG, 1536 × 1024.", "One image only."):
                if required not in text:
                    errors.append(f"{stem} lacks exact output rule: {required}")

        if len(prompts) == 2 and prompts["candidate-a"] == prompts["candidate-b"]:
            errors.append("candidate prompts are identical; spatial encoding must differ")

        result = {
            "status": "pass" if not errors else "fail",
            "validated_at": datetime.now(timezone.utc).isoformat(),
            "errors": errors,
            "analysis_sha256": current_analysis_hashes,
            "prompt_sha256": prompt_hashes,
        }
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        run["status"] = "prompts_validated" if not errors else "prompt_validation_failed"
        run["prompts_validated_at"] = result["validated_at"]
        (run_dir / "run.json").write_text(json.dumps(run, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 0 if not errors else 1
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f"RESULT | FAIL | {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
