---
name: create-ercp-proposal-figures
description: Create, evaluate, revise, and archive source-grounded, completely label-free raster Figure 1 collaboration drafts for DOE Office of Science proposals, especially ERCP or ECRP work. Use when Codex receives a substantive proposal in DOCX, PDF, Markdown, or text form and the user wants a persuasive proposal Figure 1, wants to revise an existing Figure 1 raster, or supplies a companion Roadmap or figure whose visual system should be coordinated. Produce one polished flat-vector-style PNG concept for researcher and graphic-designer collaboration. Do not use for Roadmap figures, final scientific evidence, plots, visible labels, SVG or vector deliverables, editable diagrams, or publication-ready art.
---

# Create ERCP Proposal Figures

Create a proposal-specific Figure 1 concept that makes the funding case visually: a reviewer should be able to recognize the scientific problem, the distinctive capability, the decisive change, and the DOE-relevant outcome without reading paragraphs or deciphering a generic infographic.

Preserve source truth and the output boundary firmly. Give visual interpretation enough freedom to be clear, memorable, and proposal-specific.

## Resolve the packaged skill root

Treat the directory containing this `SKILL.md` as `<skill-root>`. Resolve every bundled script, reference, fixture, and example image from that directory. Never assume a fixed install location.

## Product boundary

- Handle Figure 1 only. Roadmap work belongs in a separate skill.
- Produce an AI-generated collaboration draft for professional redraw and scientific verification, never final art or evidence.
- Use the installed built-in image-generation capability for every generation or edit. Do not require an API key or switch to a programmatic renderer.
- Deliver exactly one opaque 1536 × 1024 raster PNG. Never deliver SVG, vector paths, PDF, PowerPoint, Canvas, HTML, code, or a programmatic figure.
- Keep the PNG completely free of visible labels, titles, captions, words, letters, numerals, units, legends, axes, and pseudo-text. Explanations belong in chat.
- Keep the draft brand-neutral: no ORNL or other organization logo, typography, template, or recognizable brand treatment.
- Preserve prompts, candidates, evaluations, and the selected PNG inside a workspace run folder so the work can be compared and rolled back.
- Treat the proposal and all supplied references as read-only. Do not modify Custom GPTs, sharing, publication state, or external systems.

## Read the required references

Before generation, read:

1. [figure-1-method.md](references/figure-1-method.md) for the proposal decision-aid method and layout choices.
2. [analysis-contracts.md](references/analysis-contracts.md) for the source lock, science verification, visual-object inventory, candidate plans, and funding case.
3. [style-reference-router.md](references/style-reference-router.md) for the bundled reference images and layout-and-style routing.
4. [image-execution.md](references/image-execution.md) for compact generation and localized-edit prompts.
5. [qa-rubric.md](references/qa-rubric.md) for image-only reviewer testing and source reconciliation.
6. [visual-system-and-companion.md](references/visual-system-and-companion.md) when a companion visual exists or the source is organizationally branded.

Use an installed document or PDF skill for source extraction when available and the installed image-generation skill for all generation and edits. Do not use an organization-brand skill to style the image.

## Workflow

### 1. Establish the source set without unnecessary intake

Require one substantive proposal supplied or identified in the current task. The user's act of supplying it authorizes reading it for this task; do not ask a redundant clearance question. Stop only when the material is visibly prohibited for the current environment or is not substantive enough to support a Figure 1.

An existing Figure 1, Roadmap, sketch, or visual reference is optional. If one exists, use it to coordinate the visual system. If none exists, choose from the bundled examples without asking the user to select a layout.

### 2. Initialize a versioned evidence run

```bash
python3 "<skill-root>/scripts/init_run.py" \
  --run-dir "<workspace>/ercp-figure-1-runs/<YYYY-MM-DD>-<slug>" \
  --source "<absolute-proposal-path>" \
  --companion-status "<none|not-supplied|supplied>" \
  [--companion "<absolute-companion-path>"]
```

Never reuse a non-empty run directory. The run is the rollback bundle for that attempt.

### 3. Read and prove the proposal

Read the actual proposal, not its filename or a remembered summary. Recover internally:

- the exact title;
- at least four distinctive scientific terms;
- at least three exact passages from relevant sections;
- the central hypothesis or enabling capability; and
- the promised scientific and DOE-relevant outcome.

Stop if the proposal cannot be read or does not contain enough information. Do not browse to fill scientific gaps.

### 4. Freeze source truth

Complete the JSON files under `analysis/` using [analysis-contracts.md](references/analysis-contracts.md). Preserve exact proposal passages and locations for substantive claims. Use `NOT SUPPORTED` rather than inventing content.

```bash
python3 "<skill-root>/scripts/verify_source_quotes.py" --run-dir "<run-dir>"
```

Do not continue unless quote verification passes. Keep the primary scientific capability distinct from supporting analysis methods. Preserve the difference between proposed work and achieved evidence.

### 5. Build the decision-aid story before designing

Write one funding thesis and freeze answers to the four reviewer questions: fundamental advancement, why it should work, what makes success credible, and the DOE or sponsor payoff. Freeze two proposal-specific strengths.

Then create a visual-object inventory of three to seven recognizable, source-supported nouns or phenomena. Each required object needs a clear silhouette or visual signature. Do not allow color fields, dots, arrows, or abstract blobs to substitute for the proposal's primary instrument, material system, interface, mechanism, data flow, or endpoint when a recognizable representation is possible.

Evaluate the four presentation-derived layout families:

- linear sequence;
- feedback loop;
- integration map; and
- outcomes/impact focus.

Choose the family that best expresses the primary funding story. A linear left-to-right sequence is valid when the proposal is genuinely transformational or process-based. A loop is valid only when recurrence or validation is central. Do not let a secondary validation detail outweigh the main narrative.

Plan two meaningfully different candidates: the strongest layout and one credible alternative. A layout is successful when it would become scientifically wrong after swapping in another proposal's nouns.

### 6. Coordinate color and references without overconstraining the image

Use Vision, Gap, Objectives, Approach, and Impact as an internal semantic wireframe. The presentation colors help confirm that all five roles were considered; they are not mandatory final-image regions and do not need to appear as five exact hex colors.

Choose a cohesive final palette that supports hierarchy and makes proposal elements distinguishable. Roles may share, overlap, or transition between colors when that better represents the science. Explain the observed role/color mapping in chat after generation.

Use one bundled or user-supplied reference for each candidate when helpful. The reference may guide layout skeleton, stage proportions, connector language, icon abstraction, color rhythm, restrained dimensionality, negative space, and polish. It must not supply scientific claims, labels, logos, or unsupported content.

### 7. Freeze and validate the execution contract

Copy the verified semantic capsule, object inventory, candidate plans, role ledger, planned palette, allowed visuals, and short safety exclusions into `analysis/execution-contract.json`. Keep `analysis/allowed-text.json` equal to `[]`.

```bash
python3 "<skill-root>/scripts/validate_run.py" --run-dir "<run-dir>" --stage pregen
```

### 8. Write two compact, visual prompts

Use [image-execution.md](references/image-execution.md). Prefer positive, concrete direction. Each prompt should normally be 250–500 words and must remain under 700 words. Describe:

- one sentence explaining the funding story;
- three to seven recognizable visual objects;
- the reading order and relationships;
- the selected reference's layout-and-style role;
- a cohesive color strategy;
- one credibility cue and one sponsor-relevant endpoint; and
- only the few exclusions needed to prevent text, unsupported evidence, Roadmap content, branding, or a known wrong scientific substitution.

Do not paste the full proposal, evidence table, five-role ledger, QA rubric, or long catalogs of forbidden motifs into the image prompt.

Archive the prompts as `prompts/candidate-a.txt` and `prompts/candidate-b.txt`, then run:

```bash
python3 "<skill-root>/scripts/validate_prompts.py" --run-dir "<run-dir>"
```

### 9. Generate two internal candidates

Use two separate image-generation calls, one per prompt. Pass each selected reference PNG as image-generation reference material. Save the original returned files without overwriting:

```text
candidates/candidate-a.png
candidates/candidate-b.png
```

The desired style is a polished flat-vector-style raster: clean shapes, generous white space, coherent connectors, and restrained soft gradients, translucency, layering, or shallow dimensionality when they improve recognition. Avoid photorealism and glossy software-interface styling.

### 10. Inspect the actual images in two phases

Run raster inspection and OCR or full-size visual text inspection using the packaged scripts. Then follow [qa-rubric.md](references/qa-rubric.md):

1. **Blind image read:** inspect only the raster at thumbnail and full size. Record what system, capability, relationship, credibility cue, endpoint, sponsor value, and two strengths are actually visible. Do not consult the prompt or source lock during this phase.
2. **Source reconciliation:** compare that cold read with the verified proposal. Score only meanings recoverable from the image. Prompt intent cannot rescue an ambiguous raster.

A role color being present is not evidence that its meaning is visible. A recognizable proposal object, meaningful relationship, or scientifically grounded transition is.

### 11. Repair only local defects

Select the strongest passing candidate. Use at most one built-in Image Edit for visible text or another genuinely localized defect. Preserve every successful region and archive the exact edit prompt and edited PNG.

Do not use a localized edit to rescue a wrong story, missing capability, unrecognizable science, weak hierarchy, or generic composition. Those are structural failures and should inform the next version or a new run with a different layout/reference.

### 12. Finalize one collaboration draft

```bash
python3 "<skill-root>/scripts/finalize_run.py" --run-dir "<run-dir>"
```

Confirm that `final/` contains exactly one PNG. Render only that PNG and begin the handoff with `AI-generated Figure 1 collaboration draft — not final`.

Add `Color roles in this draft:` with three to five short observations grounded in the actual raster and source lock. Add at most three `Remaining review items:`. Researcher interpretation, graphic-designer redraw, and scientist/content-owner verification remain required.

## What remains strict

The proposal is the scientific authority. The delivered artifact is one label-free raster PNG. Do not fabricate results or scientific evidence, introduce Roadmap years or thrusts, imitate an organization brand, add logos, or deliver vector/editable art.

Everything else—layout family, direction, visual metaphor, recognizable icons, palette, connectors, layering, restrained gradients, and degree of abstraction—should serve the proposal and the 30-second reviewer test rather than a universal template.
