# Bundled style references

These eight PNGs are expected-quality reference material for this collaboration-draft workflow:

- `ref-a-transformation-separation.png`
- `ref-a2-heterogeneous-resolution.png`
- `ref-b-integration-validation-return.png`
- `ref-b2-mapping-feedback-return.png`
- `ref-b3-iterative-control-return.png`
- `ref-c-central-capability-branching.png`
- `ref-d-multiscale-mechanism-iteration.png`
- `ref-e-shared-foundation-coupled-states.png`

They demonstrate a label-free, polished flat-vector-style scientific family: white field, recognizable proposal-specific forms, coordinated color, clear connectors, generous negative space, restrained dimensionality, and strong thumbnail hierarchy.

Use them as layout-and-style examples. The image model may learn their composition grammar, stage proportions, connector language, icon abstraction, color rhythm, soft gradients, translucent overlaps, layering, and polish. The current proposal remains the sole authority for scientific content, claims, credibility, and impact.

Do not copy a reference's scientific subjects, labels, claims, evidence, logos, or unsupported endpoint. Reusing its broad layout family is allowed when that layout fits the current proposal's primary funding story.
