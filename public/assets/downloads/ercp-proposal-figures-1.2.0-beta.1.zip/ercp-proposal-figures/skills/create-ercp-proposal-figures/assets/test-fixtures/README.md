# Fictional qualification fixtures

These files are synthetic and contain no real proposal, facility, sponsor commitment, or result. Use them to test source locking and archetype routing without exposing client content.

- `fictional-archetype-a-transformation.md`: transformation and separation.
- `fictional-archetype-b-integration-return.md`: integration with a validation return path.
- `fictional-archetype-c-central-branching.md`: one central capability branching into outcomes.
- `fictional-source-lock-canary.md`: detects substitution of generic science for the attached source.

Do not treat the fixtures as knowledge for a real proposal.
