# Fictional proposal fixture — Archetype B

This entire document is fictional and contains no real organization, person, facility, export-controlled information, personal information, or unpublished research.

## Proposal title

Project CALDRIS: Cross-Scale Echo Integration for Kestrel Domains

## Scientific vision

Project CALDRIS will establish a unified causal picture of how a fictitious Kestrel domain stores and releases a boundary echo across three observation scales. The desired future capability is to predict the later domain state from the coupled echo rather than from any one measurement alone.

## Consequential gap

Fast boundary displacement, intermediate phase delay, and slow domain recovery are currently measured separately. None of the three measurements alone reveals how the same boundary event propagates across scales.

## Distinctive intervention and hypothesis

The project will synchronize the three measurements and integrate them through a harmonic-stitch relation centered on the same domain boundary. The central hypothesis is that one cross-scale phase ordering connects the initial displacement to the later recovered state.

## Objectives

The work will resolve the three echo components, determine their ordering, and establish one integrated relation that predicts the recovered domain state.

## Confidence and validation

A withheld perturbation will be predicted from the integrated relation and then applied to the same boundary. The measured recovery will return to the integrated relation for comparison. This is proposed validation, not an achieved result.

## Expected outcome and sponsor value

The project will produce a cross-scale causal rule for boundary memory. The sponsor-relevant payoff is a transferable basis for connecting measurements across time scales to predictive control of nonequilibrium domain behavior.

## Conceptual visual boundary

Allowed subjects are one Kestrel boundary, three distinct measurement bands entering one dominant integration region, one recovered-state endpoint, and one simple return path from the endpoint to the integration region. No labels, chart, axes, instrument icons, databases, documents, generic AI network, shield, checkmark, facility, schedule, or achieved-result claim is supported.
