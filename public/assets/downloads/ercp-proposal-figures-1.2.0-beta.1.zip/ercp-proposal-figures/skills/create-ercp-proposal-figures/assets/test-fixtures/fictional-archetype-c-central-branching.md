# Fictional proposal fixture — Archetype C

This entire document is fictional and contains no real organization, person, facility, export-controlled information, personal information, or unpublished research.

## Proposal title

Project NEXORA: Threaded Imaging of Coupled Membrane Events

## Scientific vision

Project NEXORA will reveal how three coupled events at a fictitious porous Nexora membrane jointly determine selective transport. The desired scientific capability is to see capture, transfer, and release as one connected mechanism rather than as isolated observations.

## Consequential gap

Current measurements observe only the final transported population. They cannot distinguish whether selectivity was set by initial capture, transfer through the membrane, or release on the far side.

## Distinctive intervention and hypothesis

The project will create a spectral-threading imager that follows one perturbation through the same membrane region and resolves the three coupled events without breaking continuity. The central hypothesis is that a common interfacial configuration branches into three event-specific signatures that together determine selective transport.

## Objectives

The work will resolve the three event signatures, determine their coupling, and identify which branch controls the final transport state.

## Confidence and validation

The imager will follow a held-out perturbation through the same membrane and test whether all three event signatures recur in the predicted relationship. This is proposed validation, not an achieved result.

## Expected outcome and sponsor value

The project will deliver a mechanistic map connecting one interfacial configuration to capture, transfer, and release. The sponsor-relevant payoff is a predictive basis for designing selective transport in responsive membrane systems.

## Conceptual visual boundary

Allowed subjects are one porous membrane region, one dominant spectral-threading capability centered on it, one continuous perturbation, three distinct event branches, and one integrated selective-transport state. No labels, plots, camera or microscope icon, generic AI network, molecule, atom, facility imagery, database, dashboard, schedule, achieved result, or generic impact symbol is supported.
