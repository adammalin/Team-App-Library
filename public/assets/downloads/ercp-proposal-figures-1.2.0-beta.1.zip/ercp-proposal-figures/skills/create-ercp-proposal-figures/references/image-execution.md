# Built-in image execution contracts

## Candidate strategy

Generate two internal candidates with separate image-generation calls:

- Candidate A uses the strongest layout family and closest reference.
- Candidate B uses a meaningfully different credible layout or reference.

Keep proposal facts, required objects, output format, and scientific boundaries the same. Let composition, reading direction, grouping, and visual metaphor vary.

## Compact generation prompt

Prompts should normally be 250–500 words and must remain under 700 words. Prefer concrete positive direction over long prohibition lists. Use these sections and exact first and last lines:

```text
NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. COMPLETELY TEXT-FREE FLAT-VECTOR-STYLE RASTER PNG.

PURPOSE
Create one persuasive DOE Office of Science proposal Figure 1 collaboration draft. The visual funding story is: [one sentence].

SOURCE-LOCKED SCIENCE — DO NOT RENDER AS TEXT
SYSTEM: ...
PRIMARY CAPABILITY: ...
DECISIVE RELATIONSHIP: ...
ENDPOINT: ...
DO NOT SUBSTITUTE: ...

MUST SHOW
- [three to seven recognizable, source-supported objects or phenomena]
- [one credibility cue]

COMPOSITION
[Candidate-specific reading order, hierarchy, relationships, and spatial blueprint. State what is dominant and what is subordinate.]

REFERENCE ASSET: [path or NONE]
Use the attached reference for layout grammar and illustration quality: [short transfer list]. Replace all depicted science with the proposal-specific objects above. Do not copy labels, claims, logos, data, or unsupported content.

COLOR AND STYLE
[Cohesive palette strategy.] Polished flat-vector-style scientific illustration on a white or near-white field. Clean shapes, clear connectors, generous negative space, and strong thumbnail hierarchy. Restrained soft gradients, translucency, layering, or shallow dimensionality are welcome when they improve recognition. No organization branding.

SCIENCE BOUNDARY
Show proposed relationships as concepts, not achieved measurements. Do not invent data, plots, microscopy, exact structures, performance values, facilities, or evidence not supported by the proposal. Do not add Roadmap years, thrusts, milestones, or task labels. Avoid unrelated stock metaphors that replace the required proposal objects.

OUTPUT
One opaque landscape raster PNG, 1536 × 1024. No title, caption, labels, letters, numerals, units, axes, legend, logo, watermark, pseudo-text, alternate, comparison, document, SVG, or vector data.

NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
```

Include the exact five renderer-capsule lines. Include every required visual object and each candidate's exact story spine. Do not include proposal quotations, the abstract, evidence tables, role names, fixed wireframe hex colors, QA instructions, or exhaustive lists of generic motifs.

When a local reference is selected, pass its actual PNG to the image-generation call. The reference is layout-and-style material, not merely a filename mentioned in the prompt.

## Useful visual freedom

The image model may use:

- linear, circular, branching, nested, convergent, or integrated composition;
- arrows, flow bands, return paths, boundaries, insets, simplified devices, and scientifically appropriate icons;
- repeated particles, nodes, layers, contour-like fields, data symbols, facility silhouettes, molecular motifs, or networks when they are supported and help identify the proposal;
- soft same-family gradients, modest perspective, translucent overlaps, and shallow dimensionality; and
- a palette inspired by the selected reference or a supplied companion, provided the output does not imitate an organization brand.

Do not ban a visual form simply because it can be generic. Make it proposal-specific through the objects, relationships, hierarchy, and endpoint.

## Localized edit contract

Use one edit only after visually inspecting the selected local PNG:

```text
NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
Use case: precise localized image correction.

CHANGE ONLY: [specific visible defect and bounded region].
PRESERVE: canvas, crop, story spine, proposal-specific objects, science, hierarchy, palette character, connectors, negative space, and every successful region.

SOURCE-LOCKED SCIENCE — DO NOT RENDER AS TEXT
[unchanged five renderer-capsule lines]

Do not add any other object, claim, text, number, logo, mark, or style change.
NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
```

Archive the exact edit prompt and save the result beside the source as `candidate-<id>-edit-01.png`. Never overwrite the source candidate.

Do not use localized editing for a missing primary capability, unrecognizable scientific system, wrong endpoint, weak story spine, or broadly generic composition.

## Save-path rule

Image generation writes under client-managed storage first. Copy the original returned file into the run directory before inspection. Preserve its bytes before hashing and QA.
