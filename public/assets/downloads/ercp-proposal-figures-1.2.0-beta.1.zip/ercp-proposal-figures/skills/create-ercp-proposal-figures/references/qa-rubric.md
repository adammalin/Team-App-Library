# Figure 1 raster QA and selection rubric

Evaluate the original raster, not a file card, filename, prompt, color ledger, or model self-report.

## Deterministic gates

Require:

- one valid 1536 × 1024 opaque PNG per candidate;
- exact prompt and source hash archived;
- empty allowed-text inventory;
- OCR or full-size visual inspection finding no visible text or pseudo-text;
- one final PNG and no client-facing vector/document alternatives; and
- recorded generation mode and repair count.

Palette and coverage metrics are diagnostics, not proof of meaning or exact-color compliance.

## Two-phase visual evaluation

### Phase A: blind image read

Inspect the raster at thumbnail size and full size without consulting the proposal, prompt, semantic capsule, reference name, or planned role ledger. Record plain-language answers:

- What scientific system or subject is visible?
- What capability or intervention appears central?
- What changes, separates, couples, integrates, or becomes possible?
- What visual cue makes the approach credible?
- What endpoint or sponsor value is visible?
- What two strengths could a reviewer write from this image?
- Which regions remain ambiguous or generic?

Save this cold read before source reconciliation. Do not infer hidden intent from color alone.

### Phase B: source reconciliation

Now compare the blind record with the verified proposal. A reviewer answer passes only when the cold-read meaning substantially matches the source lock. Prompt intent cannot rescue an ambiguous image.

## Visual and scientific hard gates

Every item must be true:

```json
{
  "attachment_grounding": true,
  "science_fidelity": true,
  "primary_capability_fidelity": true,
  "secondary_method_suppression": true,
  "decisive_relationship_visible": true,
  "scientific_endpoint_visible": true,
  "claim_evidence_reconciliation": true,
  "closed_text_inventory": true,
  "five_role_color_fidelity": true,
  "brand_neutral_output": true,
  "style_reference_boundary": true,
  "no_fabricated_evidence": true,
  "no_roadmap_logic": true,
  "no_unauthorized_marks": true,
  "no_generic_template_or_stock_metaphor": true,
  "flat_scientific_editorial_style": true,
  "one_dominant_hierarchy": true,
  "thumbnail_reviewer_test": true,
  "graphic_designer_handoff_value": true
}
```

Interpret the gates as follows:

- `primary_capability_fidelity` requires a recognizable capability, not a color region whose meaning comes only from the prompt.
- `five_role_color_fidelity` means the five proposal roles are visually accounted for through a coherent palette, contrast, continuity, transition, shared carrier, or spatial relationship. Exact wireframe hex colors are not required, and roles may share colors.
- `style_reference_boundary` allows the reference's composition grammar and visual finish to transfer. It forbids copied scientific content, labels, claims, evidence, or branding.
- `no_generic_template_or_stock_metaphor` fails only when generic imagery replaces proposal-specific content or creates the wrong scientific story. A scientifically appropriate icon, network, device, facility, database, molecule, atom, contour, layer, gear, shield, or arrow is not automatically a failure.
- `flat_scientific_editorial_style` allows restrained gradients, translucent flows, layering, soft shading, and shallow dimensionality consistent with the bundled examples. Fail photorealism, glossy UI, cinematic effects, or visual clutter that obscures the decision aid.
- `thumbnail_reviewer_test` passes only when the blind image read recovers the advancement, capability, decisive relationship, endpoint/payoff, and two defensible strengths.

## Proposal-specific recognizability

Inventory each required visual object from `visual_object_inventory`. Mark it:

- recognizable and source-consistent;
- present but ambiguous;
- absent; or
- misleading.

Every required object must be recognizable and source-consistent. Abstract dots, bands, or fields count only when their role is visually evident from the surrounding proposal-specific system.

## Evidence boundary

Do not mistake an attractive scientific-looking image for evidence. Fail when the raster implies unsupported measured results, exact structures, numerical performance, facility use, or achieved outcomes. Simplified concept illustrations of source-supported subjects are allowed.

## Scores

Score each from 0 to 5:

- science fidelity;
- primary-capability fidelity;
- proposal specificity;
- funding story;
- sponsor value;
- credibility without fake evidence;
- visual hierarchy;
- label-free compliance;
- reference-family fit; and
- graphic-designer handoff value.

Qualify only when every hard gate passes, the average is at least 4.0, and no score is below 3. A visually usable image that does not qualify may be returned only as a clearly labeled best-effort draft with its failed findings disclosed.

## Candidate evaluation file

Create `evaluations/candidate-a.json` and `evaluations/candidate-b.json`:

```json
{
  "candidate_id": "A",
  "artifact": "candidates/candidate-a.png",
  "metrics": "candidates/candidate-a.metrics.json",
  "labels_report": "candidates/candidate-a.labels.json",
  "status": "pass",
  "blind_image_read": {
    "review_mode": "image-only-cold-read",
    "visible_system": "",
    "visible_primary_capability": "",
    "visible_decisive_relationship": "",
    "visible_credibility_cue": "",
    "visible_endpoint": "",
    "visible_sponsor_value": "",
    "proposal_specific_strengths": ["", ""],
    "ambiguous_or_generic_regions": []
  },
  "hard_gates": {},
  "reviewer_test": {
    "fundamental_advancement": true,
    "why_it_should_work": true,
    "credibility": true,
    "doe_or_sponsor_payoff": true,
    "proposal_specific_strengths": ["", ""]
  },
  "object_reconciliation": [
    {"source_term": "", "status": "recognizable", "observed_form": "", "source_support": ""}
  ],
  "actual_color_role_ledger": {
    "VISION": {"visible_family": "", "carrier": "", "source_support": ""},
    "GAP": {"visible_family": "", "carrier": "", "source_support": ""},
    "OBJECTIVES": {"visible_family": "", "carrier": "", "source_support": ""},
    "APPROACH": {"visible_family": "", "carrier": "", "source_support": ""},
    "IMPACT": {"visible_family": "", "carrier": "", "source_support": ""}
  },
  "scores": {},
  "repairable_issue": null,
  "selection_reason": ""
}
```

`visible_family` may describe a shared or transitional palette relationship; it is not required to match a wireframe anchor.

Use `status: fail` whenever a hard gate fails, regardless of score.

## Repair and selection

Permit one localized edit only for a contained defect. A missing capability, unrecognizable proposal subject, wrong story, or weak composition is structural and not locally repairable.

If neither candidate qualifies, rank usable candidates by science fidelity, recognizable primary capability, proposal specificity, reviewer recovery, sponsor value, and overall visual quality. Return exactly one best-effort raster only when it remains scientifically usable, and disclose the failed findings.
