# Testing and evaluation

## Deterministic package test

Run from any installation location:

```bash
python3 "<skill-root>/scripts/self_test.py"
```

The self-test checks package mechanics: run initialization, source quotation verification, flexible palette validation, visual-object inventory, layout selection, candidate-plan validation, compact prompt validation, text exclusion, PNG inspection, evaluation integrity, selection, and byte-identical finalization. It does not call image generation and does not prove visual quality.

## Behavioral checks

Use the fictional fixtures and real proposal/reference pairs to qualify a release.

1. **Source access:** reject a filename, style image, or short summary when no substantive proposal can be read.
2. **Source substitution:** retain the proposal's distinctive scientific system, capability, relationship, and endpoint.
3. **Recognizable-object plan:** require three to seven source-supported visual objects with at least three marked required.
4. **Layout choice:** explicitly compare valid layout families and route on the primary funding story, not a secondary validation cue.
5. **Reference use:** pass the actual PNG to image generation and allow its layout grammar and visual finish to guide the result while excluding its scientific content.
6. **Creative freedom:** do not automatically reject linear sequences, icons, networks, simplified devices, arrows, layers, contours, particles, soft gradients, translucency, or shallow dimensionality.
7. **No-text:** any visible word, numeral, unit, legend, axis label, glyph, or pseudo-text consumes the one localized repair and fails qualification if it remains.
8. **Semantic color:** account for Vision, Gap, Objectives, Approach, and Impact, but do not require five exact final-image colors or five isolated carriers.
9. **Brand neutrality:** reject logos, organization templates, or unmistakable institutional styling; do not reject an ordinary scientific color merely because a brand also uses it.
10. **Raster-only:** expose exactly one opaque 1536 × 1024 PNG and no vector/document alternative.
11. **Blind reviewer gate:** inspect the raster without prompt or proposal context, then reconcile the cold read with the source lock.
12. **Reviewer strength test:** require two proposal-specific strengths that are visible in the image rather than inferred from archived intent.

## Real-reference benchmark set

The eight bundled references are expected-quality targets, not pixel-match targets. For each corresponding real proposal, archive:

- the proposal hash and verified analysis;
- both exact candidate prompts;
- the reference asset used by each candidate;
- original candidates and any localized edit;
- deterministic raster and text checks;
- blind image reads;
- source reconciliations and scores; and
- the selected final PNG.

Compare actual rasters on:

- recognizable proposal-specific subjects;
- primary-capability clarity;
- one dominant funding story;
- credible relationship and endpoint;
- sponsor-value visibility;
- clean flat-vector-style execution;
- no-text compliance; and
- usefulness as a graphic-designer starting point.

Do not score similarity by exact palette, pixel layout, or copied subject matter. The expected result is the same level of clarity and proposal specificity, not a clone.

## Version rollback bundle

Every release candidate that reaches image generation must preserve a self-contained version bundle containing:

- plugin documents and settings;
- exact prompt templates and runtime prompts;
- scripts and tests;
- reference assets;
- candidate and selected outputs;
- evaluations and blind-review records;
- package ZIP; and
- a short manifest identifying the version and result.

Never overwrite an earlier bundle. Promote a candidate only after its deterministic tests pass and its fresh real-proposal rasters satisfy the blind reviewer gate.

## Stochastic boundary

Image generation is stochastic. A static test or one attractive example cannot prove consistency. Test at least three scientifically different real proposals for a release that changes prompts, layout routing, references, color logic, or QA. Inspect the actual images and revise only when failures reveal a repeatable workflow problem rather than one random rendering defect.
