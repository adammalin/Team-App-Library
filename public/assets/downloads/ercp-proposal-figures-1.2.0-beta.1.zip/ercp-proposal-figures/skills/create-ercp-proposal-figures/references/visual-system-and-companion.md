# Brand-neutral visual system and companion controls

## Non-branding rule

Every generated Figure 1 is a brand-neutral scientific collaboration draft. Do not imitate ORNL or another organization's logo, typeface, template, campaign motif, branded geometry, or recognizable institutional treatment.

Brand-neutral does not mean colorless. Use the colors that make the proposal story coherent and easy to understand.

## Five proposal roles

Use these presentation-derived colors while wireframing and checking the argument:

| Role | Wireframe anchor | Meaning |
|---|---:|---|
| Vision | `#C6DCCC` pale sage | desired organizing state or scientific future |
| Gap | `#FE5000` orange-red | consequential limitation or unresolved condition |
| Objectives | `#B36CFF` purple | what must be discovered, resolved, compared, or proven |
| Approach | `#FF9E1B` warm orange/gold | distinctive hypothesis, intervention, measurement, or integration capability |
| Impact | `#BFD1D3` pale cyan/teal | scientific endpoint and source-supported DOE or sponsor value |

These anchors are an internal completeness check, not a mandatory final palette. Do not force five colored boxes, five isolated regions, or five exact hex values into the PNG.

In the generated draft:

- use a cohesive palette, normally three to six core colors plus neutral tones;
- use contrast, continuity, boundary change, or color transition to clarify roles;
- allow roles to share or overlap color when they are scientifically connected;
- keep the distinctive capability visually dominant even when its role color differs from the wireframe anchor; and
- explain the actual observed color-role associations in chat after inspecting the raster.

## Companion coordination

A supplied Figure 1, Roadmap, sketch, or style image may influence:

- palette character and color rhythm;
- flat-vector illustration finish;
- line weights and connector language;
- icon abstraction;
- spacing, grid, and stage proportions;
- use of soft gradients, translucency, layering, and shallow depth;
- negative space and hierarchy; and
- overall tone.

Do not transfer scientific claims, labels, dates, tasks, milestones, measurements, achieved results, logos, partner marks, or unsupported device details. When the companion is branded, match only its neutral illustration system unless the user separately requests and authorizes branded final design.

When both Figure 1 and a Roadmap will be created, record the chosen palette character, connector family, stroke character, icon abstraction, and surface treatment in the run so the later figure can coordinate with it.

## Typography and marks

Visible text is always `NONE` in this skill's raster output. Logo state is always `OMIT`. Never ask the image model to recreate an institutional mark.

## QA consequence

Fail `brand_neutral_output` when the raster contains a logo, wordmark, branded lockup, institutional template, or unmistakable organization-specific treatment. Do not fail a useful scientific color merely because that color also exists in an organization palette.
