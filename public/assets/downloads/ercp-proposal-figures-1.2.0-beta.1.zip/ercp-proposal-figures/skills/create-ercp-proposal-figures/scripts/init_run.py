#!/usr/bin/env python3
"""Initialize a private, source-hashed ERCP Figure 1 evidence run."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


HARD_GATES = (
    "attachment_grounding",
    "science_fidelity",
    "primary_capability_fidelity",
    "secondary_method_suppression",
    "decisive_relationship_visible",
    "scientific_endpoint_visible",
    "claim_evidence_reconciliation",
    "closed_text_inventory",
    "five_role_color_fidelity",
    "brand_neutral_output",
    "style_reference_boundary",
    "no_fabricated_evidence",
    "no_roadmap_logic",
    "no_unauthorized_marks",
    "no_generic_template_or_stock_metaphor",
    "flat_scientific_editorial_style",
    "one_dominant_hierarchy",
    "thumbnail_reviewer_test",
    "graphic_designer_handoff_value",
)

SCORE_FIELDS = (
    "science_fidelity",
    "primary_capability_fidelity",
    "proposal_specificity",
    "funding_story",
    "sponsor_value",
    "credibility_without_fake_evidence",
    "visual_hierarchy",
    "label_free_compliance",
    "reference_family_fit",
    "graphic_designer_handoff_value",
)

DEFAULT_PALETTE: list[str] = []


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_record(path: Path) -> dict[str, Any]:
    resolved = path.expanduser().resolve()
    if not resolved.is_file():
        raise SystemExit(f"Source is not a readable file: {resolved}")
    stat = resolved.stat()
    return {
        "path": str(resolved),
        "sha256": sha256(resolved),
        "size_bytes": stat.st_size,
        "modified_at": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
    }


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def pending_evaluation(candidate_id: str) -> dict[str, Any]:
    stem = f"candidate-{candidate_id.lower()}"
    return {
        "candidate_id": candidate_id,
        "artifact": f"candidates/{stem}.png",
        "metrics": f"candidates/{stem}.metrics.json",
        "labels_report": f"candidates/{stem}.labels.json",
        "status": "pending",
        "blind_image_read": {
            "review_mode": "image-only-cold-read",
            "visible_system": "",
            "visible_primary_capability": "",
            "visible_decisive_relationship": "",
            "visible_credibility_cue": "",
            "visible_endpoint": "",
            "visible_sponsor_value": "",
            "proposal_specific_strengths": [],
            "ambiguous_or_generic_regions": [],
        },
        "hard_gates": {name: False for name in HARD_GATES},
        "reviewer_test": {
            "fundamental_advancement": False,
            "why_it_should_work": False,
            "credibility": False,
            "doe_or_sponsor_payoff": False,
            "proposal_specific_strengths": [],
        },
        "object_reconciliation": [],
        "actual_color_role_ledger": {
            role: {"visible_family": "", "carrier": "", "source_support": ""}
            for role in ("VISION", "GAP", "OBJECTIVES", "APPROACH", "IMPACT")
        },
        "scores": {name: 0 for name in SCORE_FIELDS},
        "repairable_issue": None,
        "selection_reason": "",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument(
        "--companion-status",
        choices=("none", "not-supplied", "supplied"),
        required=True,
        help="Whether a companion figure exists and is available in this run.",
    )
    parser.add_argument("--companion", type=Path)
    args = parser.parse_args()

    if args.companion_status == "supplied" and args.companion is None:
        raise SystemExit("--companion-status supplied requires --companion")
    if args.companion_status != "supplied" and args.companion is not None:
        raise SystemExit("--companion is accepted only with --companion-status supplied")

    run_dir = args.run_dir.expanduser().resolve()
    if run_dir.exists() and any(run_dir.iterdir()):
        raise SystemExit(f"Refusing non-empty run directory: {run_dir}")

    for name in ("analysis", "prompts", "candidates", "evaluations", "validation", "final"):
        (run_dir / name).mkdir(parents=True, exist_ok=True)

    created_at = datetime.now(timezone.utc).isoformat()
    run = {
        "schema_version": 3,
        "workflow_version": "1.2.0-beta.1",
        "created_at": created_at,
        "status": "initialized",
        "source_authorization": "user-supplied-in-task",
        "source": source_record(args.source),
        "companion_status": args.companion_status,
        "companion": source_record(args.companion) if args.companion else None,
        "product": "brand-neutral DOE Office of Science Figure 1 flat-vector-style raster collaboration draft",
        "generation_mode": "codex-built-in-imagegen",
        "candidate_count": 2,
        "final_artifact_count": 1,
        "repair_ceiling": 1,
        "repair_count": 0,
        "final_artifact": None,
    }
    write_json(run_dir / "run.json", run)

    write_json(
        run_dir / "analysis" / "source-lock.json",
        {
            "status": "pending",
            "proposal_title": "",
            "distinctive_terms": [],
            "scientific_vision": "",
            "scientific_system": "",
            "consequential_gap": "",
            "objectives": [],
            "primary_capability": "",
            "decisive_relationship": "",
            "validation_logic": "",
            "scientific_endpoint": "",
            "doe_payoff": "",
            "strengths": [],
            "secondary_methods": [],
            "allowed_subjects": [],
            "allowed_relationships": [],
            "forbidden_inferences": [],
            "evidence": [],
        },
    )
    write_json(
        run_dir / "analysis" / "science-verification.json",
        {
            "status": "pending",
            "proposal_identity_checksum": {},
            "renderer_capsule": {},
            "claim_evidence_matrix": [],
            "prohibited_substitutions": [],
            "secondary_method_suppression_pass": False,
            "interchangeability_test_pass": False,
        },
    )
    write_json(
        run_dir / "analysis" / "funding-case.json",
        {
            "status": "pending",
            "funding_thesis": "",
            "reviewer_answers": {
                "fundamental_advancement": "",
                "why_it_should_work": "",
                "credibility": "",
                "doe_or_sponsor_payoff": "",
            },
            "strengths": [],
        },
    )
    write_json(
        run_dir / "analysis" / "visual-brief.json",
        {
            "status": "pending",
            "funding_story_spine": "",
            "visual_object_inventory": [],
            "layout_evaluation": [],
            "candidate_plans": [],
            "color_role_ledger": {},
            "palette_strategy": "",
            "validation_relationship_cue": {},
            "visual_brand_policy": "BRAND_NEUTRAL_PROPOSAL_DRAFT",
            "style_reference": {},
            "allowed_text": [],
            "allowed_visuals": [],
            "must_preserve": [],
            "forbidden": [],
            "companion_transfer": [],
            "companion_prohibited_transfer": [],
            "logo_state": "OMIT",
            "canvas": {"width": 1536, "height": 1024},
            "candidate_count": 2,
            "final_artifact_count": 1,
            "repair_ceiling": 1,
        },
    )
    write_json(
        run_dir / "analysis" / "execution-contract.json",
        {
            "status": "pending",
            "semantic_capsule": {},
            "only_allowed_text": [],
            "funding_story_spine": "",
            "visual_object_inventory": [],
            "layout_evaluation": [],
            "candidate_plans": [],
            "color_role_ledger": {},
            "palette_strategy": "",
            "validation_relationship_cue": {},
            "visual_brand_policy": "BRAND_NEUTRAL_PROPOSAL_DRAFT",
            "style_reference": {},
            "allowed_visuals": [],
            "logo_state": "OMIT",
            "must_preserve": [],
            "forbidden": [],
            "output": {
                "candidate_count": 2,
                "final_artifact_count": 1,
                "format": "PNG",
                "artifact_type": "raster",
                "width": 1536,
                "height": 1024,
                "opacity": "opaque",
            },
            "repair_ceiling": 1,
        },
    )
    write_json(run_dir / "analysis" / "allowed-text.json", [])
    write_json(run_dir / "analysis" / "palette.json", DEFAULT_PALETTE)
    write_json(run_dir / "evaluations" / "candidate-a.json", pending_evaluation("A"))
    write_json(run_dir / "evaluations" / "candidate-b.json", pending_evaluation("B"))

    print(f"RESULT | PASS | run_dir={run_dir}")
    print(f"SOURCE_SHA256 | {run['source']['sha256']}")
    if run["companion"]:
        print(f"COMPANION_SHA256 | {run['companion']['sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
