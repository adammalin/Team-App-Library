#!/usr/bin/env python3
"""Fingerprint and deterministically inspect an original Figure 1 PNG."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import struct
import sys
import zlib
from collections import Counter
from pathlib import Path
from typing import Any


PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


class RasterError(RuntimeError):
    pass


def chunks(data: bytes) -> list[tuple[bytes, bytes]]:
    if not data.startswith(PNG_SIGNATURE):
        raise RasterError("file does not have a PNG signature")
    result: list[tuple[bytes, bytes]] = []
    offset = len(PNG_SIGNATURE)
    while offset < len(data):
        if offset + 12 > len(data):
            raise RasterError("truncated PNG chunk")
        length = struct.unpack(">I", data[offset : offset + 4])[0]
        kind = data[offset + 4 : offset + 8]
        start = offset + 8
        end = start + length
        if end + 4 > len(data):
            raise RasterError(f"truncated {kind!r} chunk")
        payload = data[start:end]
        expected_crc = struct.unpack(">I", data[end : end + 4])[0]
        actual_crc = zlib.crc32(kind + payload) & 0xFFFFFFFF
        if expected_crc != actual_crc:
            raise RasterError(f"CRC mismatch in {kind.decode('ascii', errors='replace')} chunk")
        result.append((kind, payload))
        offset = end + 4
        if kind == b"IEND":
            if offset != len(data):
                raise RasterError("bytes follow the IEND chunk")
            break
    if not result or result[0][0] != b"IHDR" or result[-1][0] != b"IEND":
        raise RasterError("PNG critical chunk order is invalid")
    return result


def paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def decode_pixels(data: bytes) -> tuple[int, int, int, bytes]:
    png_chunks = chunks(data)
    width, height, bit_depth, color_type, compression, filtering, interlace = struct.unpack(
        ">IIBBBBB", png_chunks[0][1]
    )
    if bit_depth != 8 or color_type not in (2, 6) or interlace != 0:
        raise RasterError("only 8-bit noninterlaced RGB or RGBA PNGs are accepted")
    if compression != 0 or filtering != 0:
        raise RasterError("unsupported PNG compression or filter method")
    bpp = 3 if color_type == 2 else 4
    packed = zlib.decompress(b"".join(payload for kind, payload in png_chunks if kind == b"IDAT"))
    stride = width * bpp
    if len(packed) != height * (stride + 1):
        raise RasterError("unexpected decompressed PNG length")
    result = bytearray(height * stride)
    source = 0
    for y in range(height):
        filter_type = packed[source]
        source += 1
        row = packed[source : source + stride]
        source += stride
        target = y * stride
        for x in range(stride):
            raw = row[x]
            left = result[target + x - bpp] if x >= bpp else 0
            up = result[target - stride + x] if y > 0 else 0
            upper_left = result[target - stride + x - bpp] if y > 0 and x >= bpp else 0
            if filter_type == 0:
                value = raw
            elif filter_type == 1:
                value = (raw + left) & 255
            elif filter_type == 2:
                value = (raw + up) & 255
            elif filter_type == 3:
                value = (raw + ((left + up) // 2)) & 255
            elif filter_type == 4:
                value = (raw + paeth(left, up, upper_left)) & 255
            else:
                raise RasterError(f"unsupported PNG row filter {filter_type}")
            result[target + x] = value
    return width, height, color_type, bytes(result)


def parse_hex(value: str) -> tuple[int, int, int]:
    stripped = value.lstrip("#")
    if len(stripped) != 6:
        raise ValueError(f"invalid palette color: {value}")
    return tuple(int(stripped[index : index + 2], 16) for index in (0, 2, 4))


def distance(a: tuple[int, int, int], b: tuple[int, int, int]) -> float:
    return math.sqrt(sum((left - right) ** 2 for left, right in zip(a, b)))


def inspect(path: Path, palette_path: Path | None) -> dict[str, Any]:
    data = path.read_bytes()
    png_chunks = chunks(data)
    width, height, color_type, pixels = decode_pixels(data)
    bpp = 3 if color_type == 2 else 4
    total = width * height
    light = 0
    nonlight: list[tuple[int, int]] = []
    alpha_min = 255
    alpha_max = 255
    quantized: Counter[tuple[int, int, int]] = Counter()
    palette = None
    off_palette = 0
    if palette_path:
        palette_values = json.loads(palette_path.read_text(encoding="utf-8"))
        palette = [parse_hex(value) for value in palette_values]

    for index in range(total):
        start = index * bpp
        rgb = tuple(pixels[start : start + 3])
        if color_type == 6:
            alpha = pixels[start + 3]
            alpha_min = min(alpha_min, alpha)
            alpha_max = max(alpha_max, alpha)
        if min(rgb) >= 235:
            light += 1
        else:
            nonlight.append((index % width, index // width))
        quantized[tuple((channel // 16) * 16 for channel in rgb)] += 1
        if palette and min(distance(rgb, target) for target in palette) > 70:
            off_palette += 1

    if nonlight:
        xs = [x for x, _ in nonlight]
        ys = [y for _, y in nonlight]
        bbox = [min(xs), min(ys), max(xs), max(ys)]
        bbox_fraction = ((bbox[2] - bbox[0] + 1) * (bbox[3] - bbox[1] + 1)) / total
    else:
        bbox = None
        bbox_fraction = 0.0

    hard_errors: list[str] = []
    if path.suffix.lower() != ".png":
        hard_errors.append("file extension is not .png")
    if (width, height) != (1536, 1024):
        hard_errors.append(f"dimensions are {width}x{height}, expected 1536x1024")
    if color_type == 6 and alpha_min != 255:
        hard_errors.append(f"RGBA output is not fully opaque; minimum alpha is {alpha_min}")

    light_fraction = light / total
    diagnostics: list[str] = []
    if not 0.35 <= light_fraction <= 0.98:
        diagnostics.append(f"light-background fraction {light_fraction:.4f} is outside 0.35-0.98")
    if bbox_fraction < 0.20:
        diagnostics.append(f"non-light composition coverage {bbox_fraction:.4f} is below 0.20")
    off_palette_fraction = off_palette / total if palette else None
    if off_palette_fraction is not None and off_palette_fraction > 0.20:
        diagnostics.append(f"off-palette fraction {off_palette_fraction:.4f} exceeds diagnostic 0.20")

    return {
        "file": str(path.resolve()),
        "sha256": hashlib.sha256(data).hexdigest(),
        "size_bytes": len(data),
        "mime_type": "image/png",
        "width": width,
        "height": height,
        "bit_depth": 8,
        "color_mode": "RGB" if color_type == 2 else "RGBA",
        "opaque": color_type == 2 or alpha_min == 255,
        "alpha_min": alpha_min,
        "alpha_max": alpha_max,
        "chunk_types": [kind.decode("ascii") for kind, _ in png_chunks],
        "light_background_fraction": round(light_fraction, 6),
        "nonlight_bbox": bbox,
        "nonlight_bbox_fraction": round(bbox_fraction, 6),
        "off_palette_fraction": round(off_palette_fraction, 6) if off_palette_fraction is not None else None,
        "top_quantized_rgb": [
            {"rgb": list(rgb), "fraction": round(count / total, 6)}
            for rgb, count in quantized.most_common(12)
        ],
        "hard_gate_pass": not hard_errors,
        "hard_errors": hard_errors,
        "diagnostics": diagnostics,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--palette-json", type=Path)
    args = parser.parse_args()
    try:
        value = inspect(args.image.expanduser().resolve(), args.palette_json)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(value, indent=2))
        return 0 if value["hard_gate_pass"] else 1
    except (OSError, ValueError, RasterError, json.JSONDecodeError) as exc:
        print(f"RESULT | FAIL | {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
