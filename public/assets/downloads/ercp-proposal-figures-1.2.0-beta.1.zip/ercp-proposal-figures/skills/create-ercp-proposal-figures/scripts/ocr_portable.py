#!/usr/bin/env python3
"""Run local OCR with Apple Vision or Tesseract and emit one normalized JSON file."""

from __future__ import annotations

import argparse
import csv
import json
import shutil
import struct
import subprocess
import sys
from io import StringIO
from pathlib import Path
from typing import Any


PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def png_size(path: Path) -> tuple[int, int]:
    header = path.read_bytes()[:24]
    if len(header) < 24 or not header.startswith(PNG_SIGNATURE) or header[12:16] != b"IHDR":
        raise ValueError("image is not a decodable PNG")
    return struct.unpack(">II", header[16:24])


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def run_apple_vision(image: Path, out: Path, script: Path) -> bool:
    swift = shutil.which("swift")
    if swift is None or sys.platform != "darwin" or not script.is_file():
        return False
    result = subprocess.run(
        [swift, str(script), str(image), "--out", str(out)],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0 or not out.is_file():
        return False
    value = json.loads(out.read_text(encoding="utf-8"))
    value["status"] = "pass"
    value["available"] = True
    value["verification_mode"] = "deterministic-local-ocr"
    write_json(out, value)
    return True


def run_tesseract(image: Path, out: Path) -> bool:
    executable = shutil.which("tesseract")
    if executable is None:
        return False
    width, height = png_size(image)
    result = subprocess.run(
        [executable, str(image), "stdout", "tsv"],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        return False
    observations: list[dict[str, Any]] = []
    reader = csv.DictReader(StringIO(result.stdout), delimiter="\t")
    for row in reader:
        text = str(row.get("text", "")).strip()
        if not text:
            continue
        try:
            confidence = max(0.0, min(1.0, float(row.get("conf", "-1")) / 100.0))
            left = int(row.get("left", "0"))
            top = int(row.get("top", "0"))
            box_width = int(row.get("width", "0"))
            box_height = int(row.get("height", "0"))
        except ValueError:
            continue
        observations.append(
            {
                "text": text,
                "confidence": confidence,
                "bounding_box": {
                    "x": left / width,
                    "y": 1.0 - ((top + box_height) / height),
                    "width": box_width / width,
                    "height": box_height / height,
                },
            }
        )
    write_json(
        out,
        {
            "status": "pass",
            "available": True,
            "verification_mode": "deterministic-local-ocr",
            "engine": "Tesseract TSV",
            "image": str(image),
            "width": width,
            "height": height,
            "observations": observations,
        },
    )
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    image = args.image.expanduser().resolve()
    out = args.out.expanduser().resolve()
    try:
        if not image.is_file():
            raise ValueError(f"image does not exist: {image}")
        png_size(image)
        vision_script = Path(__file__).resolve().parent / "ocr_image.swift"
        if run_apple_vision(image, out, vision_script) or run_tesseract(image, out):
            value = json.loads(out.read_text(encoding="utf-8"))
            print(f"RESULT | PASS | engine={value.get('engine')} | observations={len(value.get('observations', []))}")
            return 0
        write_json(
            out,
            {
                "status": "unavailable",
                "available": False,
                "verification_mode": "requires-codex-visual-inspection",
                "engine": None,
                "image": str(image),
                "observations": [],
                "note": "No supported local OCR engine was available. Do not treat this as an OCR pass.",
            },
        )
        print("RESULT | UNAVAILABLE | use full-size Codex visual inspection")
        return 0
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        print(f"RESULT | FAIL | {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
