#!/usr/bin/env python3
"""Validate two compact candidate prompts against the frozen execution contract."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


REQUIRED_START = (
    "NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. "
    "COMPLETELY TEXT-FREE FLAT-VECTOR-STYLE RASTER PNG."
)
REQUIRED_END = "NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE."
REQUIRED_SECTIONS = (
    "PURPOSE",
    "SOURCE-LOCKED SCIENCE — DO NOT RENDER AS TEXT",
    "MUST SHOW",
    "COMPOSITION",
    "REFERENCE ASSET:",
    "COLOR AND STYLE",
    "SCIENCE BOUNDARY",
    "OUTPUT",
)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()
    out = run_dir / "validation" / "prompts.json"

    try:
        run = load_json(run_dir / "run.json")
        pregen = load_json(run_dir / "validation" / "pregen.json")
        execution = load_json(run_dir / "analysis" / "execution-contract.json")
        current_analysis_hashes = {
            str(path.relative_to(run_dir)): sha256(path)
            for path in sorted((run_dir / "analysis").glob("*.json"))
        }
        errors: list[str] = []
        if run.get("status") != "pregen_passed" or pregen.get("status") != "pass":
            errors.append("pre-generation validation is not current and passed")
        if pregen.get("analysis_sha256") != current_analysis_hashes:
            errors.append("analysis changed after pre-generation validation")
        if execution.get("only_allowed_text") != []:
            errors.append("execution contract is not label-free")
        if execution.get("visual_brand_policy") != "BRAND_NEUTRAL_PROPOSAL_DRAFT":
            errors.append("execution contract is not brand-neutral")

        plans = {
            str(item.get("candidate_id", "")).casefold(): item
            for item in execution.get("candidate_plans", [])
            if isinstance(item, dict)
        }
        if set(plans) != {"a", "b"}:
            errors.append("execution contract must contain candidate plans A and B")

        prompts: dict[str, str] = {}
        prompt_hashes: dict[str, str] = {}
        for stem, plan_key in (("candidate-a", "a"), ("candidate-b", "b")):
            path = run_dir / "prompts" / f"{stem}.txt"
            if not path.is_file():
                errors.append(f"missing exact prompt: {path}")
                continue
            text = path.read_text(encoding="utf-8").strip()
            prompts[stem] = text
            prompt_hashes[str(path.relative_to(run_dir))] = sha256(path)
            if not text:
                errors.append(f"empty prompt: {stem}")
                continue
            word_count = len(text.split())
            if word_count > 700:
                errors.append(f"{stem} is too restrictive and verbose at {word_count} words; maximum is 700")
            if not text.startswith(REQUIRED_START):
                errors.append(f"{stem} does not begin with the exact no-text hard gate")
            if not text.endswith(REQUIRED_END):
                errors.append(f"{stem} does not end with the exact no-text hard gate")
            for section in REQUIRED_SECTIONS:
                if section not in text:
                    errors.append(f"{stem} lacks required compact-prompt section: {section}")
            for key, value in execution.get("semantic_capsule", {}).items():
                if f"{key}: {value}" not in text:
                    errors.append(f"{stem} lacks exact semantic-capsule line: {key}")
            for value in execution.get("allowed_visuals", []):
                if value not in text:
                    errors.append(f"{stem} lacks source-supported visual: {value}")

            plan = plans.get(plan_key, {})
            story_spine = plan.get("story_spine")
            if isinstance(story_spine, str) and story_spine not in text:
                errors.append(f"{stem} lacks its candidate story spine")
            reference = plan.get("style_reference", {}) if isinstance(plan, dict) else {}
            asset = reference.get("asset") if isinstance(reference, dict) else None
            if isinstance(asset, str) and f"REFERENCE ASSET: {asset}" not in text:
                errors.append(f"{stem} lacks its selected reference asset")
            palette_strategy = execution.get("palette_strategy")
            if isinstance(palette_strategy, str) and palette_strategy not in text:
                errors.append(f"{stem} lacks the planned cohesive palette strategy")

            required_output = "One opaque landscape raster PNG, 1536 × 1024."
            if required_output not in text:
                errors.append(f"{stem} lacks the fixed raster output rule")
            if "No organization branding." not in text:
                errors.append(f"{stem} does not explicitly preserve brand neutrality")
            if text.count("NEVER USE ANY LABELS OR TEXT") < 2:
                errors.append(f"{stem} must repeat the no-text gate at start and end")

        if len(prompts) == 2 and prompts["candidate-a"] == prompts["candidate-b"]:
            errors.append("candidate prompts are identical; layout and composition must differ")

        result = {
            "status": "pass" if not errors else "fail",
            "validated_at": datetime.now(timezone.utc).isoformat(),
            "errors": errors,
            "analysis_sha256": current_analysis_hashes,
            "prompt_sha256": prompt_hashes,
            "word_counts": {stem: len(text.split()) for stem, text in prompts.items()},
        }
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        run["status"] = "prompts_validated" if not errors else "prompt_validation_failed"
        run["prompts_validated_at"] = result["validated_at"]
        (run_dir / "run.json").write_text(json.dumps(run, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 0 if not errors else 1
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f"RESULT | FAIL | {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
