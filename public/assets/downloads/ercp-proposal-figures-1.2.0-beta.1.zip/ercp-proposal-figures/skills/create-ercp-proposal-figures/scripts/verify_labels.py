#!/usr/bin/env python3
"""Compare local OCR output with the frozen closed label inventory."""

from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path
from typing import Any


TOKEN = re.compile(r"[a-z0-9]+(?:[-'][a-z0-9]+)*")


def normalize_phrase(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value).casefold()
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized


def tokens(values: list[str]) -> Counter[str]:
    return Counter(token for value in values for token in TOKEN.findall(normalize_phrase(value)))


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ocr", type=Path, required=True)
    parser.add_argument("--allowed", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--min-confidence", type=float, default=0.20)
    args = parser.parse_args()

    try:
        ocr = load_json(args.ocr.expanduser().resolve())
        allowed = load_json(args.allowed.expanduser().resolve())
        if allowed != []:
            raise ValueError("allowed-text JSON must equal the empty list for this label-free product")
        if ocr.get("available") is not True:
            raise ValueError("deterministic OCR is unavailable; use and record full-size Codex visual inspection")
        observations = ocr.get("observations", [])
        if not isinstance(observations, list):
            raise ValueError("OCR observations must be a list")

        recognized: list[str] = []
        ignored: list[dict[str, Any]] = []
        for item in observations:
            if not isinstance(item, dict) or not isinstance(item.get("text"), str):
                raise ValueError("each OCR observation must contain text")
            confidence = float(item.get("confidence", 0.0))
            if confidence >= args.min_confidence:
                recognized.append(item["text"])
            else:
                ignored.append({"text": item["text"], "confidence": confidence})

        allowed_phrases = Counter(normalize_phrase(item) for item in allowed)
        recognized_phrases = Counter(normalize_phrase(item) for item in recognized)
        phrase_match = allowed_phrases == recognized_phrases
        allowed_tokens = tokens(allowed)
        recognized_tokens = tokens(recognized)
        token_match = allowed_tokens == recognized_tokens
        passed = phrase_match or token_match

        missing_tokens = list((allowed_tokens - recognized_tokens).elements())
        unexpected_tokens = list((recognized_tokens - allowed_tokens).elements())
        result = {
            "status": "pass" if passed else "fail",
            "image": ocr.get("image"),
            "ocr_file": str(args.ocr.expanduser().resolve()),
            "allowed_file": str(args.allowed.expanduser().resolve()),
            "minimum_confidence": args.min_confidence,
            "verification_mode": ocr.get("verification_mode", "deterministic-local-ocr"),
            "allowed_text": allowed,
            "recognized_text": recognized,
            "ignored_low_confidence": ignored,
            "phrase_inventory_match": phrase_match,
            "token_inventory_match": token_match,
            "missing_tokens": missing_tokens,
            "unexpected_tokens": unexpected_tokens,
        }
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if passed else 1
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        print(f"RESULT | FAIL | {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
