#!/usr/bin/env python3
"""Verify every archived evidence quotation against the hashed source file."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import unicodedata
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree


TEXT_SUFFIXES = {".md", ".txt", ".rst"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalize(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).replace("\u00ad", "")
    return re.sub(r"\s+", " ", value).strip()


def read_docx(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        try:
            root = ElementTree.fromstring(archive.read("word/document.xml"))
        except KeyError as exc:
            raise ValueError("DOCX has no word/document.xml") from exc
    paragraphs: list[str] = []
    for paragraph in root.iter():
        if paragraph.tag.rsplit("}", 1)[-1] != "p":
            continue
        runs = [node.text or "" for node in paragraph.iter() if node.tag.rsplit("}", 1)[-1] == "t"]
        if runs:
            paragraphs.append("".join(runs))
    return "\n".join(paragraphs)


def read_pdf(path: Path) -> str:
    executable = shutil.which("pdftotext")
    if executable is None:
        raise ValueError("pdftotext is required to verify PDF quotations")
    result = subprocess.run(
        [executable, str(path), "-"],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise ValueError(f"pdftotext failed: {result.stderr.strip()}")
    return result.stdout


def extract_text(path: Path) -> tuple[str, str]:
    suffix = path.suffix.lower()
    if suffix in TEXT_SUFFIXES:
        return path.read_text(encoding="utf-8"), "plain-text"
    if suffix == ".docx":
        return read_docx(path), "docx-document-xml"
    if suffix == ".pdf":
        return read_pdf(path), "pdftotext"
    raise ValueError(f"unsupported source type for quote verification: {suffix or '<none>'}")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()
    out = run_dir / "validation" / "source-quotes.json"

    try:
        run = load_json(run_dir / "run.json")
        source_lock_path = run_dir / "analysis" / "source-lock.json"
        source_lock = load_json(source_lock_path)
        source = Path(run["source"]["path"]).expanduser().resolve()
        recorded_hash = run["source"]["sha256"]
        current_hash = sha256(source)
        if current_hash != recorded_hash:
            raise ValueError("source file hash changed after run initialization")
        extracted, extraction_method = extract_text(source)
        normalized_source = normalize(extracted)

        evidence = source_lock.get("evidence", [])
        if not isinstance(evidence, list) or not evidence:
            raise ValueError("source-lock evidence is empty")
        results: list[dict[str, Any]] = []
        for index, entry in enumerate(evidence):
            if not isinstance(entry, dict):
                raise ValueError(f"evidence entry {index} is not an object")
            claim_id = entry.get("claim_id")
            quote = entry.get("exact_quote")
            section = entry.get("section")
            if not isinstance(claim_id, str) or not claim_id.strip():
                raise ValueError(f"evidence entry {index} has no claim_id")
            if not isinstance(quote, str) or not quote.strip():
                raise ValueError(f"evidence entry {index} has no exact_quote")
            if not isinstance(section, str) or not section.strip():
                raise ValueError(f"evidence entry {index} has no section")
            normalized_quote = normalize(quote)
            normalized_section = normalize(section)
            quote_position = normalized_source.find(normalized_quote)
            section_position = normalized_source.rfind(normalized_section, 0, max(quote_position, 0) + 1)
            results.append(
                {
                    "claim_id": claim_id,
                    "section": section,
                    "normalized_quote_sha256": hashlib.sha256(normalized_quote.encode("utf-8")).hexdigest(),
                    "quote_found": quote_position >= 0,
                    "section_found_before_quote": quote_position >= 0 and section_position >= 0,
                }
            )

        failed = [
            item["claim_id"]
            for item in results
            if not item["quote_found"] or not item["section_found_before_quote"]
        ]
        report = {
            "status": "pass" if not failed else "fail",
            "source": str(source),
            "source_sha256": current_hash,
            "source_lock_sha256": sha256(source_lock_path),
            "extraction_method": extraction_method,
            "evidence_count": len(results),
            "verified_claim_ids": [
                item["claim_id"]
                for item in results
                if item["quote_found"] and item["section_found_before_quote"]
            ],
            "failed_claim_ids": failed,
            "results": results,
        }
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(report, indent=2))
        return 0 if not failed else 1
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile, ElementTree.ParseError, json.JSONDecodeError) as exc:
        report = {"status": "fail", "error": str(exc)}
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print(f"RESULT | FAIL | {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
