#!/usr/bin/env swift

import Foundation
import ImageIO
import Vision

struct UsageError: Error, CustomStringConvertible {
    let description: String
}

func fail(_ message: String, code: Int32 = 2) -> Never {
    FileHandle.standardError.write(Data(("RESULT | FAIL | \(message)\n").utf8))
    exit(code)
}

let arguments = Array(CommandLine.arguments.dropFirst())
guard arguments.count == 3, arguments[1] == "--out" else {
    fail("usage: ocr_image.swift <image> --out <json>")
}

let imageURL = URL(fileURLWithPath: arguments[0]).standardizedFileURL
let outputURL = URL(fileURLWithPath: arguments[2]).standardizedFileURL
guard FileManager.default.fileExists(atPath: imageURL.path) else {
    fail("image does not exist: \(imageURL.path)")
}

guard let source = CGImageSourceCreateWithURL(imageURL as CFURL, nil),
      let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
    fail("could not decode image: \(imageURL.path)")
}

let request = VNRecognizeTextRequest()
request.recognitionLevel = .accurate
request.usesLanguageCorrection = false
request.recognitionLanguages = ["en-US"]

do {
    let handler = VNImageRequestHandler(cgImage: image, orientation: .up, options: [:])
    try handler.perform([request])
} catch {
    fail("Vision OCR failed: \(error)")
}

let observations = (request.results ?? []).compactMap { observation -> [String: Any]? in
    guard let candidate = observation.topCandidates(1).first else { return nil }
    let box = observation.boundingBox
    return [
        "text": candidate.string,
        "confidence": Double(candidate.confidence),
        "bounding_box": [
            "x": Double(box.origin.x),
            "y": Double(box.origin.y),
            "width": Double(box.size.width),
            "height": Double(box.size.height),
        ],
    ]
}.sorted { left, right in
    let leftBox = left["bounding_box"] as! [String: Double]
    let rightBox = right["bounding_box"] as! [String: Double]
    if abs(leftBox["y"]! - rightBox["y"]!) > 0.01 {
        return leftBox["y"]! > rightBox["y"]!
    }
    return leftBox["x"]! < rightBox["x"]!
}

let result: [String: Any] = [
    "status": "pass",
    "available": true,
    "verification_mode": "deterministic-local-ocr",
    "engine": "Apple Vision VNRecognizeTextRequest accurate",
    "image": imageURL.path,
    "width": image.width,
    "height": image.height,
    "observations": observations,
]

do {
    let data = try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys])
    try FileManager.default.createDirectory(
        at: outputURL.deletingLastPathComponent(),
        withIntermediateDirectories: true
    )
    try data.write(to: outputURL, options: .atomic)
    FileHandle.standardOutput.write(Data(("RESULT | PASS | observations=\(observations.count) | out=\(outputURL.path)\n").utf8))
} catch {
    fail("could not write OCR JSON: \(error)")
}
