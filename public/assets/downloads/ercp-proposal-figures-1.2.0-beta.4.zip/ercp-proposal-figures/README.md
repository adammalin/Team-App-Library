# ERCP Proposal Figures Agent Plugin

This Agent Plugins 1.0 package adds one Codex skill: `create-ercp-proposal-figures`.

It turns a substantive DOE Office of Science ERCP or ECRP proposal draft into one source-grounded Figure 1 decision-aid concept. The visual deliverable is always a completely label-free, opaque 1536 × 1024 raster PNG produced with Codex image generation. It is never an SVG, vector file, slide, PDF, final scientific figure, or submission-ready artifact.

## What the workflow does

1. Opens and reads the attached proposal rather than relying on its filename or a user summary.
2. Locks the scientific system, gap, objectives, primary capability, decisive relationship, validation logic, endpoint, DOE payoff, and evidence.
3. Builds one simple visual funding argument that answers “Why fund this?” using three to five required proposal-specific elements and at most one compact credibility cue.
4. Compares linear sequence, feedback loop, integration map, and outcomes/impact layouts, then plans two meaningfully different candidates.
5. Uses Vision, Gap, Objectives, Approach, and Impact colors as an internal wireframe check while allowing a cohesive, proposal-appropriate final palette.
6. Selects from eight legacy planning references and translates only their layout topology, connector language, negative space, and color rhythm; attaches a separate certified flat-style target so legacy perspective, glow, shadows, and dimensional rendering do not transfer.
7. Builds both bounded image prompts deterministically from the frozen execution contract, generates two internal label-free candidates, audits literal visible depth cues before semantic scoring, treats restrained non-dimensional tonal variation as a review note, permits at most one localized repair, and returns the strongest usable PNG.
8. Archives the source hash, prompts, candidates, QA records, and selected result in a workspace-bound run folder, with a final check that exposes only one deliverable PNG.

The package also includes eight legacy layout-reference PNGs, one certified flat-style target PNG, four fictional qualification fixtures, a deterministic self-test, and a real-reference evaluation protocol.

## Version 1.2.0-beta.4 lesser-model and draft-handoff update

- The deterministic prompt builder now sends only the three to five required decision-bearing visual forms to generation and suppresses optional credibility insets, return paths, and secondary pipelines on the default lesser-model path.
- The style rubric now distinguishes restrained same-hue tonal variation from dimensional rendering. A front-facing matte shape may retain subtle tonal polish as an advisory redraw note.
- Perspective, visible depth, simulated illumination, gloss, glow, reflections, and cast shadows remain hard qualification failures.
- `graphic_designer_handoff_value` no longer fails merely because an otherwise useful collaboration draft contains acceptable tonal variation.

## Version 1.2.0-beta.3 reliability update

This build also keeps Apple Vision compiler caches inside a writable temporary directory. When macOS still blocks the Vision service in a sandbox, the QA gate records OCR as unavailable and requires full-size Codex visual inspection instead of reporting a false pass.

## Version 1.2.0-beta.2 reliability update

- Apple Vision OCR output now declares deterministic availability and verification mode directly, so `verify_labels.py` can consume it without a metadata fallback.
- The Codex plugin and skill starter prompts are both 108 characters and comply with the 128-character interface limit.
- The self-test now checks both contracts. Figure-generation behavior, source-lock rules, visual references, and the qualified output style are unchanged from `1.2.0-beta.1`.

## Start a Figure 1

Attach the substantive proposal draft to a Codex task and say:

> Use $create-ercp-proposal-figures on the proposal attached to this message. Create one brand-neutral, completely label-free, flat-2D Figure 1 PNG with one dominant “Why fund this?” story path. Use three to five recognizable proposal-specific elements and at most one compact credibility cue. Attach only the certified flat-style target, never the legacy planning references, to generation. Prefer matte solid fills, but allow subtle same-hue tonal variation that remains visibly depthless. Fail qualification for perspective, side or top faces, offset depth stacks, dimensional shading or highlights, illuminated-screen effects, glow, reflections, cast shadows, or an unclear thumbnail story.

An existing companion figure is optional. When none is supplied, the skill uses the bundled visual family. The source files remain read-only.

For a first-time recipient, attach the versioned plugin ZIP and proposal together and use the one-shot bootstrap prompt in `INSTALL-PROMPT.md`. It installs the plugin and tells Codex to follow the packaged skill directly for that same task.

## Product boundary

The result is a brand-neutral AI-generated collaboration draft for researcher interpretation, graphic-designer redraw, and scientist/content-owner verification. The package does not create Roadmaps, apply ORNL or other organization branding, or modify Custom GPTs or external systems.

## Package layout

```text
plugin.json
.codex-plugin/plugin.json
skills/
  create-ercp-proposal-figures/
    SKILL.md
    agents/openai.yaml
    assets/
    references/
    scripts/
```

The root `plugin.json` follows Agent Plugins 1.0. The `.codex-plugin` manifest provides Codex-specific presentation metadata without changing the portable core manifest.

## Validate the package

Run the packaged deterministic test:

```bash
python3 skills/create-ercp-proposal-figures/scripts/self_test.py
```

See `skills/create-ercp-proposal-figures/references/testing-and-evaluation.md` for the frozen live-image qualification checks and the boundary between script validation and stochastic visual quality.
