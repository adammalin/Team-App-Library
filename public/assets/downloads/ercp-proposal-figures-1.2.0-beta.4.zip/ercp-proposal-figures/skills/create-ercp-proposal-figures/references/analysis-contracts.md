# Source-locked analysis contracts

Complete these JSON files before generation. Use exact proposal wording where required and `NOT SUPPORTED` when the proposal does not support a claim.

## `source-lock.json`

```json
{
  "status": "pass",
  "proposal_title": "",
  "distinctive_terms": ["", "", "", ""],
  "scientific_vision": "",
  "scientific_system": "",
  "consequential_gap": "",
  "objectives": [""],
  "primary_capability": "",
  "decisive_relationship": "",
  "validation_logic": "",
  "scientific_endpoint": "",
  "doe_payoff": "",
  "strengths": ["", ""],
  "secondary_methods": [{"name": "", "limited_role": ""}],
  "allowed_subjects": [""],
  "allowed_relationships": [""],
  "forbidden_inferences": [""],
  "evidence": [
    {"claim_id": "C01", "claim": "", "exact_quote": "", "section": ""}
  ]
}
```

Map each substantive field to evidence. Preserve proposed work versus achieved results. Do not broaden DOE relevance beyond the proposal.

## `science-verification.json`

```json
{
  "status": "pass",
  "proposal_identity_checksum": {
    "scientific_system": "",
    "primary_capability": "",
    "decisive_relationship": "",
    "validation_logic": "",
    "scientific_endpoint": "",
    "doe_payoff": ""
  },
  "renderer_capsule": {
    "SYSTEM": "",
    "PRIMARY CAPABILITY": "",
    "DECISIVE RELATIONSHIP": "",
    "ENDPOINT": "",
    "DO NOT SUBSTITUTE": ""
  },
  "claim_evidence_matrix": [{"planned_item": "", "claim_id": "C01"}],
  "prohibited_substitutions": [""],
  "secondary_method_suppression_pass": true,
  "interchangeability_test_pass": true
}
```

Copy the first four renderer-capsule values from the verified identity without creative rewriting. Make `DO NOT SUBSTITUTE` proposal-specific and concise.

## `funding-case.json`

```json
{
  "status": "pass",
  "funding_thesis": "",
  "reviewer_answers": {
    "fundamental_advancement": "",
    "why_it_should_work": "",
    "credibility": "",
    "doe_or_sponsor_payoff": ""
  },
  "strengths": ["", ""]
}
```

This is internal decision logic. Do not render it as copy.

## `visual-brief.json`

```json
{
  "status": "pass",
  "funding_story_spine": "",
  "visual_object_inventory": [
    {
      "source_term": "",
      "claim_id": "C01",
      "visual_form": "",
      "recognition_cue": "",
      "required": true
    }
  ],
  "layout_evaluation": [
    {"family": "LINEAR_SEQUENCE", "fit": "primary", "reason": ""},
    {"family": "INTEGRATION_MAP", "fit": "alternate", "reason": ""}
  ],
  "candidate_plans": [
    {
      "candidate_id": "A",
      "layout_family": "LINEAR_SEQUENCE",
      "story_spine": "",
      "style_reference": {
        "asset": "assets/style-references/example.png",
        "use_mode": "LAYOUT_AND_STYLE",
        "transfer": [""],
        "prohibited_transfer": [""]
      },
      "spatial_blueprint": [
        {"id": "REGION_1", "semantic_anchor": "PRIMARY CAPABILITY", "claim_id": "C01", "geometry": ""}
      ]
    },
    {
      "candidate_id": "B",
      "layout_family": "OUTCOMES_IMPACT_FOCUS",
      "story_spine": "",
      "style_reference": {
        "asset": "assets/style-references/example.png",
        "use_mode": "LAYOUT_AND_STYLE",
        "transfer": [""],
        "prohibited_transfer": [""]
      },
      "spatial_blueprint": [
        {"id": "REGION_1", "semantic_anchor": "PRIMARY CAPABILITY", "claim_id": "C01", "geometry": ""}
      ]
    }
  ],
  "color_role_ledger": {
    "VISION": {"scientific_meaning": "", "claim_id": "C01", "visual_carrier": "", "wireframe_anchor": "#C6DCCC", "image_treatment": ""},
    "GAP": {"scientific_meaning": "", "claim_id": "C02", "visual_carrier": "", "wireframe_anchor": "#FE5000", "image_treatment": ""},
    "OBJECTIVES": {"scientific_meaning": "", "claim_id": "C03", "visual_carrier": "", "wireframe_anchor": "#B36CFF", "image_treatment": ""},
    "APPROACH": {"scientific_meaning": "", "claim_id": "C04", "visual_carrier": "", "wireframe_anchor": "#FF9E1B", "image_treatment": ""},
    "IMPACT": {"scientific_meaning": "", "claim_id": "C05", "visual_carrier": "", "wireframe_anchor": "#BFD1D3", "image_treatment": ""}
  },
  "palette_strategy": "",
  "validation_relationship_cue": {"scientific_meaning": "", "claim_id": "C06", "geometry": ""},
  "visual_brand_policy": "BRAND_NEUTRAL_PROPOSAL_DRAFT",
  "allowed_text": [],
  "allowed_visuals": [""],
  "must_preserve": [""],
  "forbidden": [""],
  "companion_transfer": [],
  "companion_prohibited_transfer": [],
  "logo_state": "OMIT",
  "canvas": {"width": 1536, "height": 1024},
  "candidate_count": 2,
  "final_artifact_count": 1,
  "repair_ceiling": 1
}
```

### Visual-object rules

- Include three to six objects or phenomena.
- Mark three to five entries `required: true`.
- Allow at most one entry with `required: false`; use it as one compact credibility cue rather than a second pipeline.
- Each required entry needs a proposal-specific recognition cue, not merely a color or geometric primitive.
- Link each item to a verified evidence claim.

### Layout rules

Evaluate at least two of `LINEAR_SEQUENCE`, `FEEDBACK_LOOP`, `INTEGRATION_MAP`, `OUTCOMES_IMPACT_FOCUS`, or `PROPOSAL_NATIVE`. Mark exactly one `primary` and at least one `alternate`. Candidate A uses the primary family; Candidate B uses an alternate family. Their story spines and spatial blueprints must differ meaningfully.

### Reference rules

`use_mode` must be `LAYOUT_AND_STYLE`. A bundled asset must exist under `assets/style-references/`; a user-supplied reference may use an absolute path. Transfer lists may include composition grammar and illustration finish. Prohibited transfer must protect science, claims, text, evidence, and branding.

### Color rules

The five `wireframe_anchor` values remain fixed only as internal semantic markers. `image_treatment` describes the intended visible carrier or color relationship and may use any cohesive palette, shared color, overlap, or transition that supports the science. `palette_strategy` explains the overall color logic.

Write `palette.json` as the planned final-image diagnostic palette: a JSON list of three to twelve six-digit hex colors, including the white or near-white background. It does not need to contain the five wireframe anchors.

`allowed_text` and `allowed-text.json` must equal `[]`. Keep `visual_brand_policy` and `logo_state` exact.

## `execution-contract.json`

```json
{
  "status": "pass",
  "semantic_capsule": {},
  "only_allowed_text": [],
  "funding_story_spine": "",
  "visual_object_inventory": [],
  "layout_evaluation": [],
  "candidate_plans": [],
  "color_role_ledger": {},
  "palette_strategy": "",
  "validation_relationship_cue": {},
  "visual_brand_policy": "BRAND_NEUTRAL_PROPOSAL_DRAFT",
  "allowed_visuals": [],
  "logo_state": "OMIT",
  "must_preserve": [],
  "forbidden": [],
  "output": {
    "candidate_count": 2,
    "final_artifact_count": 1,
    "format": "PNG",
    "artifact_type": "raster",
    "width": 1536,
    "height": 1024,
    "opacity": "opaque"
  },
  "repair_ceiling": 1
}
```

Copy corresponding fields from `science-verification.json` and `visual-brief.json` without rewriting them. The pre-generation validator rejects stale or improvised contracts.
