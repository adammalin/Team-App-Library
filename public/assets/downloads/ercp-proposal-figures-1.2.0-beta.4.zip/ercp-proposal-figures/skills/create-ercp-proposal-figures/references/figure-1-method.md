# DOE Figure 1 decision-aid method

## Purpose

Figure 1 is the proposal's visual funding case. It should help a reviewer see the fundamental advancement, why it can work, what creates confidence, and why the outcome matters to DOE or the sponsor.

Build a decision aid rather than a manuscript figure, methods inventory, Roadmap, dashboard, or decorated abstract.

## Build order

1. Read the substantive proposal.
2. Extract Vision, Gap, Objectives, distinctive Approach or hypothesis, credible success logic, and Impact.
3. Preserve source support and separate the primary capability from supporting methods.
4. Write one funding thesis and two fundable strengths.
5. Convert the proposal's important nouns and phenomena into recognizable visual objects.
6. Choose the layout family that best expresses the primary relationship.
7. Develop two visual drafts with different credible structures.
8. Run the image-only 30-second reviewer test.
9. Simplify non-decision detail and retain the strongest draft.

## Four useful layout families

These are options, not a hierarchy and not forbidden templates:

- **Linear sequence:** best when the proposal turns an input, limitation, or unresolved state into a clear outcome through a distinctive capability.
- **Feedback loop:** best when recurrence, learning, control, or iterative validation is central to the science.
- **Integration map:** best when several scales, measurements, mechanisms, or systems become valuable through integration.
- **Outcomes/impact focus:** best when one capability supports several important scientific consequences or one dominant sponsor outcome.

Choose based on the main funding story. Do not elevate a secondary validation loop over a clearer primary transformation. A familiar layout is acceptable when its contents and relationships are unmistakably proposal-specific.

## Recognizable proposal elements

Before composing, create a visual-object inventory of three to six source-supported elements. Mark three to five decision-bearing elements as required and allow at most one optional credibility cue. Prefer literal or scientifically recognizable forms when possible:

- the actual material, detector, interface, instrument, field, boundary, or data stream;
- the distinctive capability or intervention;
- the decisive transformation, coupling, selection, comparison, or integration;
- the validation or credibility cue; and
- the scientific or sponsor-relevant endpoint.

Simplify these forms for clarity, but do not replace them with abstract color fields, repeated dots, generic networks, or stock symbols when those substitutions hide the proposal's identity. Integrate credibility into the main story or one compact inset; never build a second methods pipeline. Icons and visual metaphors are useful when they are scientifically appropriate and remain anchored to proposal-specific content.

## Color as semantic scaffolding

Use the presentation's Vision, Gap, Objectives, Approach, and Impact colors while planning the wireframe. They help verify that the proposal argument is complete.

Do not force five exact colors, five boxes, or five separate final-image regions. The finished concept should use a cohesive palette suited to its subject and selected reference. A role may be communicated through form, position, transition, boundary, emphasis, or a shared color relationship. Record the actual color-role interpretation in chat.

## Thirty-second reviewer test

At thumbnail size, a cold reader should recover:

1. the fundamental advancement;
2. why the approach or hypothesis should work;
3. what makes success credible without invented evidence;
4. the scientific and DOE or sponsor payoff; and
5. two proposal-specific strengths.

If the prompt, caption, color ledger, or chat explanation must rescue the image, it has not passed.

## Text-free strategy

The AI-generated collaboration draft is completely label-free. Carry meaning through recognizable objects, hierarchy, continuity, separation, recurrence, boundaries, connectors, and visual transformation. The eventual graphic designer may add verified labels and a persuasive caption outside this workflow.

## Visual language

Aim for the quality demonstrated by the bundled examples:

- polished flat-vector-style raster illustration;
- white or near-white field;
- a few large, readable scientific forms;
- coherent connector language and one dominant story spine;
- generous negative space;
- coordinated color with clear role differentiation; and
- minimal flat translucency when it improves recognition.

Keep major objects front-facing or orthographic with solid fills and consistent line weight. Avoid isometric perspective, extrusion, bevels, metallic or glass materials, volumetric lighting, bloom or glow, cast shadows, photorealism, glossy dashboards, ornamental UI, irrelevant stock metaphors, and fabricated scientific precision. Do not reject useful arrows, icons, layers, networks, contours, devices, facilities, data symbols, or repeated particles merely because they are common visual forms; reject them only when they are unsupported, misleading, or used instead of the proposal's real content.

## Scientific boundary

Do not fabricate plots, spectra, microscopy, microstructure, molecular structures, measurements, scale bars, facilities, results, or achieved performance. A source-supported instrument, facility context, molecular motif, network, or physical structure may be represented as a simplified concept illustration, provided it is not presented as measured evidence or exact geometry.

AI supplies composition drafts. Researchers verify the science; graphic designers redraw and polish the selected concept.
