# Built-in image execution contracts

## Candidate strategy

Generate two internal candidates with separate image-generation calls:

- Candidate A uses the strongest layout family and closest reference.
- Candidate B uses a meaningfully different credible layout or reference.

Keep proposal facts, required objects, output format, and scientific boundaries the same. Let composition, reading direction, grouping, and visual metaphor vary.

## Compact generation prompt

Build prompts with `scripts/build_prompts.py`; do not ask the model to reproduce this boilerplate by hand. Prompts must contain 250–500 words. The builder includes only required visual objects in `MUST SHOW`, drops optional credibility regions, and uses the frozen funding story instead of any candidate sentence that introduces a return path. The builder uses these sections and exact first and last lines:

```text
NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. COMPLETELY TEXT-FREE FLAT-2D EDITORIAL-VECTOR-STYLE RASTER PNG.

PURPOSE
Create one persuasive DOE Office of Science proposal Figure 1 collaboration draft. The visual funding story is: [one sentence].

SOURCE-LOCKED SCIENCE — DO NOT RENDER AS TEXT
SYSTEM: ...
PRIMARY CAPABILITY: ...
DECISIVE RELATIONSHIP: ...
ENDPOINT: ...
DO NOT SUBSTITUTE: ...

MUST SHOW
- [three to five recognizable, source-supported decision objects or phenomena]
- [at most one compact credibility cue]

COMPOSITION
[Candidate-specific reading order, hierarchy, relationships, and spatial blueprint. Require one dominant story path. Integrate credibility into that path or one compact inset; do not create a second pipeline.]

REFERENCE ASSET: [path or NONE]
REFERENCE USE: LAYOUT-ONLY PLANNING AID; DO NOT ATTACH A BUNDLED REFERENCE TO GENERATION.
Translate only this written topology from the reference: [short transfer list]. Replace all depicted science with the proposal-specific objects above. Do not copy its gradients, glow, depth, labels, claims, logos, data, or unsupported content.

STYLE ASSET: assets/style-references/ref-flat-2d-style-target.png
Attach only this certified flat-style PNG. Transfer its front-facing geometry, matte fills, consistent navy outlines, white space, and absence of depth cues. Do not copy its generic objects or layout.

COLOR AND STYLE
[Cohesive palette strategy.] Flat 2D editorial vector aesthetic. Treat every major object as a paper-cut icon seen straight on. A rectangle may show only its front face. Prefer solid or restrained same-hue fills, consistent line weight, generous negative space, clear connectors, and minimal flat translucency. Subtle tonal variation may remain inside a front-facing shape when it stays matte and depthless. Never show a top or side face, offset stacked copies that imply thickness, perspective convergence, dimensional shading or highlights, an illuminated-screen effect, a glow or halo, a reflection, or a cast shadow. No organization branding.

SCIENCE BOUNDARY
Show proposed relationships as concepts, not achieved measurements. Do not invent data, plots, microscopy, exact structures, performance values, facilities, or evidence not supported by the proposal. Do not add Roadmap years, thrusts, milestones, or task labels. Avoid unrelated stock metaphors that replace the required proposal objects.

OUTPUT
One opaque landscape raster PNG, 1536 × 1024. No title, caption, labels, letters, numerals, units, axes, legend, logo, watermark, pseudo-text, alternate, comparison, document, SVG, or vector data.

NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
```

Include the exact five renderer-capsule lines. Include every required visual object and each candidate's exact story spine. Keep `MUST SHOW` to three through six bullets total. Do not include proposal quotations, the abstract, evidence tables, role names, fixed wireframe hex colors, QA instructions, or exhaustive lists of generic motifs.

Do not pass the eight legacy bundled references to the image-generation call. They are planning material only, and the prompt's written spatial blueprint carries the approved topology. Pass `assets/style-references/ref-flat-2d-style-target.png` as the only image reference for both candidates. A user-supplied style reference may replace it only after its major objects pass every dimensional-style tripwire in the QA rubric.

## Useful visual freedom

The image model may use:

- linear, circular, branching, nested, convergent, or integrated composition;
- arrows, flow bands, return paths, boundaries, insets, simplified devices, and scientifically appropriate icons;
- repeated particles, nodes, layers, contour-like fields, data symbols, facility silhouettes, molecular motifs, or networks when they are supported and help identify the proposal;
- flat overlays, simple cutaway layers, and minimal same-family translucency without rendered depth; and
- a palette inspired by the selected reference or a supplied companion, provided the output does not imitate an organization brand.

Do not ban a visual form simply because it can be generic. Make it proposal-specific through the objects, relationships, hierarchy, and endpoint.

## Repair contracts

### Localized defect

Use one edit only after visually inspecting the selected local PNG:

```text
NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
Use case: precise localized image correction.

CHANGE ONLY: [specific visible defect and bounded region].
PRESERVE: canvas, crop, story spine, proposal-specific objects, science, hierarchy, palette character, connectors, negative space, and every successful region.

SOURCE-LOCKED SCIENCE — DO NOT RENDER AS TEXT
[unchanged five renderer-capsule lines]

Do not add any other object, claim, text, number, logo, mark, or style change.
NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
```

Archive the exact edit prompt and save the result beside the source as `candidate-<id>-edit-01.png`. Never overwrite the source candidate.

Do not use localized editing for a missing primary capability, unrecognizable scientific system, wrong endpoint, weak story spine, or broadly generic composition.

### Whole-image flat-style normalization

Use `scripts/build_flat_style_repair_prompt.py` only when the saved evaluation proves that every non-style hard gate passes, all reviewer questions pass, every reconciled object is recognizable, and the only observed style failures are dimensional shading/highlights, glow, or shadows. Acceptable contained tonal variation is advisory and does not justify spending the edit. This edit may flatten dimensional surface treatment across the canvas, but it may not alter layout, objects, science, hierarchy, or connectors.

Attach the original candidate first and `assets/style-references/ref-flat-2d-style-target.png` second. Use the generated prompt exactly. Save the returned original as `candidate-<id>-edit-01.png`, never overwrite the generated candidate, and evaluate the edited pixels from scratch. If the edit changes meaning, composition, object count, endpoint, or connector logic, reject it.

## Save-path rule

Image generation writes under client-managed storage first. Copy the original returned file into the run directory before inspection. Preserve its bytes before hashing and QA.
