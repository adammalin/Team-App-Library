#!/usr/bin/env python3
"""Build one tightly gated whole-image flat-style normalization prompt."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


STYLE_ONLY_GATES = {"flat_scientific_editorial_style", "graphic_designer_handoff_value"}
REQUIRED_HARD_GATES = {
    "attachment_grounding",
    "science_fidelity",
    "primary_capability_fidelity",
    "secondary_method_suppression",
    "decisive_relationship_visible",
    "scientific_endpoint_visible",
    "claim_evidence_reconciliation",
    "closed_text_inventory",
    "five_role_color_fidelity",
    "brand_neutral_output",
    "style_reference_boundary",
    "no_fabricated_evidence",
    "no_roadmap_logic",
    "no_unauthorized_marks",
    "no_generic_template_or_stock_metaphor",
    "flat_scientific_editorial_style",
    "one_dominant_hierarchy",
    "thumbnail_reviewer_test",
    "graphic_designer_handoff_value",
}
REQUIRED_STYLE_FLAGS = {
    "nonfrontal_major_object",
    "visible_side_or_top_face",
    "offset_stacked_depth",
    "dimensional_shading_or_highlight_on_major_object",
    "glow_halo_or_illuminated_screen",
    "cast_shadow_or_reflection",
    "contained_nondimensional_tonal_variation",
    "competing_secondary_pipeline",
}
SURFACE_STYLE_FLAGS = {
    "dimensional_shading_or_highlight_on_major_object",
    "glow_halo_or_illuminated_screen",
    "cast_shadow_or_reflection",
}


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--candidate", choices=("a", "b"), required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()
    stem = f"candidate-{args.candidate}"
    evaluation = load_json(run_dir / "evaluations" / f"{stem}.json")
    contract = load_json(run_dir / "analysis" / "execution-contract.json")

    gates = evaluation.get("hard_gates", {})
    if not isinstance(gates, dict) or set(gates) != REQUIRED_HARD_GATES:
        raise SystemExit("candidate hard-gate inventory is incomplete")
    failed_gates = {name for name, value in gates.items() if value is not True}
    if not failed_gates or not failed_gates <= STYLE_ONLY_GATES:
        raise SystemExit(
            "flat-style repair is allowed only when every semantic, hierarchy, text, and evidence gate already passes"
        )

    observations = evaluation.get("style_observations", {})
    if not isinstance(observations, dict) or set(observations) != REQUIRED_STYLE_FLAGS:
        raise SystemExit("candidate style-observation inventory is incomplete")
    observed_failures = {
        name for name, value in observations.items()
        if value is True and name != "contained_nondimensional_tonal_variation"
    }
    if not observed_failures or not observed_failures <= SURFACE_STYLE_FLAGS:
        raise SystemExit(
            "flat-style repair cannot fix perspective, side faces, stacked depth, or a competing secondary pipeline"
        )

    reviewer = evaluation.get("reviewer_test", {})
    if not isinstance(reviewer, dict) or any(
        reviewer.get(name) is not True
        for name in ("fundamental_advancement", "why_it_should_work", "credibility", "doe_or_sponsor_payoff")
    ):
        raise SystemExit("flat-style repair requires a complete passing 30-second reviewer read")

    reconciled = evaluation.get("object_reconciliation", [])
    reconciled_by_term = {
        str(item.get("source_term", "")): item
        for item in reconciled
        if isinstance(item, dict)
    } if isinstance(reconciled, list) else {}
    required_terms = {
        str(item.get("source_term", ""))
        for item in contract.get("visual_object_inventory", [])
        if isinstance(item, dict) and item.get("required") is True
    }
    if not required_terms or any(
        reconciled_by_term.get(term, {}).get("status") != "recognizable" for term in required_terms
    ):
        raise SystemExit("flat-style repair requires every required object to remain recognizable")

    prompt = """NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.

Edit the first attached candidate image only. Use the second attached image only as the flat-style target.

PRESERVE EXACTLY: canvas size, crop, white background, composition, object count, object silhouettes, positions, proportions, scientific relationships, arrows, connector paths, visual hierarchy, color roles, and all proposal-specific content. Do not add, remove, move, reinterpret, or replace any object.

CHANGE ONLY THE DIMENSIONAL SURFACE TREATMENT: remove shading, highlights, sheen, illumination, glow, halo, reflection, cast shadow, or transparency variation that makes an object look rounded, glossy, material, lit, or three-dimensional. Replace it with a matte solid fill or restrained same-hue tonal variation that remains visibly depthless. Keep all major objects strictly front-facing with no top face, side face, offset copy, extrusion, or perspective. Retain consistent dark navy outlines and generous white space. The result should look like clean editorial vector artwork rendered as a raster PNG.

OUTPUT: one opaque 1536 x 1024 landscape PNG. No title, caption, labels, letters, numerals, units, axes, legend, logo, watermark, pseudo-text, alternate, comparison, SVG, or vector data.

NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
"""
    prompt_path = run_dir / "prompts" / f"{stem}-edit-01.txt"
    prompt_path.write_text(prompt, encoding="utf-8")
    print(
        json.dumps(
            {
                "status": "eligible",
                "candidate": stem,
                "prompt": str(prompt_path),
                "attach_in_order": [
                    str(run_dir / "candidates" / f"{stem}.png"),
                    "<skill-root>/assets/style-references/ref-flat-2d-style-target.png",
                ],
                "observed_surface_failures": sorted(observed_failures),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
