#!/usr/bin/env python3
"""Build two compact image prompts from a validated ERCP execution contract."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


CAPSULE_KEYS = ("SYSTEM", "PRIMARY CAPABILITY", "DECISIVE RELATIONSHIP", "ENDPOINT", "DO NOT SUBSTITUTE")
STYLE_ASSET = "assets/style-references/ref-flat-2d-style-target.png"


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def required_visuals(contract: dict[str, Any]) -> list[str]:
    values = [
        str(item.get("visual_form", "")).strip()
        for item in contract.get("visual_object_inventory", [])
        if isinstance(item, dict) and item.get("required") is True and str(item.get("visual_form", "")).strip()
    ]
    if not 3 <= len(values) <= 5:
        raise ValueError("visual_object_inventory must contain three to five required visual forms")
    return values


def render_prompt(contract: dict[str, Any], plan: dict[str, Any], region_limit: int, transfer_limit: int) -> str:
    capsule = contract.get("semantic_capsule", {})
    capsule_lines = "\n".join(f"{key}: {capsule[key]}" for key in CAPSULE_KEYS)
    must_show = "\n".join(f"- {value}" for value in required_visuals(contract))
    optional_claim_ids = {
        str(item.get("claim_id", "")).strip()
        for item in contract.get("visual_object_inventory", [])
        if isinstance(item, dict) and item.get("required") is False and str(item.get("claim_id", "")).strip()
    }
    reference = plan.get("style_reference", {})
    transfers = [str(value).strip() for value in reference.get("transfer", []) if str(value).strip()]
    transfer_text = ", ".join(transfers[:transfer_limit])
    regions = [
        str(item.get("geometry", "")).strip().rstrip(".")
        for item in plan.get("spatial_blueprint", [])
        if (
            isinstance(item, dict)
            and str(item.get("geometry", "")).strip()
            and str(item.get("claim_id", "")).strip() not in optional_claim_ids
        )
    ][:region_limit]
    region_text = ". ".join(regions)
    if region_text:
        region_text += "."

    return f"""NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. COMPLETELY TEXT-FREE FLAT-2D EDITORIAL-VECTOR-STYLE RASTER PNG.

PURPOSE
Show the funding story.

SOURCE-LOCKED SCIENCE — DO NOT RENDER AS TEXT
{capsule_lines}

MUST SHOW
{must_show}

COMPOSITION
Use one dominant story path: {contract['funding_story_spine']} {region_text} Do not add a separate validation inset, return path, or secondary pipeline.

REFERENCE ASSET: {reference.get('asset', 'NONE')}
REFERENCE USE: LAYOUT-ONLY PLANNING AID; DO NOT ATTACH A BUNDLED REFERENCE TO GENERATION.
{f'Written topology only: {transfer_text}.' if transfer_text else ''}

STYLE ASSET: {STYLE_ASSET}
Attach only this certified flat-style PNG. Transfer its front-facing geometry, matte fills, consistent navy outlines, white space, and absence of depth cues. Do not copy its generic objects or layout.

COLOR AND STYLE
{contract['palette_strategy']} Flat 2D editorial vector aesthetic. Treat every major object as a paper-cut icon seen straight on. A rectangle may show only its front face. Prefer solid or restrained same-hue fills, consistent line weight, generous negative space, clear connectors, and minimal flat translucency. Subtle tonal variation may remain inside a front-facing shape when it stays matte and depthless. Never show a top or side face, offset stacked copies that imply thickness, perspective convergence, dimensional shading or highlights, an illuminated-screen effect, a glow or halo, a reflection, or a cast shadow. No organization branding.

SCIENCE BOUNDARY
Show concepts, not achieved evidence. No invented data, Roadmap content, unsupported precision, or stock substitutes.

OUTPUT
One opaque landscape raster PNG, 1536 × 1024. No text, logos, pseudo-text, SVG, vector data, or alternates.

NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
""".strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()
    contract = load_json(run_dir / "analysis" / "execution-contract.json")
    plans = {
        str(item.get("candidate_id", "")).casefold(): item
        for item in contract.get("candidate_plans", [])
        if isinstance(item, dict)
    }
    if set(plans) != {"a", "b"}:
        raise SystemExit("execution contract must contain candidate plans A and B")

    prompt_dir = run_dir / "prompts"
    prompt_dir.mkdir(parents=True, exist_ok=True)
    word_counts: dict[str, int] = {}
    for candidate_id in ("a", "b"):
        prompt = ""
        for region_limit, transfer_limit in ((5, 3), (3, 2), (1, 1), (0, 0)):
            prompt = render_prompt(contract, plans[candidate_id], region_limit, transfer_limit)
            if len(prompt.split()) <= 500:
                break
        word_count = len(prompt.split())
        if not 250 <= word_count <= 500:
            raise SystemExit(f"candidate-{candidate_id} deterministic prompt has {word_count} words; compact the execution contract")
        path = prompt_dir / f"candidate-{candidate_id}.txt"
        path.write_text(prompt, encoding="utf-8")
        word_counts[path.name] = word_count

    print(json.dumps({"status": "pass", "word_counts": word_counts}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
