#!/usr/bin/env python3
"""Exercise the Figure 1 run contract with fictional text and a synthetic PNG."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import struct
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
SOURCE = ROOT / "assets" / "fictional-fluxweave-proposal.md"

HARD_GATES = (
    "attachment_grounding",
    "science_fidelity",
    "primary_capability_fidelity",
    "secondary_method_suppression",
    "decisive_relationship_visible",
    "scientific_endpoint_visible",
    "claim_evidence_reconciliation",
    "closed_text_inventory",
    "five_role_color_fidelity",
    "brand_neutral_output",
    "style_reference_boundary",
    "no_fabricated_evidence",
    "no_roadmap_logic",
    "no_unauthorized_marks",
    "no_generic_template_or_stock_metaphor",
    "flat_scientific_editorial_style",
    "one_dominant_hierarchy",
    "thumbnail_reviewer_test",
    "graphic_designer_handoff_value",
)

SCORES = (
    "science_fidelity",
    "primary_capability_fidelity",
    "proposal_specificity",
    "funding_story",
    "sponsor_value",
    "credibility_without_fake_evidence",
    "visual_hierarchy",
    "label_free_compliance",
    "reference_family_fit",
    "graphic_designer_handoff_value",
)


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def run(
    command: list[str],
    expect: int = 0,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, text=True, capture_output=True, check=False, env=env)
    if result.returncode != expect:
        raise RuntimeError(
            f"unexpected exit {result.returncode}, expected {expect}: {' '.join(command)}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def png_chunk(kind: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)


def write_synthetic_png(path: Path) -> None:
    width, height = 1536, 1024
    white = bytes((255, 255, 255)) * width
    sage = bytes((198, 220, 204)) * width
    scanlines = b"".join(b"\x00" + (sage if 384 <= y < 640 else white) for y in range(height))
    data = (
        b"\x89PNG\r\n\x1a\n"
        + png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
        + png_chunk(b"IDAT", zlib.compress(scanlines, level=9))
        + png_chunk(b"IEND", b"")
    )
    path.write_bytes(data)


def validate_manifest_prompts() -> None:
    plugin_root = ROOT.parent.parent
    manifest = json.loads((plugin_root / ".codex-plugin" / "plugin.json").read_text(encoding="utf-8"))
    prompts = manifest.get("interface", {}).get("defaultPrompt")
    if not isinstance(prompts, list) or not 1 <= len(prompts) <= 3:
        raise RuntimeError("interface.defaultPrompt must be a list containing one to three prompts")
    if any(not isinstance(prompt, str) or not prompt or len(prompt) > 128 for prompt in prompts):
        raise RuntimeError("every interface.defaultPrompt entry must be a non-empty string of at most 128 characters")

    openai_yaml = (ROOT / "agents" / "openai.yaml").read_text(encoding="utf-8")
    marker = "  default_prompt: "
    default_line = next((line for line in openai_yaml.splitlines() if line.startswith(marker)), None)
    if default_line is None:
        raise RuntimeError("agents/openai.yaml is missing interface.default_prompt")
    encoded_prompt = default_line[len(marker):]
    try:
        skill_prompt = json.loads(encoded_prompt)
    except json.JSONDecodeError as exc:
        raise RuntimeError("agents/openai.yaml default_prompt must be a quoted string") from exc
    if not isinstance(skill_prompt, str) or "$create-ercp-proposal-figures" not in skill_prompt or len(skill_prompt) > 128:
        raise RuntimeError("agents/openai.yaml default_prompt must mention the skill and contain at most 128 characters")


def validate_local_ocr_contract(temporary: Path) -> None:
    image = temporary / "apple-vision-contract.png"
    output = temporary / "apple-vision-contract.ocr.json"
    allowed = temporary / "apple-vision-contract.allowed.json"
    report = temporary / "apple-vision-contract.labels.json"
    write_synthetic_png(image)
    write_json(allowed, [])
    run(
        [
            sys.executable,
            str(SCRIPTS / "ocr_portable.py"),
            "--image",
            str(image),
            "--out",
            str(output),
        ]
    )
    payload = json.loads(output.read_text(encoding="utf-8"))
    available = payload.get("available") is True
    if available:
        if payload.get("status") != "pass" or payload.get("verification_mode") != "deterministic-local-ocr":
            raise RuntimeError(f"available local OCR did not declare a deterministic pass: {payload}")
        expected_verifier_codes = (0, 1)
    else:
        if payload.get("status") != "unavailable" or payload.get("verification_mode") != "requires-codex-visual-inspection":
            raise RuntimeError(f"unavailable local OCR did not require visual inspection: {payload}")
        expected_verifier_codes = (2,)

    verification = subprocess.run(
        [
            sys.executable,
            str(SCRIPTS / "verify_labels.py"),
            "--ocr",
            str(output),
            "--allowed",
            str(allowed),
            "--out",
            str(report),
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    if verification.returncode not in expected_verifier_codes:
        raise RuntimeError(
            "portable OCR output is not handled safely by verify_labels.py\n"
            f"stdout:\n{verification.stdout}\nstderr:\n{verification.stderr}"
        )


def inspect_and_label(run_dir: Path, stem: str) -> None:
    candidate = run_dir / "candidates" / f"{stem}.png"
    thumbnail = run_dir / "candidates" / f"{stem}.thumbnail.png"
    metrics = run_dir / "candidates" / f"{stem}.metrics.json"
    ocr = run_dir / "candidates" / f"{stem}.ocr.json"
    labels = run_dir / "candidates" / f"{stem}.labels.json"
    write_synthetic_png(candidate)
    run(
        [
            sys.executable,
            str(SCRIPTS / "inspect_raster.py"),
            "--image",
            str(candidate),
            "--out",
            str(metrics),
            "--palette-json",
            str(run_dir / "analysis" / "palette.json"),
            "--thumbnail",
            str(thumbnail),
        ]
    )
    run([sys.executable, str(SCRIPTS / "ocr_portable.py"), "--image", str(candidate), "--out", str(ocr)])
    ocr_result = json.loads(ocr.read_text(encoding="utf-8"))
    if ocr_result.get("available") is True:
        run(
            [
                sys.executable,
                str(SCRIPTS / "verify_labels.py"),
                "--ocr",
                str(ocr),
                "--allowed",
                str(run_dir / "analysis" / "allowed-text.json"),
                "--out",
                str(labels),
            ]
        )
    else:
        write_json(
            labels,
            {
                "status": "pass",
                "image": str(candidate.resolve()),
                "verification_mode": "codex-visual-inspection-fixture",
                "allowed_text": [],
                "recognized_text": [],
            },
        )


def populate_analysis(run_dir: Path) -> None:
    scientific_system = "Transient interfacial disorder and coupled heat and charge transport across layered quantum interfaces"
    primary_capability = "Synchronized ultrafast structural and transport mapping across the same interface"
    decisive_relationship = "Recurring structural motifs create identifiable transport corridors, and a timed strain pulse selectively strengthens or suppresses those corridors"
    validation_logic = "Recurrence of the same motif–transport relationship across repeated interface preparations"
    endpoint = "A source-supported map connecting transient interfacial motifs to directional transport response"
    payoff = "A mechanistic basis for designing energy-relevant quantum interfaces whose transport behavior can be deliberately tuned rather than observed only after averaging"
    strengths = [
        "The same interface is observed structurally and electronically on synchronized time scales.",
        "The proposed recurrence test links a transient visual feature to an independently measured transport response without claiming a result in advance.",
    ]
    claims = [
        ("C1", "scientific system", "FLUXWEAVE will establish how transient interfacial disorder redirects coupled heat and charge transport across layered quantum interfaces.", "Scientific vision"),
        ("C2", "consequential gap", "Existing measurements average over the brief interval in which interfacial disorder forms, propagates, and reorganizes.", "Consequential gap"),
        ("C3", "primary capability", "The central capability is synchronized ultrafast structural and transport mapping across the same interface.", "Primary capability and hypothesis"),
        ("C4", "decisive relationship", "The hypothesis is that recurring structural motifs create identifiable transport corridors, and that a timed strain pulse selectively strengthens or suppresses those corridors.", "Primary capability and hypothesis"),
        ("C5", "comparison approach", "The project will compare synchronized measurements before, during, and after the strain pulse across repeated interface preparations.", "Approach and credibility"),
        ("C6", "validation logic", "Recurrence of the same motif–transport relationship across preparations provides the proposed credibility check.", "Approach and credibility"),
        ("C7", "secondary method limit", "Pattern classification is limited to locating recurring motifs; it is not the scientific engine.", "Approach and credibility"),
        ("C8", "scientific endpoint", "The endpoint is a source-supported map connecting transient interfacial motifs to directional transport response.", "Scientific endpoint and DOE relevance"),
        ("C9", "DOE payoff", "This relationship would provide a mechanistic basis for designing energy-relevant quantum interfaces whose transport behavior can be deliberately tuned rather than observed only after averaging.", "Scientific endpoint and DOE relevance"),
        ("C10", "strength one", strengths[0], "Expected strengths"),
        ("C11", "strength two", strengths[1], "Expected strengths"),
    ]
    source = {
        "status": "pass",
        "proposal_title": "FLUXWEAVE: Reversible Thermal Transport in Porous Interfaces",
        "distinctive_terms": ["FLUXWEAVE", "reciprocal", "porous interface", "localization"],
        "scientific_vision": "Establish how transient interfacial disorder redirects coupled heat and charge transport across layered quantum interfaces.",
        "scientific_system": scientific_system,
        "consequential_gap": "Existing measurements obscure the transient interval and leave structural rearrangement versus directional transport unresolved.",
        "objectives": [
            "Resolve how recurring structural motifs connect to directional transport response.",
            "Test how a timed strain pulse selectively strengthens or suppresses transport corridors.",
        ],
        "primary_capability": primary_capability,
        "decisive_relationship": decisive_relationship,
        "validation_logic": validation_logic,
        "scientific_endpoint": endpoint,
        "doe_payoff": payoff,
        "strengths": strengths,
        "secondary_methods": [{"name": "Pattern classification", "limited_role": "Locating recurring motifs only"}],
        "allowed_subjects": ["layered quantum interface", "recurring structural motifs", "transport corridors", "timed strain pulse"],
        "allowed_relationships": [decisive_relationship, validation_logic],
        "forbidden_inferences": ["no achieved result", "no fabricated transport value", "no generic AI pipeline"],
        "evidence": [
            {"claim_id": claim_id, "claim": claim, "exact_quote": quote, "section": section}
            for claim_id, claim, quote, section in claims
        ],
    }
    write_json(run_dir / "analysis" / "source-lock.json", source)
    write_json(
        run_dir / "analysis" / "science-verification.json",
        {
            "status": "pass",
            "proposal_identity_checksum": {
                "scientific_system": scientific_system,
                "primary_capability": primary_capability,
                "decisive_relationship": decisive_relationship,
                "validation_logic": validation_logic,
                "scientific_endpoint": endpoint,
                "doe_payoff": payoff,
            },
            "renderer_capsule": {
                "SYSTEM": scientific_system,
                "PRIMARY CAPABILITY": primary_capability,
                "DECISIVE RELATIONSHIP": decisive_relationship,
                "ENDPOINT": endpoint,
                "DO NOT SUBSTITUTE": "Do not replace synchronized motif–transport logic with pattern classification, steady-state averaging, a generic pipeline, or a dashboard",
            },
            "claim_evidence_matrix": [
                {"claim_id": f"C{index}", "planned_item": item}
                for index, item in enumerate(
                    ["layered interface", "transient disorder gap", "synchronized mapping", "motif–corridor relationship"], 1
                )
            ],
            "prohibited_substitutions": ["pattern classification as engine", "generic funnel", "dashboard"],
            "secondary_method_suppression_pass": True,
            "interchangeability_test_pass": True,
        },
    )
    write_json(
        run_dir / "analysis" / "funding-case.json",
        {
            "status": "pass",
            "funding_thesis": "Fund the capability that exposes how geometry governs reversible local transport.",
            "reviewer_answers": {
                "fundamental_advancement": primary_capability,
                "why_it_should_work": decisive_relationship,
                "credibility": validation_logic,
                "doe_or_sponsor_payoff": payoff,
            },
            "strengths": strengths,
        },
    )
    funding_story_spine = "Transient interface disorder becomes a controllable transport mechanism when synchronized mapping reveals motif-linked corridors and a timed pulse tests them."
    objects = [
        {"source_term": "layered quantum interface", "claim_id": "C1", "visual_form": "recognizable stacked interface", "recognition_cue": "two coupled material layers sharing a boundary", "required": True},
        {"source_term": "recurring structural motifs", "claim_id": "C4", "visual_form": "repeated localized motifs", "recognition_cue": "same motif shape recurring along the boundary", "required": True},
        {"source_term": "directional transport corridors", "claim_id": "C4", "visual_form": "directional flow channels", "recognition_cue": "continuous paths aligned with the recurring motifs", "required": True},
        {"source_term": "timed strain pulse", "claim_id": "C4", "visual_form": "localized pulse entering the interface", "recognition_cue": "single wavefront changing selected corridors", "required": True},
        {"source_term": "integrated motif-response map", "claim_id": "C8", "visual_form": "resolved coupled endpoint", "recognition_cue": "motifs and transport paths visibly aligned in one state", "required": True},
    ]
    layouts = [
        {"family": "INTEGRATION_MAP", "fit": "primary", "reason": "The proposal integrates synchronized structural and transport observations on the same interface."},
        {"family": "LINEAR_SEQUENCE", "fit": "alternate", "reason": "The pulse-to-corridor transformation can also read as a clear causal sequence."},
        {"family": "FEEDBACK_LOOP", "fit": "rejected", "reason": "Recurrence is a credibility cue rather than the primary funding story."},
    ]
    reference_a = {
        "asset": "assets/style-references/ref-e-shared-foundation-coupled-states.png",
        "use_mode": "LAYOUT_AND_STYLE",
        "transfer": ["integrated composition", "shared foundation"],
        "prohibited_transfer": ["reference science", "reference labels", "reference claims", "reference branding"],
    }
    reference_b = {
        "asset": "assets/style-references/ref-a-transformation-separation.png",
        "use_mode": "LAYOUT_AND_STYLE",
        "transfer": ["causal reading order", "large recognizable stages", "coordinated color rhythm"],
        "prohibited_transfer": ["reference science", "reference labels", "reference claims", "reference branding"],
    }
    plans = [
        {
            "candidate_id": "A",
            "layout_family": "INTEGRATION_MAP",
            "story_spine": "A shared layered interface is read structurally and electronically while a timed pulse exposes motif-linked transport corridors and a resolved response map.",
            "style_reference": reference_a,
            "spatial_blueprint": [
                {"id": "A1", "semantic_anchor": "SYSTEM", "claim_id": "C1", "geometry": "large layered interface spanning the composition"},
                {"id": "A2", "semantic_anchor": "PRIMARY CAPABILITY", "claim_id": "C3", "geometry": "paired structural and transport views integrated around the same boundary"},
                {"id": "A3", "semantic_anchor": "DECISIVE RELATIONSHIP", "claim_id": "C4", "geometry": "pulse changes selected motif-aligned corridors"},
                {"id": "A4", "semantic_anchor": "ENDPOINT", "claim_id": "C8", "geometry": "resolved motif-to-response state"},
            ],
        },
        {
            "candidate_id": "B",
            "layout_family": "LINEAR_SEQUENCE",
            "story_spine": "A timed pulse enters a recognizable disordered interface, synchronized mapping reveals recurring motifs and corridors, and an ordered directional response emerges.",
            "style_reference": reference_b,
            "spatial_blueprint": [
                {"id": "B1", "semantic_anchor": "SYSTEM", "claim_id": "C1", "geometry": "disordered layered interface at left"},
                {"id": "B2", "semantic_anchor": "PRIMARY CAPABILITY", "claim_id": "C3", "geometry": "central synchronized mapping zone"},
                {"id": "B3", "semantic_anchor": "DECISIVE RELATIONSHIP", "claim_id": "C4", "geometry": "pulse and motif-aligned corridors through center"},
                {"id": "B4", "semantic_anchor": "ENDPOINT", "claim_id": "C8", "geometry": "ordered directional response at right"},
            ],
        },
    ]
    ledger = {
        "VISION": {"scientific_meaning": source["scientific_vision"], "claim_id": "C1", "visual_carrier": "resolved interface state", "wireframe_anchor": "#C6DCCC", "image_treatment": "cool blue-green organizing field"},
        "GAP": {"scientific_meaning": source["consequential_gap"], "claim_id": "C2", "visual_carrier": "unresolved disordered interface", "wireframe_anchor": "#FE5000", "image_treatment": "warm concentrated disorder accent"},
        "OBJECTIVES": {"scientific_meaning": source["objectives"][0], "claim_id": "C4", "visual_carrier": "recurring motifs and corridors", "wireframe_anchor": "#B36CFF", "image_treatment": "violet and blue relationship cues"},
        "APPROACH": {"scientific_meaning": primary_capability, "claim_id": "C3", "visual_carrier": "synchronized mapping and pulse", "wireframe_anchor": "#FF9E1B", "image_treatment": "teal capability with one warm pulse accent"},
        "IMPACT": {"scientific_meaning": payoff, "claim_id": "C9", "visual_carrier": "ordered directional response", "wireframe_anchor": "#BFD1D3", "image_treatment": "coherent green-blue resolved endpoint"},
    }
    palette_strategy = "Use a cohesive blue, teal, green, violet, and warm-gold palette with warm color concentrated at the intervention and cool color organizing the resolved scientific state."
    visual = {
        "status": "pass",
        "funding_story_spine": funding_story_spine,
        "visual_object_inventory": objects,
        "layout_evaluation": layouts,
        "candidate_plans": plans,
        "color_role_ledger": ledger,
        "palette_strategy": palette_strategy,
        "validation_relationship_cue": {"scientific_meaning": validation_logic, "claim_id": "C6", "geometry": "subordinate matched recurrence cue across repeated interface preparations"},
        "visual_brand_policy": "BRAND_NEUTRAL_PROPOSAL_DRAFT",
        "allowed_text": [],
        "allowed_visuals": ["layered interface", "recurring motifs", "transport corridors", "timed pulse", "integrated endpoint map"],
        "must_preserve": ["recognizable layered interface", "motif-corridor relationship", "timed intervention", "resolved endpoint", "white field"],
        "forbidden": ["visible text", "logo", "Roadmap timeline", "fabricated measured result", "generic AI dashboard"],
        "companion_transfer": [],
        "companion_prohibited_transfer": [],
        "logo_state": "OMIT",
        "canvas": {"width": 1536, "height": 1024},
        "candidate_count": 2,
        "final_artifact_count": 1,
        "repair_ceiling": 1,
    }
    write_json(run_dir / "analysis" / "visual-brief.json", visual)
    write_json(run_dir / "analysis" / "allowed-text.json", [])
    write_json(run_dir / "analysis" / "palette.json", ["#FFFFFF", "#2E75B6", "#39A9A4", "#6FBD65", "#7C5AB8", "#F5A623", "#373A36"])
    write_json(
        run_dir / "analysis" / "execution-contract.json",
        {
            "status": "pass",
            "semantic_capsule": {
                "SYSTEM": scientific_system,
                "PRIMARY CAPABILITY": primary_capability,
                "DECISIVE RELATIONSHIP": decisive_relationship,
                "ENDPOINT": endpoint,
                "DO NOT SUBSTITUTE": "Do not replace synchronized motif–transport logic with pattern classification, steady-state averaging, a generic pipeline, or a dashboard",
            },
            "only_allowed_text": [],
            "funding_story_spine": funding_story_spine,
            "visual_object_inventory": objects,
            "layout_evaluation": layouts,
            "candidate_plans": plans,
            "color_role_ledger": ledger,
            "palette_strategy": palette_strategy,
            "validation_relationship_cue": visual["validation_relationship_cue"],
            "visual_brand_policy": "BRAND_NEUTRAL_PROPOSAL_DRAFT",
            "allowed_visuals": visual["allowed_visuals"],
            "logo_state": "OMIT",
            "must_preserve": visual["must_preserve"],
            "forbidden": visual["forbidden"],
            "output": {
                "candidate_count": 2,
                "final_artifact_count": 1,
                "format": "PNG",
                "artifact_type": "raster",
                "width": 1536,
                "height": 1024,
                "opacity": "opaque",
            },
            "repair_ceiling": 1,
        },
    )


def write_candidate_prompts(run_dir: Path) -> None:
    run([sys.executable, str(SCRIPTS / "build_prompts.py"), "--run-dir", str(run_dir)])


def main() -> int:
    if not SOURCE.is_file():
        raise SystemExit(f"fixture source is missing: {SOURCE}")
    validate_manifest_prompts()
    style_assets = sorted((ROOT / "assets" / "style-references").glob("ref-*.png"))
    if len(style_assets) != 9 or any(path.stat().st_size == 0 for path in style_assets):
        raise SystemExit(f"expected eight legacy layout references plus one certified style target, found: {style_assets}")
    with tempfile.TemporaryDirectory(prefix="ercp-figure-1-self-test-") as temporary:
        validate_local_ocr_contract(Path(temporary))
        run_dir = Path(temporary) / "run"
        run(
            [
                sys.executable,
                str(SCRIPTS / "init_run.py"),
                "--run-dir",
                str(run_dir),
                "--source",
                str(SOURCE),
                "--companion-status",
                "none",
            ]
        )
        run([sys.executable, str(SCRIPTS / "validate_run.py"), "--run-dir", str(run_dir)], expect=1)
        populate_analysis(run_dir)
        run([sys.executable, str(SCRIPTS / "verify_source_quotes.py"), "--run-dir", str(run_dir)])
        run([sys.executable, str(SCRIPTS / "validate_run.py"), "--run-dir", str(run_dir)])
        palette_path = run_dir / "analysis" / "palette.json"
        planned_palette = json.loads(palette_path.read_text(encoding="utf-8"))
        write_json(palette_path, ["#FFFFFF", "not-a-color"])
        run([sys.executable, str(SCRIPTS / "validate_run.py"), "--run-dir", str(run_dir)], expect=1)
        write_json(palette_path, planned_palette)
        run([sys.executable, str(SCRIPTS / "validate_run.py"), "--run-dir", str(run_dir)])
        write_candidate_prompts(run_dir)
        run([sys.executable, str(SCRIPTS / "validate_prompts.py"), "--run-dir", str(run_dir)])

        inspect_and_label(run_dir, "candidate-a")
        inspect_and_label(run_dir, "candidate-b")
        candidate = run_dir / "candidates" / "candidate-a.png"

        mismatch_ocr = run_dir / "validation" / "mismatch-ocr.json"
        mismatch_report = run_dir / "validation" / "mismatch-labels.json"
        write_json(
            mismatch_ocr,
            {
                "available": True,
                "verification_mode": "deterministic-local-ocr",
                "image": str(candidate.resolve()),
                "observations": [{"text": "UNAUTHORIZED", "confidence": 1.0}],
            },
        )
        run(
            [
                sys.executable,
                str(SCRIPTS / "verify_labels.py"),
                "--ocr",
                str(mismatch_ocr),
                "--allowed",
                str(run_dir / "analysis" / "allowed-text.json"),
                "--out",
                str(mismatch_report),
            ],
            expect=1,
        )

        evaluation = {
            "candidate_id": "A",
            "artifact": "candidates/candidate-a.png",
            "metrics": "candidates/candidate-a.metrics.json",
            "labels_report": "candidates/candidate-a.labels.json",
            "status": "fail",
            "blind_image_read": {
                "review_mode": "image-only-cold-read",
                "thumbnail_artifact": "candidates/candidate-a.thumbnail.png",
                "visible_system": "a layered material interface",
                "visible_primary_capability": "paired views of structure and directional flow",
                "visible_decisive_relationship": "a pulse changes motif-aligned transport corridors",
                "visible_credibility_cue": "the same motif-flow relationship recurs",
                "visible_endpoint": "an integrated motif-response state",
                "visible_sponsor_value": "more controllable interface transport",
                "proposal_specific_strengths": ["same-interface paired observation", "selective pulse test"],
                "ambiguous_or_generic_regions": [],
            },
            "style_observations": {
                "nonfrontal_major_object": True,
                "visible_side_or_top_face": False,
                "offset_stacked_depth": False,
                "dimensional_shading_or_highlight_on_major_object": False,
                "glow_halo_or_illuminated_screen": False,
                "cast_shadow_or_reflection": False,
                "contained_nondimensional_tonal_variation": False,
                "competing_secondary_pipeline": False,
            },
            "style_observation_evidence": {
                "nonfrontal_major_object": "center panel is visibly angled away from the viewer",
                "visible_side_or_top_face": "none observed after full-size inspection",
                "offset_stacked_depth": "none observed after full-size inspection",
                "dimensional_shading_or_highlight_on_major_object": "none observed after full-size inspection",
                "glow_halo_or_illuminated_screen": "none observed after full-size inspection",
                "cast_shadow_or_reflection": "none observed after full-size inspection",
                "contained_nondimensional_tonal_variation": "none observed after full-size inspection",
                "competing_secondary_pipeline": "none observed after full-size inspection",
            },
            "hard_gates": {name: name != "flat_scientific_editorial_style" for name in HARD_GATES},
            "reviewer_test": {
                "fundamental_advancement": True,
                "why_it_should_work": True,
                "credibility": True,
                "doe_or_sponsor_payoff": True,
                "proposal_specific_strengths": ["reciprocal field logic", "geometry-linked endpoint"],
            },
            "object_reconciliation": [
                {"source_term": term, "status": "recognizable", "observed_form": "synthetic fixture form", "source_support": "fictional fixture"}
                for term in ("layered quantum interface", "recurring structural motifs", "directional transport corridors", "timed strain pulse", "integrated motif-response map")
            ],
            "actual_color_role_ledger": {
                role: {"visible_family": "canonical proposal-role family", "carrier": "synthetic test field", "source_support": "fictional fixture"}
                for role in ("VISION", "GAP", "OBJECTIVES", "APPROACH", "IMPACT")
            },
            "scores": {name: 3.8 for name in SCORES},
            "repairable_issue": None,
            "selection_reason": "fictional self-test candidate",
        }
        write_json(run_dir / "evaluations" / "candidate-a.json", evaluation)
        run(
            [
                sys.executable,
                str(SCRIPTS / "build_flat_style_repair_prompt.py"),
                "--run-dir",
                str(run_dir),
                "--candidate",
                "a",
            ],
            expect=1,
        )
        style_only = json.loads(json.dumps(evaluation))
        style_only["style_observations"]["nonfrontal_major_object"] = False
        style_only["style_observation_evidence"]["nonfrontal_major_object"] = "none observed after full-size inspection"
        style_only["style_observations"]["dimensional_shading_or_highlight_on_major_object"] = True
        style_only["style_observation_evidence"]["dimensional_shading_or_highlight_on_major_object"] = (
            "center panel uses directional shading that makes it look rounded and illuminated"
        )
        style_only["hard_gates"] = {name: True for name in HARD_GATES}
        style_only["hard_gates"]["flat_scientific_editorial_style"] = False
        style_only["hard_gates"]["graphic_designer_handoff_value"] = False
        write_json(run_dir / "evaluations" / "candidate-a.json", style_only)
        run(
            [
                sys.executable,
                str(SCRIPTS / "build_flat_style_repair_prompt.py"),
                "--run-dir",
                str(run_dir),
                "--candidate",
                "a",
            ]
        )
        repair_prompt = run_dir / "prompts" / "candidate-a-edit-01.txt"
        repair_text = repair_prompt.read_text(encoding="utf-8")
        if "CHANGE ONLY THE DIMENSIONAL SURFACE TREATMENT" not in repair_text or "PRESERVE EXACTLY" not in repair_text:
            raise RuntimeError("flat-style repair prompt lacks its preservation or edit boundary")
        repair_prompt.unlink()

        tonal_advisory = json.loads(json.dumps(evaluation))
        tonal_advisory["status"] = "pass"
        tonal_advisory["style_observations"]["nonfrontal_major_object"] = False
        tonal_advisory["style_observation_evidence"]["nonfrontal_major_object"] = (
            "none observed after full-size inspection"
        )
        tonal_advisory["style_observations"]["contained_nondimensional_tonal_variation"] = True
        tonal_advisory["style_observation_evidence"]["contained_nondimensional_tonal_variation"] = (
            "front-facing panel has a faint same-hue tonal ramp but remains matte and depthless"
        )
        tonal_advisory["hard_gates"] = {name: True for name in HARD_GATES}
        tonal_advisory["scores"] = {name: 4.2 for name in SCORES}
        write_json(run_dir / "evaluations" / "candidate-a.json", tonal_advisory)
        run(
            [
                sys.executable,
                str(SCRIPTS / "build_flat_style_repair_prompt.py"),
                "--run-dir",
                str(run_dir),
                "--candidate",
                "a",
            ],
            expect=1,
        )
        module_spec = importlib.util.spec_from_file_location("ercp_finalize_run", SCRIPTS / "finalize_run.py")
        if module_spec is None or module_spec.loader is None:
            raise RuntimeError("could not load finalize_run.py for advisory-style test")
        finalize_module = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(finalize_module)
        assessed, assessment_errors = finalize_module.assess(
            run_dir.resolve(), (run_dir / "evaluations" / "candidate-a.json").resolve()
        )
        if assessment_errors or assessed is None or assessed.get("qualification_pass") is not True:
            raise RuntimeError(
                f"contained non-dimensional tonal variation did not remain qualification-safe: "
                f"{assessment_errors or assessed}"
            )
        if "style review note: contained_nondimensional_tonal_variation" not in assessed.get("review_notes", []):
            raise RuntimeError("contained tonal variation did not produce an advisory review note")
        write_json(run_dir / "evaluations" / "candidate-a.json", evaluation)
        rejected = {
            "candidate_id": "B",
            "artifact": "candidates/candidate-b.png",
            "metrics": "candidates/candidate-b.metrics.json",
            "labels_report": "candidates/candidate-b.labels.json",
            "status": "fail",
            "blind_image_read": {
                "review_mode": "image-only-cold-read",
                "thumbnail_artifact": "candidates/candidate-b.thumbnail.png",
                "visible_system": "a layered material interface",
                "visible_primary_capability": "paired views of structure and directional flow",
                "visible_decisive_relationship": "a pulse changes motif-aligned transport corridors",
                "visible_credibility_cue": "the same motif-flow relationship recurs",
                "visible_endpoint": "an integrated motif-response state",
                "visible_sponsor_value": "more controllable interface transport",
                "proposal_specific_strengths": ["same-interface paired observation", "selective pulse test"],
                "ambiguous_or_generic_regions": ["synthetic generic region"],
            },
            "style_observations": {
                "nonfrontal_major_object": False,
                "visible_side_or_top_face": False,
                "offset_stacked_depth": False,
                "dimensional_shading_or_highlight_on_major_object": False,
                "glow_halo_or_illuminated_screen": False,
                "cast_shadow_or_reflection": False,
                "contained_nondimensional_tonal_variation": False,
                "competing_secondary_pipeline": False,
            },
            "style_observation_evidence": {
                "nonfrontal_major_object": "none observed after full-size inspection",
                "visible_side_or_top_face": "none observed after full-size inspection",
                "offset_stacked_depth": "none observed after full-size inspection",
                "dimensional_shading_or_highlight_on_major_object": "none observed after full-size inspection",
                "glow_halo_or_illuminated_screen": "none observed after full-size inspection",
                "cast_shadow_or_reflection": "none observed after full-size inspection",
                "contained_nondimensional_tonal_variation": "none observed after full-size inspection",
                "competing_secondary_pipeline": "none observed after full-size inspection",
            },
            "hard_gates": {name: name != "no_generic_template_or_stock_metaphor" for name in HARD_GATES},
            "reviewer_test": {
                "fundamental_advancement": True,
                "why_it_should_work": True,
                "credibility": True,
                "doe_or_sponsor_payoff": False,
                "proposal_specific_strengths": ["reciprocal field logic", "geometry-linked endpoint"],
            },
            "object_reconciliation": [
                {"source_term": term, "status": "recognizable", "observed_form": "synthetic fixture form", "source_support": "fictional fixture"}
                for term in ("layered quantum interface", "recurring structural motifs", "directional transport corridors", "timed strain pulse", "integrated motif-response map")
            ],
            "actual_color_role_ledger": {
                role: {"visible_family": "canonical proposal-role family", "carrier": "synthetic test field", "source_support": "fictional fixture"}
                for role in ("VISION", "GAP", "OBJECTIVES", "APPROACH", "IMPACT")
            },
            "scores": {name: 3.0 for name in SCORES},
            "repairable_issue": None,
            "selection_reason": "generic fictional layout rejected",
        }
        write_json(run_dir / "evaluations" / "candidate-b.json", rejected)
        run([sys.executable, str(SCRIPTS / "finalize_run.py"), "--run-dir", str(run_dir)])
        run([sys.executable, str(SCRIPTS / "validate_delivery.py"), "--run-dir", str(run_dir)])

        unexpected = run_dir / "final" / "unexpected-thumbnail.png"
        unexpected.write_bytes(candidate.read_bytes())
        run([sys.executable, str(SCRIPTS / "validate_delivery.py"), "--run-dir", str(run_dir)], expect=1)
        unexpected.unlink()
        run([sys.executable, str(SCRIPTS / "validate_delivery.py"), "--run-dir", str(run_dir)])

        final_files = list((run_dir / "final").iterdir())
        if [path.name for path in final_files] != ["ercp-figure-1-draft.png"]:
            raise RuntimeError(f"unexpected final files: {final_files}")
        if hashlib.sha256(final_files[0].read_bytes()).hexdigest() != hashlib.sha256(candidate.read_bytes()).hexdigest():
            raise RuntimeError("final artifact is not byte-identical to the selected source raster")
        finalization = json.loads((run_dir / "validation" / "finalization.json").read_text(encoding="utf-8"))
        if finalization.get("status") != "best_effort" or finalization.get("qualification_pass") is not False:
            raise RuntimeError(f"failed candidates did not produce a best-effort handoff: {finalization}")
        if not finalization.get("remaining_issues"):
            raise RuntimeError("best-effort handoff did not record remaining issues")

    print("RESULT | PASS | ERCP Figure 1 skill self-test completed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
