#!/usr/bin/env python3
"""Validate two compact candidate prompts against the frozen execution contract."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


REQUIRED_START = (
    "NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. "
    "COMPLETELY TEXT-FREE FLAT-2D EDITORIAL-VECTOR-STYLE RASTER PNG."
)
REQUIRED_END = "NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE."
REQUIRED_STYLE = (
    "Flat 2D editorial vector aesthetic. Treat every major object as a paper-cut icon seen straight on. "
    "A rectangle may show only its front face. Prefer solid or restrained same-hue fills, consistent line weight, "
    "generous negative space, clear connectors, and minimal flat translucency. Subtle tonal variation may remain "
    "inside a front-facing shape when it stays matte and depthless."
)
REQUIRED_STYLE_EXCLUSIONS = (
    "Never show a top or side face, offset stacked copies that imply thickness, perspective convergence, "
    "dimensional shading or highlights, an illuminated-screen effect, a glow or halo, a reflection, or a cast shadow."
)
REQUIRED_REFERENCE_USE = "REFERENCE USE: LAYOUT-ONLY PLANNING AID; DO NOT ATTACH A BUNDLED REFERENCE TO GENERATION."
REQUIRED_STYLE_ASSET = "STYLE ASSET: assets/style-references/ref-flat-2d-style-target.png"
REQUIRED_STYLE_USE = (
    "Attach only this certified flat-style PNG. Transfer its front-facing geometry, matte fills, "
    "consistent navy outlines, white space, and absence of depth cues. Do not copy its generic objects or layout."
)
REQUIRED_SECTIONS = (
    "PURPOSE",
    "SOURCE-LOCKED SCIENCE — DO NOT RENDER AS TEXT",
    "MUST SHOW",
    "COMPOSITION",
    "REFERENCE ASSET:",
    "COLOR AND STYLE",
    "SCIENCE BOUNDARY",
    "OUTPUT",
)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()
    out = run_dir / "validation" / "prompts.json"

    try:
        run = load_json(run_dir / "run.json")
        pregen = load_json(run_dir / "validation" / "pregen.json")
        execution = load_json(run_dir / "analysis" / "execution-contract.json")
        current_analysis_hashes = {
            str(path.relative_to(run_dir)): sha256(path)
            for path in sorted((run_dir / "analysis").glob("*.json"))
        }
        errors: list[str] = []
        if run.get("status") != "pregen_passed" or pregen.get("status") != "pass":
            errors.append("pre-generation validation is not current and passed")
        if pregen.get("analysis_sha256") != current_analysis_hashes:
            errors.append("analysis changed after pre-generation validation")
        if execution.get("only_allowed_text") != []:
            errors.append("execution contract is not label-free")
        if execution.get("visual_brand_policy") != "BRAND_NEUTRAL_PROPOSAL_DRAFT":
            errors.append("execution contract is not brand-neutral")

        plans = {
            str(item.get("candidate_id", "")).casefold(): item
            for item in execution.get("candidate_plans", [])
            if isinstance(item, dict)
        }
        if set(plans) != {"a", "b"}:
            errors.append("execution contract must contain candidate plans A and B")

        prompts: dict[str, str] = {}
        prompt_hashes: dict[str, str] = {}
        for stem, plan_key in (("candidate-a", "a"), ("candidate-b", "b")):
            path = run_dir / "prompts" / f"{stem}.txt"
            if not path.is_file():
                errors.append(f"missing exact prompt: {path}")
                continue
            text = path.read_text(encoding="utf-8").strip()
            prompts[stem] = text
            prompt_hashes[str(path.relative_to(run_dir))] = sha256(path)
            if not text:
                errors.append(f"empty prompt: {stem}")
                continue
            word_count = len(text.split())
            if not 250 <= word_count <= 500:
                errors.append(f"{stem} must contain 250 to 500 words; found {word_count}")
            if not text.startswith(REQUIRED_START):
                errors.append(f"{stem} does not begin with the exact no-text hard gate")
            if not text.endswith(REQUIRED_END):
                errors.append(f"{stem} does not end with the exact no-text hard gate")
            for section in REQUIRED_SECTIONS:
                if section not in text:
                    errors.append(f"{stem} lacks required compact-prompt section: {section}")
            if REQUIRED_STYLE not in text:
                errors.append(f"{stem} lacks the exact flat-2D positive style contract")
            if REQUIRED_STYLE_EXCLUSIONS not in text:
                errors.append(f"{stem} lacks the exact rendered-depth exclusion contract")
            if REQUIRED_REFERENCE_USE not in text:
                errors.append(f"{stem} lacks the bundled-reference no-attachment contract")
            if REQUIRED_STYLE_ASSET not in text:
                errors.append(f"{stem} lacks the certified flat-style asset")
            if REQUIRED_STYLE_USE not in text:
                errors.append(f"{stem} lacks the exact certified-style transfer boundary")
            if "one dominant story path" not in text.casefold():
                errors.append(f"{stem} does not require one dominant story path")
            try:
                must_show = text.split("\nMUST SHOW\n", 1)[1].split("\n\nCOMPOSITION\n", 1)[0]
                must_show_count = sum(line.startswith("- ") for line in must_show.splitlines())
                if not 3 <= must_show_count <= 5:
                    errors.append(f"{stem} MUST SHOW must contain three to five bullets; found {must_show_count}")
            except IndexError:
                errors.append(f"{stem} lacks a parseable MUST SHOW block")
            for key, value in execution.get("semantic_capsule", {}).items():
                if f"{key}: {value}" not in text:
                    errors.append(f"{stem} lacks exact semantic-capsule line: {key}")
            for item in execution.get("visual_object_inventory", []):
                if not isinstance(item, dict):
                    continue
                visual_form = item.get("visual_form")
                if not isinstance(visual_form, str) or not visual_form.strip():
                    continue
                if item.get("required") is True and visual_form not in text:
                    errors.append(f"{stem} lacks required visual form: {visual_form}")
                if item.get("required") is False and visual_form in text:
                    errors.append(f"{stem} promotes an optional credibility cue into MUST SHOW: {visual_form}")

            plan = plans.get(plan_key, {})
            funding_story_spine = execution.get("funding_story_spine")
            if isinstance(funding_story_spine, str) and funding_story_spine not in text:
                errors.append(f"{stem} lacks the frozen funding story spine")
            if "Do not add a separate validation inset, return path, or secondary pipeline." not in text:
                errors.append(f"{stem} lacks the no-secondary-pipeline generation rule")
            reference = plan.get("style_reference", {}) if isinstance(plan, dict) else {}
            asset = reference.get("asset") if isinstance(reference, dict) else None
            if isinstance(asset, str) and f"REFERENCE ASSET: {asset}" not in text:
                errors.append(f"{stem} lacks its selected reference asset")
            palette_strategy = execution.get("palette_strategy")
            if isinstance(palette_strategy, str) and palette_strategy not in text:
                errors.append(f"{stem} lacks the planned cohesive palette strategy")

            required_output = "One opaque landscape raster PNG, 1536 × 1024."
            if required_output not in text:
                errors.append(f"{stem} lacks the fixed raster output rule")
            if "No organization branding." not in text:
                errors.append(f"{stem} does not explicitly preserve brand neutrality")
            if text.count("NEVER USE ANY LABELS OR TEXT") < 2:
                errors.append(f"{stem} must repeat the no-text gate at start and end")

        if len(prompts) == 2 and prompts["candidate-a"] == prompts["candidate-b"]:
            errors.append("candidate prompts are identical; layout and composition must differ")

        result = {
            "status": "pass" if not errors else "fail",
            "validated_at": datetime.now(timezone.utc).isoformat(),
            "errors": errors,
            "analysis_sha256": current_analysis_hashes,
            "prompt_sha256": prompt_hashes,
            "word_counts": {stem: len(text.split()) for stem, text in prompts.items()},
        }
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        run["status"] = "prompts_validated" if not errors else "prompt_validation_failed"
        run["prompts_validated_at"] = result["validated_at"]
        (run_dir / "run.json").write_text(json.dumps(run, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 0 if not errors else 1
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f"RESULT | FAIL | {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
