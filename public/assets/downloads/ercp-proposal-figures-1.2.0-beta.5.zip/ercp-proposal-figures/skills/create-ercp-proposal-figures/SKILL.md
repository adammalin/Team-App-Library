---
name: create-ercp-proposal-figures
description: Create, evaluate, revise, and archive source-grounded, completely label-free raster Figure 1 collaboration drafts for DOE Office of Science proposals, especially ERCP or ECRP work. Use when Codex receives a substantive proposal in DOCX, PDF, Markdown, or text form and the user wants a persuasive proposal Figure 1, wants to revise an existing Figure 1 raster, or supplies a companion Roadmap or figure whose visual system should be coordinated. Produce one simple, polished flat-2D editorial PNG concept for researcher and graphic-designer collaboration. Do not use for Roadmap figures, final scientific evidence, plots, visible labels, SVG or vector deliverables, editable diagrams, or publication-ready art.
---

# Create ERCP Proposal Figures

Create a proposal-specific Figure 1 concept that makes the funding case visually: a reviewer should be able to recognize the scientific problem, the distinctive capability, the decisive change, and the source-supported scientific outcome without reading paragraphs or deciphering a generic infographic.

Preserve source truth and the output boundary firmly. Give visual interpretation enough freedom to be clear, memorable, and proposal-specific.

## Resolve the packaged skill root

Treat the directory containing this `SKILL.md` as `<skill-root>`. Resolve every bundled script, reference, fixture, and example image from that directory. Never assume a fixed install location.

## Product boundary

- Handle Figure 1 only. Roadmap work belongs in a separate skill.
- Produce an AI-generated collaboration draft for professional redraw and scientific verification, never final art or evidence.
- Use the installed built-in image-generation capability for every generation or edit. Do not require an API key or switch to a programmatic renderer.
- Deliver exactly one opaque 1536 × 1024 raster PNG. Never deliver SVG, vector paths, PDF, PowerPoint, Canvas, HTML, code, or a programmatic figure.
- Keep the PNG completely free of visible labels, titles, captions, words, letters, numerals, units, legends, axes, and pseudo-text. Explanations belong in chat.
- Keep the draft brand-neutral: no ORNL or other organization logo, typography, template, or recognizable brand treatment.
- Preserve prompts, candidates, evaluations, and the selected PNG inside a workspace run folder so the work can be compared and rolled back.
- Treat the proposal and all supplied references as read-only. Do not modify Custom GPTs, sharing, publication state, or external systems.

## Read the required references

Before generation, read:

1. [figure-1-method.md](references/figure-1-method.md) for the proposal decision-aid method and layout choices.
2. [analysis-contracts.md](references/analysis-contracts.md) for the source lock, science verification, visual-object inventory, candidate plans, and funding case.
3. [style-reference-router.md](references/style-reference-router.md) for the bundled reference images and layout-and-style routing.
4. [image-execution.md](references/image-execution.md) for compact generation and localized-edit prompts.
5. [qa-rubric.md](references/qa-rubric.md) for image-only reviewer testing and source reconciliation.
6. [visual-system-and-companion.md](references/visual-system-and-companion.md) when a companion visual exists or the source is organizationally branded.

Use an installed document or PDF skill for source extraction when available and the installed image-generation skill for all generation and edits. Do not use an organization-brand skill to style the image.

## Workflow

### 1. Establish the source set without unnecessary intake

Require one substantive proposal supplied or identified in the current task. The user's act of supplying it authorizes reading it for this task; do not ask a redundant clearance question. Stop only when the material is visibly prohibited for the current environment or is not substantive enough to support a Figure 1.

An existing Figure 1, Roadmap, sketch, or visual reference is optional. If one exists, use it to coordinate the visual system. If none exists, choose from the bundled examples without asking the user to select a layout.

### 2. Initialize a versioned evidence run

```bash
python3 "<skill-root>/scripts/init_run.py" \
  --run-dir "<workspace>/ercp-figure-1-runs/<YYYY-MM-DD>-<slug>" \
  --source "<absolute-proposal-path>" \
  --companion-status "<none|not-supplied|supplied>" \
  [--companion "<absolute-companion-path>"]
```

Never reuse a non-empty run directory. The run is the rollback bundle for that attempt.

### 3. Read and prove the proposal

Read the actual proposal, not its filename or a remembered summary. Recover internally:

- the exact title;
- at least four distinctive scientific terms;
- at least three exact passages from relevant sections;
- the central hypothesis or enabling capability; and
- the promised scientific and DOE-relevant outcome.

Stop if the proposal cannot be read or does not contain enough information. Do not browse to fill scientific gaps.

### 4. Freeze source truth

Complete the JSON files under `analysis/` using [analysis-contracts.md](references/analysis-contracts.md). Preserve exact proposal passages and locations for substantive claims. Use `NOT SUPPORTED` rather than inventing content.

```bash
python3 "<skill-root>/scripts/verify_source_quotes.py" --run-dir "<run-dir>"
```

Do not continue unless quote verification passes. Keep the primary scientific capability distinct from supporting analysis methods. Preserve the difference between proposed work and achieved evidence.

### 5. Build the decision-aid story before designing

Write one funding thesis and freeze answers to the four reviewer questions: fundamental advancement, why it should work, what makes success credible, and the DOE or sponsor payoff. Freeze two proposal-specific strengths.

Freeze a concise `visual_claim`: the unresolved before state, the source-supported scientific action, the visibly changed after state, the scientific payoff, and one topology (`TRANSFORMATION`, `INTEGRATION`, `PARALLEL_EVIDENCE`, `FEEDBACK`, or `BRANCHING_OUTCOMES`). Link every claim part to verified evidence. Keep each statement under 33 words so lesser models receive a visible instruction rather than an abstract essay. Preserve the topology literally: never turn parallel research thrusts into a false sequence or make one independent thrust branch from another. Keep the payoff science-based—what becomes knowable, measurable, predictable, controllable, validatable, or discoverable—and depict the resulting scientific state, map, relationship, or knowledge rather than a generic car, turbine, factory, certificate, checkmark, globe, lightbulb, or innovation symbol.

Then create a visual-object inventory of three to six recognizable, source-supported nouns or phenomena. Mark three to five as required decision-bearing objects and allow at most one optional credibility cue. Each required object needs a clear silhouette or visual signature. Combine subordinate validation activities into one compact cue instead of creating a second methods pipeline. Do not allow color fields, dots, arrows, or abstract blobs to substitute for the proposal's primary instrument, material system, interface, mechanism, data flow, or endpoint when a recognizable representation is possible.

Evaluate the four presentation-derived layout families:

- linear sequence;
- feedback loop;
- integration map; and
- outcomes/impact focus.

Choose the family that best expresses the primary funding story. A linear left-to-right sequence is valid when the proposal is genuinely transformational or process-based. A loop is valid only when recurrence or validation is central. Do not let a secondary validation detail outweigh the main narrative.

Plan two meaningfully different candidates: the strongest layout and one credible alternative. A layout is successful when it would become scientifically wrong after swapping in another proposal's nouns.

### 6. Coordinate color and references without overconstraining the image

Use Vision, Gap, Objectives, Approach, and Impact as an internal semantic wireframe. The presentation colors help confirm that all five roles were considered; they are not mandatory final-image regions and do not need to appear as five exact hex colors.

Choose a cohesive final palette that supports hierarchy and makes proposal elements distinguishable. Roles may share, overlap, or transition between colors when that better represents the science. Explain the observed role/color mapping in chat after generation.

Use one legacy bundled or user-supplied reference for each candidate when helpful during planning. The eight legacy references are **layout-only planning aids**: they may guide story topology, stage proportions, connector language, negative space, and color rhythm, but some also contain perspective, glow, shadows, or dimensional rendering that this skill forbids. Do not attach a legacy reference PNG to image generation. Attach only `assets/style-references/ref-flat-2d-style-target.png` to both generation calls as the certified style target. A user-supplied reference may replace that style target only when its major objects already pass the dimensional-style tripwires below. No reference may supply scientific claims, labels, logos, or unsupported content.

### 7. Freeze and validate the execution contract

Copy the verified semantic capsule, visual claim, object inventory, candidate plans, role ledger, planned palette, allowed visuals, and short safety exclusions into `analysis/execution-contract.json`. Keep `analysis/allowed-text.json` equal to `[]`.

```bash
python3 "<skill-root>/scripts/validate_run.py" --run-dir "<run-dir>" --stage pregen
```

### 8. Build two compact, visual prompts deterministically

Do not hand-compose the boilerplate-heavy image prompts. Make both candidate plans complete in `analysis/execution-contract.json`, then run:

```bash
python3 "<skill-root>/scripts/build_prompts.py" --run-dir "<run-dir>"
```

The builder preserves the source-locked capsule, frozen visual claim, required visual forms, palette, strict style language, and 250–500-word limit. It excludes every optional credibility object and optional spatial region from `MUST SHOW`; the default lesser-model path must not request a lower validation inset or return path. Use [image-execution.md](references/image-execution.md) to understand the generated contract. The candidate-specific fields must describe:

- one sentence explaining the funding story;
- one visible before-action-after change and the correct relationship topology;
- three to five required visual objects and at most one compact credibility cue;
- the reading order and relationships;
- the selected reference's layout-only planning role;
- a cohesive color strategy;
- one source-supported scientific payoff rather than a generic future-benefit symbol; and
- only the few exclusions needed to prevent text, unsupported evidence, Roadmap content, branding, or a known wrong scientific substitution.

Do not paste the full proposal, evidence table, five-role ledger, QA rubric, or long catalogs of forbidden motifs into the image prompt. Require one dominant story path. Do not ask for a second pipeline, a methods inventory, or several tiny validation scenes.

Inspect the built prompts for scientific correctness without expanding them, then run:

```bash
python3 "<skill-root>/scripts/validate_prompts.py" --run-dir "<run-dir>"
```

### 9. Generate two internal candidates

Use two separate image-generation calls, one per prompt. Do not attach a legacy bundled reference PNG; its topology has already been translated into the written spatial blueprint. Attach `assets/style-references/ref-flat-2d-style-target.png` as the only image reference for both calls. A user-supplied style reference may replace it only when it passes the dimensional-style tripwires. Save the original returned files without overwriting:

```text
candidates/candidate-a.png
candidates/candidate-b.png
```

The desired style is a polished flat-2D editorial-vector-style raster. Treat every major object as a paper-cut icon seen straight on. A rectangle may show only its front face. Prefer solid or restrained same-hue fills, consistent line weight, generous white space, and coherent connectors. Minimal flat translucency is allowed. Subtle tonal variation contained inside a front-facing shape is acceptable when the object still reads as matte and depthless. Fail if a major object shows a top or side face, offset stacked copies that imply thickness, perspective convergence, dimensional shading or highlights, an illuminated-screen effect, glow or halo, reflection, or cast shadow. Tonal treatment becomes disqualifying only when it creates perceived volume, illumination, glossy or material realism, or a competing focal effect.

### 10. Inspect the actual images in two phases

Run raster inspection and create the required thumbnail for each candidate, then run OCR or full-size visual text inspection:

```bash
python3 "<skill-root>/scripts/inspect_raster.py" \
  --image "<candidate.png>" \
  --out "<candidate.metrics.json>" \
  --palette-json "<run-dir>/analysis/palette.json" \
  --thumbnail "<candidate.thumbnail.png>"
```

Then follow [qa-rubric.md](references/qa-rubric.md):

1. **Blind image read:** create and inspect an actual 240 × 160 thumbnail before inspecting the full-size raster. Use a fresh task or isolated evaluator that receives only the thumbnail, full-size raster, and evaluation schema—not the proposal, source filename, prompt, intended topology, or planned meanings. Record the visible system, capability, before state, action, after state, relationship, observed topology, credibility cue, scientific endpoint/payoff, generic-substitution decision, and two strengths. Use `unknown` when a meaning is not recoverable from the image alone. If a truly isolated evaluator is unavailable, the candidate cannot fully qualify; keep it as a disclosed best-effort draft.
2. **Source reconciliation:** compare that cold read with the verified proposal. Score only meanings recoverable from the image. Prompt intent cannot rescue an ambiguous raster.

Run the observable flat-style tripwire audit from [qa-rubric.md](references/qa-rubric.md) **before** semantic scoring. Answer every tripwire from the full-size pixels and record localized evidence, even when the answer is false. Record contained non-dimensional tonal variation, modest nonfrontal views, shallow diagrammatic side/top faces, and flat layered offsets as advisory observations when they clarify the science without realistic thickness or light. If dimensional shading/highlights, glow, illumination, reflections, cast shadows, extrusion, or strongly perspectival rendering is present in a major object, set `flat_scientific_editorial_style` to `false`. Scientific clarity or attractive rendering cannot override a true dimensional-style failure. If the thumbnail shows a competing lower or secondary pipeline, set `one_dominant_hierarchy` to `false`.

A role color being present is not evidence that its meaning is visible. A recognizable proposal object, meaningful relationship, or scientifically grounded transition is.

### 11. Repair only bounded defects

Select the strongest candidate that either passes outright or fails only a repairable visual-surface defect. Use at most one built-in Image Edit in the run.

For visible text or another genuinely localized defect, use the localized-edit contract in [image-execution.md](references/image-execution.md). For dimensional shading, highlights, glow, or shadows distributed across otherwise successful major objects, first run:

```bash
python3 "<skill-root>/scripts/build_flat_style_repair_prompt.py" \
  --run-dir "<run-dir>" \
  --candidate "<a|b>"
```

This controlled whole-image normalization is eligible only when every science, evidence, text, hierarchy, endpoint, and reviewer-recovery gate already passes and the only observed style failures are dimensional surface treatments. Do not spend the one edit merely to remove acceptable contained tonal variation. Attach the original candidate first and the certified flat-style target second. Use the generated prompt exactly; save the result as `candidates/candidate-<id>-edit-01.png` without overwriting the original. Re-run raster, thumbnail, text, full-size tripwire, object-reconciliation, reviewer, and score evaluation on the edited pixels. Record the edited evaluation separately and set `repair_count` to `1` only after the edited raster exists.

Do not edit to rescue a wrong story, missing capability, unrecognizable science, absent visual action, wrong topology, generic payoff substitution, weak hierarchy, competing secondary pipeline, strongly perspectival structure, or generic composition. Those are structural failures and require a fresh generation or best-effort handoff.

### 12. Finalize one collaboration draft

```bash
python3 "<skill-root>/scripts/finalize_run.py" --run-dir "<run-dir>"
```

Confirm that `final/` contains exactly one PNG. Render only that PNG and begin the handoff with `AI-generated Figure 1 collaboration draft — not final`.

Do not write thumbnails, metrics, OCR files, or review derivatives into `final/`; keep them under `candidates/` or `validation/`. Make delivery validation the last filesystem action:

```bash
python3 "<skill-root>/scripts/validate_delivery.py" --run-dir "<run-dir>"
```

Do not deliver when this final check fails.

Add `Color roles in this draft:` with three to five short observations grounded in the actual raster and source lock. Add at most three `Remaining review items:`. Researcher interpretation, graphic-designer redraw, and scientist/content-owner verification remain required.

## What remains strict

The proposal is the scientific authority. The delivered artifact is one label-free raster PNG. Do not fabricate results or scientific evidence, introduce Roadmap years or thrusts, imitate an organization brand, add logos, or deliver vector/editable art.

Everything else—layout family, direction, visual metaphor, recognizable icons, palette, connectors, flat layering, shallow diagrammatic depth, restrained contained tonal variation, and degree of abstraction—should serve the proposal and the isolated 30-second reviewer test rather than a universal template. Perspective convergence, extrusion, depth-simulating shading or highlights, illuminated screens, glow, reflections, and cast shadows remain disallowed on major objects.
