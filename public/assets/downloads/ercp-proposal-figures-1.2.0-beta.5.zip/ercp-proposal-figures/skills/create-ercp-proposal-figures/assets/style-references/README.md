# Bundled style references

These eight PNGs are legacy layout-planning material for this collaboration-draft workflow:

- `ref-a-transformation-separation.png`
- `ref-a2-heterogeneous-resolution.png`
- `ref-b-integration-validation-return.png`
- `ref-b2-mapping-feedback-return.png`
- `ref-b3-iterative-control-return.png`
- `ref-c-central-capability-branching.png`
- `ref-d-multiscale-mechanism-iteration.png`
- `ref-e-shared-foundation-coupled-states.png`

The ninth PNG is the certified generation style target:

- `ref-flat-2d-style-target.png`

The eight legacy images demonstrate useful label-free scientific layout families: white field, coordinated color, clear connectors, generous negative space, and strong thumbnail hierarchy. Treat them as planning aids only. Some combine acceptable tonal polish with glow, shadows, or perspective, so do not attach them to generation. Attach only `ref-flat-2d-style-target.png`; it uses matte front-facing shapes, consistent outlines, and no depth effects. Generated drafts may retain restrained same-hue tonal variation when it does not imply volume, illumination, gloss, or material depth.

Translate only their composition grammar, stage proportions, connector language, icon abstraction, color rhythm, negative space, and hierarchy into the written plan. The current proposal remains the sole authority for scientific content, claims, credibility, and impact.

Do not copy a reference's scientific subjects, labels, claims, evidence, logos, or unsupported endpoint. Reusing its broad layout family is allowed when that layout fits the current proposal's primary funding story.
