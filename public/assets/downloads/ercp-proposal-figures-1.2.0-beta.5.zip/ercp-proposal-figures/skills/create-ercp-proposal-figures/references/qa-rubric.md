# Figure 1 raster QA and selection rubric

Evaluate the original raster, not a file card, filename, prompt, color ledger, or model self-report.

## Deterministic gates

Require:

- one valid 1536 × 1024 opaque PNG per candidate;
- exact prompt and source hash archived;
- empty allowed-text inventory;
- OCR or full-size visual inspection finding no visible text or pseudo-text;
- one final PNG and no client-facing vector/document alternatives; and
- recorded generation mode and repair count.

Palette and coverage metrics are diagnostics, not proof of meaning or exact-color compliance.

## Two-phase visual evaluation

### Phase A: blind image read

Create a real 240 × 160 thumbnail with `inspect_raster.py --thumbnail`. Use a fresh task or isolated evaluator whose only inputs are that thumbnail, the full-size raster, and this evaluation schema. Do not expose the proposal, prompt, semantic capsule, source filename, reference name, planned role ledger, or intended topology. Record `source_context_available: false` and plain-language answers:

- What scientific system or subject is visible?
- What capability or intervention appears central?
- What is the visible before state?
- What scientific action is physically visible?
- What is the visible after state?
- What changes, separates, couples, integrates, or becomes possible?
- What visual cue makes the approach credible?
- What endpoint or sponsor value is visible?
- What two strengths could a reviewer write from this image?
- Which regions remain ambiguous or generic?
- Is the visible payoff scientific, or has it been replaced by generic societal or future imagery?
- Which topology is actually visible: `TRANSFORMATION`, `INTEGRATION`, `PARALLEL_EVIDENCE`, `FEEDBACK`, `BRANCHING_OUTCOMES`, or `UNKNOWN`?

Save this cold read before source reconciliation. Use `unknown` when the image does not support an answer. Do not infer hidden intent from color alone or use proposal-only acronyms and claims to rescue the raster.

Before semantic scoring, answer these literal pixel questions from the full-size raster. Every value must be a boolean:

```json
{
  "nonfrontal_major_object": false,
  "visible_side_or_top_face": false,
  "offset_stacked_depth": false,
  "dimensional_shading_or_highlight_on_major_object": false,
  "glow_halo_or_illuminated_screen": false,
  "cast_shadow_or_reflection": false,
  "contained_nondimensional_tonal_variation": false,
  "competing_secondary_pipeline": false
}
```

Use these diagnostics literally:

- If a rectangular panel reveals two faces, `visible_side_or_top_face` is `true` even when the angle is slight.
- If repeated panels are offset behind one another to suggest thickness, `offset_stacked_depth` is `true`.
- If shading or a highlight makes a major shape look rounded, illuminated, glossy, material, or more focal because of simulated light, `dimensional_shading_or_highlight_on_major_object` is `true`.
- If a front-facing shape has only subtle same-hue tonal variation and remains visibly matte and depthless, set `contained_nondimensional_tonal_variation` to `true`; this is a review note, not a hard failure.
- Attractive hardware rendering is not an exception.

Also record `style_observation_evidence` with the same eight keys. Each value must name the visible region and cue, or state exactly `none observed after full-size inspection`. Dimensional shading/highlights, glow/illumination, reflections, or cast shadows fail `flat_scientific_editorial_style`. A nonfrontal object, shallow top/side face, flat offset layer, or contained non-dimensional tonal variation is an advisory redraw note unless it creates perspective convergence, extrusion, realistic thickness, illumination, or material depth. `competing_secondary_pipeline: true` fails `one_dominant_hierarchy`.

### Phase B: source reconciliation

Now compare the blind record with the verified proposal. A reviewer answer passes only when the cold-read meaning substantially matches the source lock. Prompt intent cannot rescue an ambiguous image.

## Visual and scientific hard gates

Every item must be true:

```json
{
  "attachment_grounding": true,
  "science_fidelity": true,
  "primary_capability_fidelity": true,
  "secondary_method_suppression": true,
  "decisive_relationship_visible": true,
  "visual_verb_recoverable": true,
  "topology_fidelity": true,
  "scientific_endpoint_visible": true,
  "claim_evidence_reconciliation": true,
  "closed_text_inventory": true,
  "five_role_color_fidelity": true,
  "brand_neutral_output": true,
  "style_reference_boundary": true,
  "no_fabricated_evidence": true,
  "no_roadmap_logic": true,
  "no_unauthorized_marks": true,
  "no_generic_template_or_stock_metaphor": true,
  "flat_scientific_editorial_style": true,
  "one_dominant_hierarchy": true,
  "thumbnail_reviewer_test": true,
  "graphic_designer_handoff_value": true
}
```

Interpret the gates as follows:

- `primary_capability_fidelity` requires a recognizable capability, not a color region whose meaning comes only from the prompt.
- `visual_verb_recoverable` requires a cold reader to describe a visible before state, action, and changed after state without proposal vocabulary being supplied.
- `topology_fidelity` requires the observed topology to match the source-locked topology after reconciliation. Parallel work cannot pass when the image implies false sequential causality.
- `scientific_endpoint_visible` fails when generic societal or future-benefit symbols substitute for the proposal's actual scientific payoff.
- `five_role_color_fidelity` means the five proposal roles are visually accounted for through a coherent palette, contrast, continuity, transition, shared carrier, or spatial relationship. Exact wireframe hex colors are not required, and roles may share colors.
- `style_reference_boundary` allows the reference's composition grammar and visual finish to transfer. It forbids copied scientific content, labels, claims, evidence, or branding.
- `no_generic_template_or_stock_metaphor` fails only when generic imagery replaces proposal-specific content or creates the wrong scientific story. A scientifically appropriate icon, network, device, facility, database, molecule, atom, contour, layer, gear, shield, or arrow is not automatically a failure.
- `flat_scientific_editorial_style` requires consistent line weight and a predominantly matte, diagrammatic reading. Solid fills are preferred, but restrained same-hue tonal variation, a gentle background tint, mild edge softness, limited uniform translucency, shallow orthographic faces, and flat layered offsets may pass when they do not imply realistic volume, illumination, gloss, material realism, perspective convergence, or a competing focal effect. Fail dimensional shading or highlight, illuminated screen, glow or halo, reflection, cast shadow, extrusion, or strongly perspectival rendering.
- `graphic_designer_handoff_value` measures whether the scientifically correct, clearly organized concept gives a professional redraw artist a useful starting point. Acceptable contained tonal variation cannot fail this gate by itself; note `flatten tonal variation during professional redraw` when useful.
- `thumbnail_reviewer_test` passes only when the isolated blind image read recovers the advancement, capability, visible before/action/after change, decisive relationship, scientific endpoint/payoff, and two defensible strengths.

## Proposal-specific recognizability

Inventory each required visual object from `visual_object_inventory`. Mark it:

- recognizable and source-consistent;
- present but ambiguous;
- absent; or
- misleading.

Every required object must be recognizable and source-consistent. Abstract dots, bands, or fields count only when their role is visually evident from the surrounding proposal-specific system.

## Evidence boundary

Do not mistake an attractive scientific-looking image for evidence. Fail when the raster implies unsupported measured results, exact structures, numerical performance, facility use, or achieved outcomes. Simplified concept illustrations of source-supported subjects are allowed.

## Scores

Score each from 0 to 5:

- science fidelity;
- primary-capability fidelity;
- proposal specificity;
- funding story;
- scientific payoff and sponsor relevance (`sponsor_value` in the saved score schema);
- credibility without fake evidence;
- visual hierarchy;
- label-free compliance;
- reference-family fit; and
- graphic-designer handoff value.

Qualify only when every hard gate passes, the average is at least 4.0, and no score is below 3. A visually usable image that does not qualify may be returned only as a clearly labeled best-effort draft with its failed findings disclosed.

## Candidate evaluation file

Create `evaluations/candidate-a.json` and `evaluations/candidate-b.json`:

```json
{
  "candidate_id": "A",
  "artifact": "candidates/candidate-a.png",
  "metrics": "candidates/candidate-a.metrics.json",
  "labels_report": "candidates/candidate-a.labels.json",
  "status": "pass",
  "blind_image_read": {
    "review_mode": "image-only-cold-read",
    "source_context_available": false,
    "thumbnail_artifact": "candidates/candidate-a.thumbnail.png",
    "visible_system": "",
    "visible_primary_capability": "",
    "visible_before_state": "",
    "visible_action": "",
    "visible_after_state": "",
    "visible_decisive_relationship": "",
    "visible_credibility_cue": "",
    "visible_endpoint": "",
    "visible_sponsor_value": "",
    "observed_topology": "UNKNOWN",
    "generic_or_societal_payoff_substitution": false,
    "proposal_specific_strengths": ["", ""],
    "ambiguous_or_generic_regions": []
  },
  "style_observations": {
    "nonfrontal_major_object": false,
    "visible_side_or_top_face": false,
    "offset_stacked_depth": false,
    "dimensional_shading_or_highlight_on_major_object": false,
    "glow_halo_or_illuminated_screen": false,
    "cast_shadow_or_reflection": false,
    "contained_nondimensional_tonal_variation": false,
    "competing_secondary_pipeline": false
  },
  "style_observation_evidence": {
    "nonfrontal_major_object": "none observed after full-size inspection",
    "visible_side_or_top_face": "none observed after full-size inspection",
    "offset_stacked_depth": "none observed after full-size inspection",
    "dimensional_shading_or_highlight_on_major_object": "none observed after full-size inspection",
    "glow_halo_or_illuminated_screen": "none observed after full-size inspection",
    "cast_shadow_or_reflection": "none observed after full-size inspection",
    "contained_nondimensional_tonal_variation": "none observed after full-size inspection",
    "competing_secondary_pipeline": "none observed after full-size inspection"
  },
  "hard_gates": {},
  "reviewer_test": {
    "fundamental_advancement": true,
    "why_it_should_work": true,
    "credibility": true,
    "doe_or_sponsor_payoff": true,
    "proposal_specific_strengths": ["", ""]
  },
  "object_reconciliation": [
    {"source_term": "", "status": "recognizable", "observed_form": "", "source_support": ""}
  ],
  "actual_color_role_ledger": {
    "VISION": {"visible_family": "", "carrier": "", "source_support": ""},
    "GAP": {"visible_family": "", "carrier": "", "source_support": ""},
    "OBJECTIVES": {"visible_family": "", "carrier": "", "source_support": ""},
    "APPROACH": {"visible_family": "", "carrier": "", "source_support": ""},
    "IMPACT": {"visible_family": "", "carrier": "", "source_support": ""}
  },
  "scores": {},
  "repairable_issue": null,
  "selection_reason": ""
}
```

`visible_family` may describe a shared or transitional palette relationship; it is not required to match a wireframe anchor.

Use `status: fail` whenever a hard gate fails, regardless of score.

## Repair and selection

Permit one localized edit for a contained defect. Also permit one controlled whole-image flat-style normalization when `build_flat_style_repair_prompt.py` confirms that every non-style gate and reviewer question already passes and the only observed failures are dimensional shading/highlights, glow, or shadows. Acceptable contained tonal variation or shallow diagrammatic depth does not require repair. Re-evaluate the edited pixels from scratch. A missing capability, unrecognizable proposal subject, wrong visual verb, wrong topology, generic payoff substitution, weak composition, competing secondary pipeline, or strongly perspectival structure is not repairable by this edit.

If neither candidate qualifies, rank usable candidates by science fidelity, recognizable primary capability, proposal specificity, reviewer recovery, sponsor value, and overall visual quality. Return exactly one best-effort raster only when it remains scientifically usable, and disclose the failed findings.
