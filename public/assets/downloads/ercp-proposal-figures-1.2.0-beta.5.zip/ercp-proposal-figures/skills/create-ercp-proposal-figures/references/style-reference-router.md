# Layout-and-style reference router

## Purpose

Use the bundled PNGs as layout-planning examples. They may guide composition grammar, but the attached proposal remains the authority for science, claims, credibility, and sponsor value.

Translate a reference into a written topology: layout skeleton, stage proportions, connector language, balance of literal and symbolic forms, color rhythm, white space, and hierarchy. Replace every scientific subject and outcome with source-supported content from the current proposal. Do not attach a bundled reference to generation: several examples combine useful tonal polish with glow, shadows, or shallow perspective that conflict with the flat-2D output contract and can overpower prompt language.

## Bundled references

Certified generation style target:

- `assets/style-references/ref-flat-2d-style-target.png`: attach this to generation to reinforce front-facing shapes, matte fills, consistent navy outlines, generous white space, and no depth or lighting effects. Transfer its surface language only, never its generic scientific content or topology.

Legacy layout-planning references; never attach these to generation:

- `assets/style-references/ref-a-transformation-separation.png`: a heterogeneous starting state passes through one dominant capability and separates into organized outcomes.
- `assets/style-references/ref-a2-heterogeneous-resolution.png`: a mixed scientific field narrows into a central resolving mechanism and produces an ordered endpoint.
- `assets/style-references/ref-b-integration-validation-return.png`: disparate records or inputs integrate through a central system, with a subordinate return or validation relationship.
- `assets/style-references/ref-b2-mapping-feedback-return.png`: a scientific field is mapped through an analytical capability into a resolved state, with a clear feedback path.
- `assets/style-references/ref-b3-iterative-control-return.png`: one transformation produces an ordered endpoint while a lower intervention or learning loop improves the system.
- `assets/style-references/ref-c-central-capability-branching.png`: a clear input enters a recognizable enabling device or capability, then resolves into several outcomes.
- `assets/style-references/ref-d-multiscale-mechanism-iteration.png`: a physical interface or system connects multiscale characterization, modeling, data, and an improved material state.
- `assets/style-references/ref-e-shared-foundation-coupled-states.png`: two scientific states connect through a central multiscale response while a shared enabling foundation supports both.

The reference filenames describe layout behavior, not the only proposals they can support.

## Routing method

1. Freeze the funding thesis and visual-object inventory.
2. Identify the main relationship: transformation, separation, integration, branching, mapping, recurrence, coupled states, or another proposal-native relationship.
3. Score all four presentation layout families—linear sequence, feedback loop, integration map, and outcomes/impact focus—against the main relationship.
4. Choose the closest legacy bundled reference for Candidate A's layout plan.
5. Choose a different credible legacy layout or reference for Candidate B when one exists.

Route on the main funding argument. Do not select a feedback-loop reference merely because the proposal contains a later validation activity. Do not reject a linear reference merely because the proposal is scientifically complex.

## What may transfer

- layout family and reading direction;
- broad stage proportions and relative emphasis;
- composition skeleton such as input → capability → outcome, hub-and-branches, integration, or return path;
- connector and arrow language;
- icon abstraction and shape vocabulary without copying the depicted science;
- balance of large and small forms;
- coordinated color rhythm without requiring the same exact palette;
- uniform flat translucency and overlapping 2D regions without rendered depth;
- negative space, hierarchy, and overall polish.

## What may not transfer

- proposal-specific science, labels, claims, data, or achieved results;
- a depicted instrument, material, facility, mechanism, or endpoint unsupported by the current proposal;
- logos, brand marks, institutional templates, or recognizable brand treatment; or
- misleading scientific precision.

Reusing a reference's general topology is allowed. Copying its scientific story is not.

## Shared visual family

The expected family is an opaque 1536 × 1024 landscape PNG with no visible text, a white or near-white field, recognizable proposal-specific forms, one dominant story spine, clear connectors, generous negative space, and a polished flat-vector-style finish.

The examples include soft gradients, translucent regions, layered forms, and modest perspective. Use only their 2D topology, reading direction, proportions, connector logic, negative space, and broad color rhythm. Subtle same-hue tonal variation may appear in the generated figure, but major objects must remain front-facing, matte, and depthless; legacy glow, shadows, perspective, and dimensional surface modeling are not transferable.

## Routing failure conditions

Fail routing when:

- the selected reference follows a secondary method instead of the primary funding story;
- the proposal's defining objects disappear into generic abstraction;
- reference science or unsupported claims enter the planned figure; or
- Candidate A and Candidate B are merely cosmetic rearrangements of the same weak structure.
