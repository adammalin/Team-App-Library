#!/usr/bin/env python3
"""Build two compact image prompts from a validated ERCP execution contract."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


CAPSULE_KEYS = ("SYSTEM", "PRIMARY CAPABILITY", "DECISIVE RELATIONSHIP", "ENDPOINT", "DO NOT SUBSTITUTE")
PROMPT_CAPSULE_KEYS = ("SYSTEM", "PRIMARY CAPABILITY", "DO NOT SUBSTITUTE")
STYLE_ASSET = "assets/style-references/ref-flat-2d-style-target.png"


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def required_visuals(contract: dict[str, Any]) -> list[str]:
    values = [
        str(item.get("visual_form", "")).strip()
        for item in contract.get("visual_object_inventory", [])
        if isinstance(item, dict) and item.get("required") is True and str(item.get("visual_form", "")).strip()
    ]
    if not 3 <= len(values) <= 5:
        raise ValueError("visual_object_inventory must contain three to five required visual forms")
    return values


def render_prompt(contract: dict[str, Any], plan: dict[str, Any], region_limit: int) -> str:
    capsule = contract.get("semantic_capsule", {})
    if tuple(capsule.keys()) != CAPSULE_KEYS:
        raise ValueError("semantic capsule differs from the five-line source-lock contract")
    capsule_lines = "\n".join(f"{key}: {capsule[key]}" for key in PROMPT_CAPSULE_KEYS)
    must_show = "\n".join(f"- {value}" for value in required_visuals(contract))
    optional_claim_ids = {
        str(item.get("claim_id", "")).strip()
        for item in contract.get("visual_object_inventory", [])
        if isinstance(item, dict) and item.get("required") is False and str(item.get("claim_id", "")).strip()
    }
    regions = [
        str(item.get("geometry", "")).strip().rstrip(".")
        for item in plan.get("spatial_blueprint", [])
        if (
            isinstance(item, dict)
            and str(item.get("geometry", "")).strip()
            and str(item.get("claim_id", "")).strip() not in optional_claim_ids
        )
    ][:region_limit]
    region_text = ". ".join(regions)
    if region_text:
        region_text += "."
    visual_claim = contract.get("visual_claim", {})
    claim_lines = "\n".join(
        (
            f"BEFORE STATE: {visual_claim['before_state']}",
            f"VISIBLE ACTION: {visual_claim['action']}",
            f"AFTER STATE: {visual_claim['after_state']}",
            f"SCIENTIFIC PAYOFF: {visual_claim['scientific_payoff']}",
            f"RELATIONSHIP TOPOLOGY: {visual_claim['topology']}",
        )
    )

    return f"""NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. COMPLETELY TEXT-FREE FLAT-2D EDITORIAL-VECTOR-STYLE RASTER PNG.

PURPOSE
Show the funding story.

SOURCE-LOCKED SCIENCE — DO NOT RENDER AS TEXT
{capsule_lines}

VISUAL CLAIM — SHOW THE CHANGE, NOT JUST THE OBJECTS
{claim_lines}
Show physical change. Obey topology: PARALLEL_EVIDENCE uses independent lanes that never pass through or branch from one another and converge only at the endpoint. The endpoint must depict scientific state, map, relationship, or knowledge—not a car, turbine, factory, certificate, checkmark, lightbulb, globe, or innovation icon.

MUST SHOW
{must_show}

COMPOSITION
Use one dominant story path: {contract['funding_story_spine']} Do not add a separate validation inset, return path, or secondary pipeline.
CANDIDATE STRUCTURE: {plan['layout_family']}. {region_text}

STYLE TARGET: {STYLE_ASSET}
Attach only this style target. Transfer matte fills, navy outlines, white space, and depthless finish; never its objects or layout.

COLOR AND STYLE
{contract['palette_strategy']} Polished flat editorial vector: matte fills, navy outlines, white space, clear connectors, front-facing paper-cut icons. Depthless same-hue tone and translucency are allowed. No perspective, extrusion, dimensional lighting, glow, reflection, shadow, or branding.

SCIENCE BOUNDARY
Show proposed concepts, not achieved evidence. No invented data, Roadmap content, unsupported precision, or stock substitutes.

OUTPUT
One opaque 1536 × 1024 landscape PNG. No text, pseudo-text, Greek letters, logo, SVG, vector data, or alternate.

NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE.
""".strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()
    contract = load_json(run_dir / "analysis" / "execution-contract.json")
    plans = {
        str(item.get("candidate_id", "")).casefold(): item
        for item in contract.get("candidate_plans", [])
        if isinstance(item, dict)
    }
    if set(plans) != {"a", "b"}:
        raise SystemExit("execution contract must contain candidate plans A and B")

    prompt_dir = run_dir / "prompts"
    prompt_dir.mkdir(parents=True, exist_ok=True)
    word_counts: dict[str, int] = {}
    for candidate_id in ("a", "b"):
        prompt = ""
        for region_limit in (5, 3, 1, 0):
            prompt = render_prompt(contract, plans[candidate_id], region_limit)
            if len(prompt.split()) <= 500:
                break
        word_count = len(prompt.split())
        if not 250 <= word_count <= 500:
            raise SystemExit(f"candidate-{candidate_id} deterministic prompt has {word_count} words; compact the execution contract")
        path = prompt_dir / f"candidate-{candidate_id}.txt"
        path.write_text(prompt, encoding="utf-8")
        word_counts[path.name] = word_count

    print(json.dumps({"status": "pass", "word_counts": word_counts}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
