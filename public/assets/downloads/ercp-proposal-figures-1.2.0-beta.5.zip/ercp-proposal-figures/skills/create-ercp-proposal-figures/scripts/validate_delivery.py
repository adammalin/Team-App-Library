#!/usr/bin/env python3
"""Verify that the ERCP run exposes exactly one final raster PNG."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()
    final_dir = run_dir / "final"
    expected = final_dir / "ercp-figure-1-draft.png"
    files = sorted(path.name for path in final_dir.iterdir()) if final_dir.is_dir() else []
    errors: list[str] = []
    if files != [expected.name]:
        errors.append(f"final directory must contain only {expected.name}; found {files}")
    if not expected.is_file():
        errors.append("final raster is missing")
    elif expected.read_bytes()[:8] != b"\x89PNG\r\n\x1a\n":
        errors.append("final artifact is not a PNG")

    result = {"status": "pass" if not errors else "fail", "files": files, "errors": errors}
    out = run_dir / "validation" / "delivery.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
