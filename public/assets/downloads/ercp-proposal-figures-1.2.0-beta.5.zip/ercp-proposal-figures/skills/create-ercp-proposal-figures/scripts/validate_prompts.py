#!/usr/bin/env python3
"""Validate two compact candidate prompts against the frozen execution contract."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


REQUIRED_START = (
    "NEVER USE ANY LABELS OR TEXT. ONE IMAGE ONLY. "
    "COMPLETELY TEXT-FREE FLAT-2D EDITORIAL-VECTOR-STYLE RASTER PNG."
)
REQUIRED_END = "NEVER USE ANY LABELS OR TEXT. ONLY ALLOWED VISIBLE TEXT: NONE."
PROMPT_CAPSULE_KEYS = ("SYSTEM", "PRIMARY CAPABILITY", "DO NOT SUBSTITUTE")
REQUIRED_STYLE = (
    "Polished flat editorial vector: matte fills, navy outlines, white space, clear connectors, front-facing "
    "paper-cut icons. Depthless same-hue tone and translucency are allowed."
)
REQUIRED_STYLE_EXCLUSIONS = (
    "No perspective, extrusion, dimensional lighting, glow, reflection, shadow, or branding."
)
REQUIRED_STYLE_ASSET = "STYLE TARGET: assets/style-references/ref-flat-2d-style-target.png"
REQUIRED_STYLE_USE = (
    "Attach only this style target. Transfer matte fills, navy outlines, white space, and depthless finish; "
    "never its objects or layout."
)
REQUIRED_SECTIONS = (
    "PURPOSE",
    "SOURCE-LOCKED SCIENCE — DO NOT RENDER AS TEXT",
    "VISUAL CLAIM — SHOW THE CHANGE, NOT JUST THE OBJECTS",
    "MUST SHOW",
    "COMPOSITION",
    "CANDIDATE STRUCTURE:",
    "COLOR AND STYLE",
    "SCIENCE BOUNDARY",
    "OUTPUT",
)
REQUIRED_VISUAL_CLAIM_RULE = (
    "Show physical change. Obey topology: PARALLEL_EVIDENCE uses independent lanes that never pass through or "
    "branch from one another and converge only at the endpoint. The endpoint must depict scientific state, map, "
    "relationship, or knowledge—not a car, turbine, factory, certificate, checkmark, lightbulb, globe, or innovation icon."
)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.expanduser().resolve()
    out = run_dir / "validation" / "prompts.json"

    try:
        run = load_json(run_dir / "run.json")
        pregen = load_json(run_dir / "validation" / "pregen.json")
        execution = load_json(run_dir / "analysis" / "execution-contract.json")
        current_analysis_hashes = {
            str(path.relative_to(run_dir)): sha256(path)
            for path in sorted((run_dir / "analysis").glob("*.json"))
        }
        errors: list[str] = []
        if run.get("status") != "pregen_passed" or pregen.get("status") != "pass":
            errors.append("pre-generation validation is not current and passed")
        if pregen.get("analysis_sha256") != current_analysis_hashes:
            errors.append("analysis changed after pre-generation validation")
        if execution.get("only_allowed_text") != []:
            errors.append("execution contract is not label-free")
        if execution.get("visual_brand_policy") != "BRAND_NEUTRAL_PROPOSAL_DRAFT":
            errors.append("execution contract is not brand-neutral")

        plans = {
            str(item.get("candidate_id", "")).casefold(): item
            for item in execution.get("candidate_plans", [])
            if isinstance(item, dict)
        }
        if set(plans) != {"a", "b"}:
            errors.append("execution contract must contain candidate plans A and B")

        prompts: dict[str, str] = {}
        prompt_hashes: dict[str, str] = {}
        for stem, plan_key in (("candidate-a", "a"), ("candidate-b", "b")):
            path = run_dir / "prompts" / f"{stem}.txt"
            if not path.is_file():
                errors.append(f"missing exact prompt: {path}")
                continue
            text = path.read_text(encoding="utf-8").strip()
            prompts[stem] = text
            prompt_hashes[str(path.relative_to(run_dir))] = sha256(path)
            if not text:
                errors.append(f"empty prompt: {stem}")
                continue
            word_count = len(text.split())
            if not 250 <= word_count <= 500:
                errors.append(f"{stem} must contain 250 to 500 words; found {word_count}")
            if not text.startswith(REQUIRED_START):
                errors.append(f"{stem} does not begin with the exact no-text hard gate")
            if not text.endswith(REQUIRED_END):
                errors.append(f"{stem} does not end with the exact no-text hard gate")
            for section in REQUIRED_SECTIONS:
                if section not in text:
                    errors.append(f"{stem} lacks required compact-prompt section: {section}")
            if REQUIRED_STYLE not in text:
                errors.append(f"{stem} lacks the exact flat-2D positive style contract")
            if REQUIRED_STYLE_EXCLUSIONS not in text:
                errors.append(f"{stem} lacks the exact rendered-depth exclusion contract")
            if REQUIRED_STYLE_ASSET not in text:
                errors.append(f"{stem} lacks the certified flat-style asset")
            if REQUIRED_STYLE_USE not in text:
                errors.append(f"{stem} lacks the exact certified-style transfer boundary")
            if "one dominant story path" not in text.casefold():
                errors.append(f"{stem} does not require one dominant story path")
            try:
                must_show = text.split("\nMUST SHOW\n", 1)[1].split("\n\nCOMPOSITION\n", 1)[0]
                must_show_count = sum(line.startswith("- ") for line in must_show.splitlines())
                if not 3 <= must_show_count <= 5:
                    errors.append(f"{stem} MUST SHOW must contain three to five bullets; found {must_show_count}")
            except IndexError:
                errors.append(f"{stem} lacks a parseable MUST SHOW block")
            for key in PROMPT_CAPSULE_KEYS:
                value = execution.get("semantic_capsule", {}).get(key)
                if f"{key}: {value}" not in text:
                    errors.append(f"{stem} lacks exact semantic-capsule line: {key}")
            for redundant_key in ("DECISIVE RELATIONSHIP", "ENDPOINT"):
                value = execution.get("semantic_capsule", {}).get(redundant_key)
                if isinstance(value, str) and f"{redundant_key}: {value}" in text:
                    errors.append(f"{stem} repeats {redundant_key} instead of using the compact visual claim")
            visual_claim = execution.get("visual_claim", {})
            visual_claim_lines = {
                "before_state": "BEFORE STATE",
                "action": "VISIBLE ACTION",
                "after_state": "AFTER STATE",
                "scientific_payoff": "SCIENTIFIC PAYOFF",
                "topology": "RELATIONSHIP TOPOLOGY",
            }
            for key, label in visual_claim_lines.items():
                value = visual_claim.get(key) if isinstance(visual_claim, dict) else None
                if not isinstance(value, str) or f"{label}: {value}" not in text:
                    errors.append(f"{stem} lacks exact visual-claim line: {key}")
            if REQUIRED_VISUAL_CLAIM_RULE not in text:
                errors.append(f"{stem} lacks the visible-action and science-payoff substitution rule")
            for item in execution.get("visual_object_inventory", []):
                if not isinstance(item, dict):
                    continue
                visual_form = item.get("visual_form")
                if not isinstance(visual_form, str) or not visual_form.strip():
                    continue
                if item.get("required") is True and visual_form not in text:
                    errors.append(f"{stem} lacks required visual form: {visual_form}")
                if item.get("required") is False and visual_form in text:
                    errors.append(f"{stem} promotes an optional credibility cue into MUST SHOW: {visual_form}")

            plan = plans.get(plan_key, {})
            funding_story_spine = execution.get("funding_story_spine")
            if isinstance(funding_story_spine, str) and funding_story_spine not in text:
                errors.append(f"{stem} lacks the frozen funding story spine")
            if "Do not add a separate validation inset, return path, or secondary pipeline." not in text:
                errors.append(f"{stem} lacks the no-secondary-pipeline generation rule")
            layout_family = plan.get("layout_family") if isinstance(plan, dict) else None
            if isinstance(layout_family, str) and f"CANDIDATE STRUCTURE: {layout_family}." not in text:
                errors.append(f"{stem} lacks its selected candidate structure")
            palette_strategy = execution.get("palette_strategy")
            if isinstance(palette_strategy, str) and palette_strategy not in text:
                errors.append(f"{stem} lacks the planned cohesive palette strategy")

            required_output = "One opaque 1536 × 1024 landscape PNG."
            if required_output not in text:
                errors.append(f"{stem} lacks the fixed raster output rule")
            if "Greek letters" not in text:
                errors.append(f"{stem} lacks the symbolic-letter exclusion")
            if "branding" not in text:
                errors.append(f"{stem} does not explicitly preserve brand neutrality")
            if text.count("NEVER USE ANY LABELS OR TEXT") < 2:
                errors.append(f"{stem} must repeat the no-text gate at start and end")

        if len(prompts) == 2 and prompts["candidate-a"] == prompts["candidate-b"]:
            errors.append("candidate prompts are identical; layout and composition must differ")

        result = {
            "status": "pass" if not errors else "fail",
            "validated_at": datetime.now(timezone.utc).isoformat(),
            "errors": errors,
            "analysis_sha256": current_analysis_hashes,
            "prompt_sha256": prompt_hashes,
            "word_counts": {stem: len(text.split()) for stem, text in prompts.items()},
        }
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        run["status"] = "prompts_validated" if not errors else "prompt_validation_failed"
        run["prompts_validated_at"] = result["validated_at"]
        (run_dir / "run.json").write_text(json.dumps(run, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 0 if not errors else 1
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f"RESULT | FAIL | {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
