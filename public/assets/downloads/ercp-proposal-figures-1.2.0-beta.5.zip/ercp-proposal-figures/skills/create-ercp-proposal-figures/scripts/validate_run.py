#!/usr/bin/env python3
"""Validate source-locked ERCP Figure 1 analysis before image generation."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


CAPSULE_KEYS = (
    "SYSTEM",
    "PRIMARY CAPABILITY",
    "DECISIVE RELATIONSHIP",
    "ENDPOINT",
    "DO NOT SUBSTITUTE",
)
REVIEWER_KEYS = (
    "fundamental_advancement",
    "why_it_should_work",
    "credibility",
    "doe_or_sponsor_payoff",
)
COLOR_ROLES = ("VISION", "GAP", "OBJECTIVES", "APPROACH", "IMPACT")
WIREFRAME_ROLE_COLORS = {
    "VISION": "#C6DCCC",
    "GAP": "#FE5000",
    "OBJECTIVES": "#B36CFF",
    "APPROACH": "#FF9E1B",
    "IMPACT": "#BFD1D3",
}
LAYOUT_FAMILIES = {
    "LINEAR_SEQUENCE",
    "FEEDBACK_LOOP",
    "INTEGRATION_MAP",
    "OUTCOMES_IMPACT_FOCUS",
    "PROPOSAL_NATIVE",
}
VISUAL_CLAIM_KEYS = (
    "before_state",
    "action",
    "after_state",
    "scientific_payoff",
    "topology",
    "source_support",
)
VISUAL_CLAIM_PARTS = ("before_state", "action", "after_state", "scientific_payoff")
RELATIONSHIP_TOPOLOGIES = {
    "TRANSFORMATION",
    "INTEGRATION",
    "PARALLEL_EVIDENCE",
    "FEEDBACK",
    "BRANCHING_OUTCOMES",
}
BUNDLED_STYLE_ASSETS = {
    "assets/style-references/ref-a-transformation-separation.png",
    "assets/style-references/ref-a2-heterogeneous-resolution.png",
    "assets/style-references/ref-b-integration-validation-return.png",
    "assets/style-references/ref-b2-mapping-feedback-return.png",
    "assets/style-references/ref-b3-iterative-control-return.png",
    "assets/style-references/ref-c-central-capability-branching.png",
    "assets/style-references/ref-d-multiscale-mechanism-iteration.png",
    "assets/style-references/ref-e-shared-foundation-coupled-states.png",
}
HEX_COLOR = re.compile(r"^#[0-9A-Fa-f]{6}$")


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"missing file: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON in {path}: {exc}") from exc


def nonempty(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip()) and value.strip() != "NOT SUPPORTED"


def check_label(label: Any) -> str | None:
    if not nonempty(label):
        return "label is empty"
    if len(label) > 36:
        return f"label exceeds 36 characters: {label!r}"
    if len(label.split()) > 5:
        return f"label exceeds five words: {label!r}"
    return None


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_pregen(run_dir: Path) -> list[str]:
    errors: list[str] = []
    run = load_json(run_dir / "run.json")
    source = load_json(run_dir / "analysis" / "source-lock.json")
    science = load_json(run_dir / "analysis" / "science-verification.json")
    funding = load_json(run_dir / "analysis" / "funding-case.json")
    visual = load_json(run_dir / "analysis" / "visual-brief.json")
    execution = load_json(run_dir / "analysis" / "execution-contract.json")
    allowed_text = load_json(run_dir / "analysis" / "allowed-text.json")
    palette = load_json(run_dir / "analysis" / "palette.json")
    try:
        quote_report = load_json(run_dir / "validation" / "source-quotes.json")
    except ValueError as exc:
        errors.append(str(exc))
        quote_report = {}

    if run.get("schema_version") != 4:
        errors.append("run schema version must equal 4")
    if run.get("workflow_version") != "1.2.0-beta.5":
        errors.append("run workflow version must equal 1.2.0-beta.5")

    if run.get("source_authorization") != "user-supplied-in-task":
        errors.append("source authorization does not record a user-supplied task input")
    companion_status = run.get("companion_status")
    if companion_status not in ("none", "not-supplied", "supplied"):
        errors.append("companion status must be none, not-supplied, or supplied")
    if companion_status == "supplied" and not isinstance(run.get("companion"), dict):
        errors.append("supplied companion status requires a hashed companion record")
    if companion_status != "supplied" and run.get("companion") is not None:
        errors.append("companion record exists but companion status is not supplied")
    if run.get("generation_mode") != "codex-built-in-imagegen":
        errors.append("generation mode must be codex-built-in-imagegen")
    if run.get("candidate_count") != 2 or run.get("final_artifact_count") != 1:
        errors.append("run output-count contract differs from two internal candidates and one final artifact")
    if run.get("repair_ceiling") != 1:
        errors.append("repair ceiling must equal one")

    if source.get("status") != "pass":
        errors.append("source-lock status is not pass")
    required_source = (
        "proposal_title",
        "scientific_vision",
        "scientific_system",
        "consequential_gap",
        "primary_capability",
        "decisive_relationship",
        "validation_logic",
        "scientific_endpoint",
        "doe_payoff",
    )
    for key in required_source:
        if not nonempty(source.get(key)):
            errors.append(f"source-lock field is missing or unsupported: {key}")
    objectives = source.get("objectives", [])
    if not isinstance(objectives, list) or not objectives or any(not nonempty(item) for item in objectives):
        errors.append("source lock requires at least one source-supported objective")
    if len(source.get("distinctive_terms", [])) < 4:
        errors.append("source lock requires at least four distinctive terms")
    if len(source.get("strengths", [])) < 2:
        errors.append("source lock requires two proposal-specific strengths")
    if not source.get("allowed_subjects") or not source.get("allowed_relationships"):
        errors.append("source lock requires allowed subjects and relationships")
    if not source.get("forbidden_inferences"):
        errors.append("source lock requires proposal-specific forbidden inferences")
    evidence = source.get("evidence", [])
    if len(evidence) < 8:
        errors.append("source lock requires at least eight claim-evidence entries")
    evidence_ids: set[str] = set()
    for index, entry in enumerate(evidence):
        if not isinstance(entry, dict):
            errors.append(f"evidence entry {index} is not an object")
            continue
        claim_id = entry.get("claim_id")
        if not nonempty(claim_id) or not nonempty(entry.get("claim")):
            errors.append(f"evidence entry {index} lacks claim id or claim")
        if not nonempty(entry.get("exact_quote")) or not nonempty(entry.get("section")):
            errors.append(f"evidence entry {index} lacks exact quote or section")
        if isinstance(claim_id, str):
            if claim_id in evidence_ids:
                errors.append(f"duplicate claim id: {claim_id}")
            evidence_ids.add(claim_id)

    if quote_report.get("status") != "pass":
        errors.append("source quotation verification did not pass")
    if quote_report.get("source_sha256") != run.get("source", {}).get("sha256"):
        errors.append("source quotation report refers to a different source hash")
    if quote_report.get("source_lock_sha256") != sha256(run_dir / "analysis" / "source-lock.json"):
        errors.append("source quotation report is stale for the current source lock")
    if quote_report.get("evidence_count") != len(evidence):
        errors.append("source quotation report evidence count differs from the source lock")
    if set(quote_report.get("verified_claim_ids", [])) != evidence_ids:
        errors.append("source quotation report does not verify every claim id")

    if science.get("status") != "pass":
        errors.append("science-verification status is not pass")
    checksum = science.get("proposal_identity_checksum", {})
    expected_pairs = {
        "scientific_system": source.get("scientific_system"),
        "primary_capability": source.get("primary_capability"),
        "decisive_relationship": source.get("decisive_relationship"),
        "validation_logic": source.get("validation_logic"),
        "scientific_endpoint": source.get("scientific_endpoint"),
        "doe_payoff": source.get("doe_payoff"),
    }
    for key, expected in expected_pairs.items():
        if checksum.get(key) != expected:
            errors.append(f"identity checksum does not match source lock: {key}")
    capsule = science.get("renderer_capsule", {})
    if tuple(capsule.keys()) != CAPSULE_KEYS:
        errors.append("renderer capsule keys or order differ from the required five-line contract")
    capsule_pairs = {
        "SYSTEM": source.get("scientific_system"),
        "PRIMARY CAPABILITY": source.get("primary_capability"),
        "DECISIVE RELATIONSHIP": source.get("decisive_relationship"),
        "ENDPOINT": source.get("scientific_endpoint"),
    }
    for key, expected in capsule_pairs.items():
        if capsule.get(key) != expected:
            errors.append(f"renderer capsule does not match source lock: {key}")
    if not nonempty(capsule.get("DO NOT SUBSTITUTE")):
        errors.append("renderer capsule requires a proposal-specific DO NOT SUBSTITUTE line")
    if not science.get("prohibited_substitutions"):
        errors.append("science verification requires prohibited substitutions")
    if science.get("secondary_method_suppression_pass") is not True:
        errors.append("secondary-method suppression did not pass")
    if science.get("interchangeability_test_pass") is not True:
        errors.append("proposal interchangeability test did not pass")
    matrix = science.get("claim_evidence_matrix", [])
    if not matrix:
        errors.append("claim-evidence matrix is empty")
    for index, item in enumerate(matrix):
        if item.get("claim_id") not in evidence_ids or not nonempty(item.get("planned_item")):
            errors.append(f"claim-evidence matrix entry {index} is unsupported")

    if funding.get("status") != "pass" or not nonempty(funding.get("funding_thesis")):
        errors.append("funding case is not passed and populated")
    answers = funding.get("reviewer_answers", {})
    for key in REVIEWER_KEYS:
        if not nonempty(answers.get(key)):
            errors.append(f"funding case lacks reviewer answer: {key}")
    if len(funding.get("strengths", [])) < 2:
        errors.append("funding case requires two strengths")

    if visual.get("status") != "pass" or not nonempty(visual.get("funding_story_spine")):
        errors.append("visual brief is not passed and lacks a funding story spine")

    visual_claim = visual.get("visual_claim", {})
    if not isinstance(visual_claim, dict) or tuple(visual_claim.keys()) != VISUAL_CLAIM_KEYS:
        errors.append("visual claim keys or order differ from the required before-action-after-payoff contract")
    else:
        for part in VISUAL_CLAIM_PARTS:
            statement = visual_claim.get(part)
            if not nonempty(statement):
                errors.append(f"visual claim lacks a source-grounded {part}")
            elif len(statement.split()) > 32:
                errors.append(f"visual claim {part} exceeds 32 words; keep the image instruction concrete")
        if visual_claim.get("topology") not in RELATIONSHIP_TOPOLOGIES:
            errors.append("visual claim uses an unsupported relationship topology")
        support = visual_claim.get("source_support", {})
        if not isinstance(support, dict) or tuple(support.keys()) != VISUAL_CLAIM_PARTS:
            errors.append("visual claim source support must map all four claim parts in order")
        else:
            for part in VISUAL_CLAIM_PARTS:
                support_value = support.get(part)
                support_ids = support_value if isinstance(support_value, list) else [support_value]
                if not 1 <= len(support_ids) <= 3 or any(claim_id not in evidence_ids for claim_id in support_ids):
                    errors.append(f"visual claim {part} must use one to three supported claim ids")

    objects = visual.get("visual_object_inventory", [])
    if not isinstance(objects, list) or not 3 <= len(objects) <= 6:
        errors.append("visual object inventory must contain three to six entries")
        objects = []
    required_objects = 0
    optional_objects = 0
    for index, item in enumerate(objects):
        if not isinstance(item, dict) or not all(
            nonempty(item.get(key)) for key in ("source_term", "claim_id", "visual_form", "recognition_cue")
        ):
            errors.append(f"visual object entry {index} is incomplete")
            continue
        if item.get("claim_id") not in evidence_ids:
            errors.append(f"visual object entry {index} uses an unsupported claim id")
        if item.get("required") is True:
            required_objects += 1
        elif item.get("required") is False:
            optional_objects += 1
        else:
            errors.append(f"visual object entry {index} required must be boolean")
    if not 3 <= required_objects <= 5:
        errors.append("visual object inventory requires three to five required entries")
    if optional_objects > 1:
        errors.append("visual object inventory allows at most one optional credibility cue")

    layout_evaluation = visual.get("layout_evaluation", [])
    if not isinstance(layout_evaluation, list) or len(layout_evaluation) < 2:
        errors.append("layout evaluation must compare at least two families")
        layout_evaluation = []
    layout_fits: dict[str, str] = {}
    for index, item in enumerate(layout_evaluation):
        if not isinstance(item, dict) or item.get("family") not in LAYOUT_FAMILIES:
            errors.append(f"layout evaluation entry {index} uses an unsupported family")
            continue
        if item.get("fit") not in ("primary", "alternate", "rejected") or not nonempty(item.get("reason")):
            errors.append(f"layout evaluation entry {index} lacks a valid fit and reason")
            continue
        if item["family"] in layout_fits:
            errors.append(f"layout family appears more than once: {item['family']}")
        layout_fits[item["family"]] = item["fit"]
    primary_families = [family for family, fit in layout_fits.items() if fit == "primary"]
    alternate_families = [family for family, fit in layout_fits.items() if fit == "alternate"]
    if len(primary_families) != 1 or not alternate_families:
        errors.append("layout evaluation requires exactly one primary and at least one alternate")

    candidate_plans = visual.get("candidate_plans", [])
    if not isinstance(candidate_plans, list) or [item.get("candidate_id") for item in candidate_plans if isinstance(item, dict)] != ["A", "B"]:
        errors.append("candidate plans must contain A then B")
        candidate_plans = []
    for index, plan in enumerate(candidate_plans):
        family = plan.get("layout_family")
        expected_fit = "primary" if plan.get("candidate_id") == "A" else "alternate"
        if family not in LAYOUT_FAMILIES or layout_fits.get(family) != expected_fit:
            errors.append(f"candidate plan {plan.get('candidate_id', index)} does not use its {expected_fit} layout")
        if not nonempty(plan.get("story_spine")):
            errors.append(f"candidate plan {plan.get('candidate_id', index)} lacks a story spine")
        if plan.get("relationship_topology") != visual_claim.get("topology"):
            errors.append(f"candidate plan {plan.get('candidate_id', index)} changes the source-locked relationship topology")
        blueprint = plan.get("spatial_blueprint", [])
        if not isinstance(blueprint, list) or len(blueprint) < 3:
            errors.append(f"candidate plan {plan.get('candidate_id', index)} requires at least three spatial regions")
        else:
            for item_index, item in enumerate(blueprint):
                if not isinstance(item, dict) or not all(
                    nonempty(item.get(key)) for key in ("id", "semantic_anchor", "claim_id", "geometry")
                ):
                    errors.append(f"candidate plan {plan.get('candidate_id', index)} region {item_index} is incomplete")
                    continue
                if item.get("semantic_anchor") not in CAPSULE_KEYS[:4]:
                    errors.append(f"candidate plan {plan.get('candidate_id', index)} region {item_index} uses an unknown semantic anchor")
                if item.get("claim_id") not in evidence_ids:
                    errors.append(f"candidate plan {plan.get('candidate_id', index)} region {item_index} uses an unsupported claim id")
        style_reference = plan.get("style_reference", {})
        if not isinstance(style_reference, dict):
            errors.append(f"candidate plan {plan.get('candidate_id', index)} style reference is not an object")
        else:
            asset = style_reference.get("asset")
            if not nonempty(asset):
                errors.append(f"candidate plan {plan.get('candidate_id', index)} style reference asset is missing")
            elif asset != "NONE":
                asset_path = Path(str(asset))
                if asset in BUNDLED_STYLE_ASSETS:
                    if not (Path(__file__).resolve().parent.parent / asset).is_file():
                        errors.append(f"bundled style reference file is missing: {asset}")
                elif not asset_path.is_absolute() or not asset_path.is_file():
                    errors.append(f"candidate plan {plan.get('candidate_id', index)} style reference is not bundled or readable")
            if style_reference.get("use_mode") != "LAYOUT_AND_STYLE":
                errors.append(f"candidate plan {plan.get('candidate_id', index)} reference use_mode must be LAYOUT_AND_STYLE")
            if not style_reference.get("transfer") or not style_reference.get("prohibited_transfer"):
                errors.append(f"candidate plan {plan.get('candidate_id', index)} reference inventories are incomplete")
    if len(candidate_plans) == 2:
        if candidate_plans[0].get("layout_family") == candidate_plans[1].get("layout_family"):
            errors.append("candidate plans must use different layout families")
        if candidate_plans[0].get("story_spine") == candidate_plans[1].get("story_spine"):
            errors.append("candidate plans must use meaningfully different story spines")

    labels = visual.get("allowed_text", [])
    if labels != []:
        errors.append("allowed text must equal the empty list for a completely label-free raster")
    if allowed_text != labels:
        errors.append("allowed-text.json differs from visual-brief allowed_text")
    ledger = visual.get("color_role_ledger", {})
    if not isinstance(ledger, dict) or tuple(ledger.keys()) != COLOR_ROLES:
        errors.append("five-role color ledger keys or order differ from VISION, GAP, OBJECTIVES, APPROACH, IMPACT")
    else:
        for role, entry in ledger.items():
            if not isinstance(entry, dict):
                errors.append(f"color role {role} is not an object")
                continue
            if not all(nonempty(entry.get(key)) for key in ("scientific_meaning", "claim_id", "visual_carrier", "wireframe_anchor", "image_treatment")):
                errors.append(f"color role {role} is incomplete")
            if entry.get("claim_id") not in evidence_ids:
                errors.append(f"color role {role} uses an unsupported claim id")
            if entry.get("wireframe_anchor") != WIREFRAME_ROLE_COLORS[role]:
                errors.append(f"color role {role} uses the wrong internal wireframe anchor")
    if not nonempty(visual.get("palette_strategy")):
        errors.append("visual brief requires a cohesive palette strategy")
    validation_cue = visual.get("validation_relationship_cue", {})
    if not isinstance(validation_cue, dict) or not all(
        nonempty(validation_cue.get(key)) for key in ("scientific_meaning", "claim_id", "geometry")
    ):
        errors.append("validation relationship cue is incomplete")
    elif validation_cue.get("claim_id") not in evidence_ids:
        errors.append("validation relationship cue uses an unsupported claim id")
    if not visual.get("allowed_visuals") or not visual.get("forbidden") or not visual.get("must_preserve"):
        errors.append("visual brief requires allowed visuals, forbidden content, and preserve inventory")
    if len(visual.get("forbidden", [])) > 10:
        errors.append("visual brief forbidden inventory is too long; keep only material science and output risks")
    if visual.get("visual_brand_policy") != "BRAND_NEUTRAL_PROPOSAL_DRAFT":
        errors.append("visual brand policy must equal BRAND_NEUTRAL_PROPOSAL_DRAFT")
    if visual.get("logo_state") != "OMIT":
        errors.append("logo state must equal OMIT for a brand-neutral collaboration draft")
    if visual.get("canvas") != {"width": 1536, "height": 1024}:
        errors.append("canvas must equal 1536 by 1024")
    if visual.get("candidate_count") != 2 or visual.get("final_artifact_count") != 1:
        errors.append("visual brief output count differs from the fixed contract")
    if visual.get("repair_ceiling") != 1:
        errors.append("visual brief repair ceiling must equal one")

    expected_output = {
        "candidate_count": 2,
        "final_artifact_count": 1,
        "format": "PNG",
        "artifact_type": "raster",
        "width": 1536,
        "height": 1024,
        "opacity": "opaque",
    }
    if execution.get("status") != "pass":
        errors.append("execution contract status is not pass")
    if execution.get("semantic_capsule") != capsule:
        errors.append("execution contract semantic capsule differs from science verification")
    if execution.get("only_allowed_text") != labels:
        errors.append("execution contract allowed text differs from the visual brief")
    for contract_key, visual_key in (
        ("funding_story_spine", "funding_story_spine"),
        ("visual_claim", "visual_claim"),
        ("visual_object_inventory", "visual_object_inventory"),
        ("layout_evaluation", "layout_evaluation"),
        ("candidate_plans", "candidate_plans"),
        ("color_role_ledger", "color_role_ledger"),
        ("palette_strategy", "palette_strategy"),
        ("validation_relationship_cue", "validation_relationship_cue"),
        ("visual_brand_policy", "visual_brand_policy"),
        ("allowed_visuals", "allowed_visuals"),
        ("logo_state", "logo_state"),
        ("must_preserve", "must_preserve"),
        ("forbidden", "forbidden"),
    ):
        if execution.get(contract_key) != visual.get(visual_key):
            errors.append(f"execution contract differs from the visual brief: {contract_key}")
    if execution.get("output") != expected_output:
        errors.append("execution contract output differs from the fixed raster contract")
    if execution.get("repair_ceiling") != 1:
        errors.append("execution contract repair ceiling must equal one")

    if not isinstance(palette, list) or not 3 <= len(palette) <= 12 or any(not HEX_COLOR.match(str(c)) for c in palette):
        errors.append("palette.json must contain three to twelve six-digit hex colors")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--stage", choices=("pregen",), default="pregen")
    args = parser.parse_args()

    run_dir = args.run_dir.expanduser().resolve()
    try:
        errors = validate_pregen(run_dir)
    except (OSError, ValueError) as exc:
        errors = [str(exc)]
    analysis_hashes = {
        str(path.relative_to(run_dir)): sha256(path)
        for path in sorted((run_dir / "analysis").glob("*.json"))
    }
    result = {
        "stage": args.stage,
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "analysis_sha256": analysis_hashes,
    }
    out = run_dir / "validation" / f"{args.stage}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    try:
        run = load_json(run_dir / "run.json")
        run["status"] = "pregen_passed" if not errors else "pregen_failed"
        run["pregen_validated_at"] = datetime.now(timezone.utc).isoformat()
        (run_dir / "run.json").write_text(json.dumps(run, indent=2) + "\n", encoding="utf-8")
    except (OSError, ValueError, TypeError):
        pass
    print(json.dumps(result, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
